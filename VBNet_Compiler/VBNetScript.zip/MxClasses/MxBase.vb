Option Strict On
Namespace Mx
    Public Module PubOperations
        Public Const mt = ""
        Public Const qs = """"
        Public Const qt = "''"
        Public Const s = " "

        <System.Diagnostics.DebuggerHidden()> Public Function AreEqual(ur_value_1 As String, ur_value_2 As String) As Boolean
            AreEqual = False
            If String.IsNullOrWhiteSpace(ur_value_1) Then
                If String.IsNullOrWhiteSpace(ur_value_2) Then
                    AreEqual = True
                End If

            Else 'ur_value_1
                If String.IsNullOrWhiteSpace(ur_value_2) = False AndAlso
                   String.Equals(ur_value_1, ur_value_2, System.StringComparison.CurrentCultureIgnoreCase) Then
                    AreEqual = True
                End If
            End If 'ur_value_1
        End Function 'AreEqual

        <System.Diagnostics.DebuggerHidden()> Public Function b0(ur_val As Integer) As Integer
            b0 = ur_val - 1
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function b1(ur_val As Integer) As Integer
            b1 = ur_val + 1
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function CmdOutput(ur_exec_path As String, Optional ur_exec_param As String = mt) As String
            Dim P As New System.Diagnostics.Process()
            With 1 : Dim prcINFO = P.StartInfo
                prcINFO.FileName = ur_exec_path
                prcINFO.Arguments = ur_exec_param
                prcINFO.UseShellExecute = False
                prcINFO.RedirectStandardOutput = True
                prcINFO.CreateNoWindow = True
            End With 'prcINFO

            P.Start()
            CmdOutput = P.StandardOutput.ReadToEnd()
            P.WaitForExit()
        End Function 'CmdOutput

        <System.Diagnostics.DebuggerHidden()> Public Function ContainingText(ur_large_text As String, ur_small_text As String) As Boolean
            ContainingText = InStr(ur_large_text, ur_small_text, CompareMethod.Text) > 0
        End Function 'ContainingText

        <System.Diagnostics.DebuggerHidden()> Public Function EndingWithText(ur_large_text As String, ur_small_text As String) As Boolean
            EndingWithText = AreEqual(Right(ur_large_text, Len(ur_small_text)), ur_small_text)
        End Function 'EndingWithText

        <System.Diagnostics.DebuggerHidden()> Public Function HasText(ur_value As String) As Boolean
            HasText = Not String.IsNullOrWhiteSpace(ur_value)
        End Function 'HasText

        <System.Diagnostics.DebuggerHidden()> Public Function MyClassName() As String
            Dim stf As New System.Diagnostics.StackFrame(1)
            MyClassName = stf.GetMethod.DeclaringType.Name
        End Function 'MyClassName

        <System.Diagnostics.DebuggerHidden()> Public Function MyMethodName() As String
            Dim stf As New System.Diagnostics.StackFrame(1)
            With 1 : Dim dgyMETHOD = stf.GetMethod
                MyMethodName = dgyMETHOD.DeclaringType.Name & "." & dgyMETHOD.Name
            End With 'dgyMETHOD
        End Function 'MyMethodName

        <System.Diagnostics.DebuggerHidden()> Public Function MyMethodTitle() As String
            Dim stf As New System.Diagnostics.StackFrame(1)
            MyMethodTitle = stf.GetMethod.Name
        End Function 'MyMethodTitle

        <System.Diagnostics.DebuggerHidden()> Public Function StartingWithText(ur_large_text As String, ur_small_text As String) As Boolean
            StartingWithText = AreEqual(Left(ur_large_text, Len(ur_small_text)), ur_small_text)
        End Function 'StartingWithText

        Public Function Strapd() As Strap
            Strapd = New Strap
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function StrSplit(ur_value As String, ur_separator As String) As Sdata
            StrSplit = New Sdata().d(Microsoft.VisualBasic.Split(ur_value, ur_separator))
        End Function 'StrSplit


        Public Class ErrListBase
            Inherits Dlone(Of String)

            <System.Diagnostics.DebuggerHidden()> Public Function DoContinue() As Boolean
                DoContinue = (Me.Found = False)
            End Function 'DoContinue

            <System.Diagnostics.DebuggerHidden()> Public Sub dError_Data(ur_exception As System.Exception, ur_methodbase As System.Reflection.MethodBase, Optional ur_procedure_status As String = mt)
                Dim stpTEXT = Strapd().d(Me.EntryItem)
                If stpTEXT.Length > 0 Then
                    stpTEXT.dLine().dLine()
                End If

                stpTEXT.dLine(ur_exception.Message)
                stpTEXT.dLine(Strapd().d("Error in @r1.@r2").r1(ur_methodbase.DeclaringType.Name).r2(ur_methodbase.Name).dS("(status: @r1)").r1(ur_procedure_status))
                Call Me.d(stpTEXT)
            End Sub 'dError_Data

            <System.Diagnostics.DebuggerHidden()> Public Sub Throw_Error_Data(ur_exception As System.Exception, ur_methodbase As System.Reflection.MethodBase, Optional ur_procedure_status As String = mt)
                Call Me.dError_Data(ur_exception, ur_methodbase, ur_procedure_status)
                Throw New LocalException(mt)
            End Sub 'Throw_Error_Data
        End Class 'ErrListBase


        Public Class LocalException
            Inherits Exception

            <System.Diagnostics.DebuggerHidden()> Public Sub New()
            End Sub

            <System.Diagnostics.DebuggerHidden()> Public Sub New(message As String)
                MyBase.New(message)
            End Sub

            <System.Diagnostics.DebuggerHidden()> Public Sub New(message As String, inner As Exception)
                MyBase.New(message, inner)
            End Sub
        End Class 'LocalException








        Public Class Dlone(Of T)
            Private vobjDATA As T
            Private vbolVAL_READY As Boolean

            <System.Diagnostics.DebuggerHidden()> Public Sub New(Optional ByVal ur_data As T = Nothing)
                Me.vobjDATA = ur_data
                Call Me.Reset()
            End Sub

            Public Shadows ReadOnly Property Current() As T
                <System.Diagnostics.DebuggerHidden()> Get
                    Current = Me.vobjDATA
                End Get
            End Property

            <System.Diagnostics.DebuggerHidden()> Public Function d(ur_obj As T) As Dlone(Of T)
                d = Me
                Me.vobjDATA = ur_obj
                Call Me.Reset()
            End Function 'd

            <System.Diagnostics.DebuggerHidden()> Public Function GetEnumerator() As Dlone(Of T)
                GetEnumerator = Me
                Call Me.Reset()
            End Function

            Public ReadOnly Property EntryItem() As T
                <System.Diagnostics.DebuggerHidden()> Get
                    EntryItem = Me.vobjDATA
                End Get
            End Property

            <System.Diagnostics.DebuggerHidden()> Public Function Found() As Boolean
                Found = (Me.vobjDATA IsNot Nothing)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function MoveNext() As Boolean
                MoveNext = Me.vbolVAL_READY
                Me.vbolVAL_READY = False
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function Reset() As Dlone(Of T)
                Reset = Me
                Me.vbolVAL_READY = Me.Found
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function Test() As DloneTest
                Test = New DloneTest(Me.vobjDATA)
            End Function

            Public Class DloneTest
                Inherits Dlone(Of T)

                <System.Diagnostics.DebuggerHidden()> Public Sub New(Optional ByVal ur_data As T = Nothing)
                    MyBase.New(ur_data)
                    Call Me.Reset()
                End Sub

                Public Shadows ReadOnly Property Current() As DloneTest
                    <System.Diagnostics.DebuggerHidden()> Get
                        Current = Me
                    End Get
                End Property

                <System.Diagnostics.DebuggerHidden()> Public Shadows Function GetEnumerator() As DloneTest
                    GetEnumerator = Me
                    Call Me.Reset()
                End Function

                <System.Diagnostics.DebuggerHidden()> Public Shadows Function Reset() As DloneTest
                    Reset = Me
                    Me.vbolVAL_READY = True
                End Function
            End Class 'DloneTest


            Public Class Req
                Inherits Dlone(Of T)
                <System.Diagnostics.DebuggerHidden()> Public Sub New(ur_obj As T)
                    Call MyBase.New(ur_obj)
                End Sub 'New

                <System.Diagnostics.DebuggerHidden()> Public Shared Widening Operator CType(b As T) As Req
                    Return New Req(b)
                End Operator 'CType
                <System.Diagnostics.DebuggerHidden()> Public Shared Widening Operator CType(b As Req) As T
                    Return b.EntryItem
                End Operator 'CType

                <System.Diagnostics.DebuggerHidden()> Public Shadows Function d(ur_obj As T) As Req
                    d = Me
                    MyBase.d(ur_obj)
                    If ur_obj Is Nothing Then
                        Throw New System.ArgumentException("Null Parameter")
                    End If 'Meo
                End Function 'd

                Public ReadOnly Property u() As T
                    <System.Diagnostics.DebuggerHidden()> Get
                        u = Me.vobjDATA
                    End Get
                End Property
            End Class 'Req
        End Class 'DLone

        Public Class enmV(Of T)
            Shared vsdaVAL As System.Collections.Generic.List(Of T)
            Shared vsdaNAME As Sdnm(Of T)

            <System.Diagnostics.DebuggerHidden()> Public Shared Function Keys() As System.Collections.ObjectModel.ReadOnlyCollection(Of T)
                Call Init()
                Keys = vsdaVAL.AsReadOnly
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Shared Function Names() As Sdnm(Of T)
                Call Init()
                Names = vsdaNAME
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Shared Sub Init()
                If vsdaNAME Is Nothing Then
                    vsdaVAL = New System.Collections.Generic.List(Of T)
                    vsdaNAME = New Sdnm(Of T)(False)
                    For Each intVAL In System.Enum.GetValues(GetType(T))
                        vsdaVAL.Add(DirectCast(CObj(intVAL), T))
                        vsdaNAME.Add(intVAL.ToString)
                    Next
                End If 'vsdaNAME
            End Sub 'Init

            <System.Diagnostics.DebuggerHidden()> Public Shared Function Length() As Integer
                Call Init()
                Length = vsdaNAME.Count
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Shared Function n(ur_index As T) As String
                Call Init()
                n = vsdaNAME.Item(DirectCast(DirectCast(ur_index, Object), Integer))
            End Function
        End Class 'enmV

        Public Class RCTR
            Private vintMAX_NUM As Integer
            Private vintCUR_NUM As Integer

            <System.Diagnostics.DebuggerHidden()> Public Sub New(ByVal ur_max_num As Integer)
                Me.vintMAX_NUM = ur_max_num
                Call Me.Reset()
            End Sub

            Public Shadows ReadOnly Property Current() As Integer
                <System.Diagnostics.DebuggerHidden()> Get
                    Current = Me.vintCUR_NUM
                End Get
            End Property

            <System.Diagnostics.DebuggerHidden()> Public Function GetEnumerator() As RCTR
                GetEnumerator = Me
                Call Me.Reset()
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function MoveNext() As Boolean
                MoveNext = (Me.vintCUR_NUM < Me.vintMAX_NUM)
                Me.vintCUR_NUM += 1
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function Reset() As RCTR
                Reset = Me
                Me.vintCUR_NUM = 0
            End Function

            Public Class Rb0
                Inherits RCTR
                <System.Diagnostics.DebuggerHidden()> Public Sub New(ByVal ur_max_num As Integer)
                    Call MyBase.New(ur_max_num)
                End Sub 'New

                Public Shadows ReadOnly Property Current() As Integer
                    <System.Diagnostics.DebuggerHidden()> Get
                        Current = Me.vintCUR_NUM - 1
                    End Get
                End Property
            End Class 'Rb0

            Public Class Rb0desc
                Inherits RCTR
                <System.Diagnostics.DebuggerHidden()> Public Sub New(ByVal ur_max_num As Integer)
                    Call MyBase.New(ur_max_num)
                End Sub 'New

                Public Shadows ReadOnly Property Current() As Integer
                    <System.Diagnostics.DebuggerHidden()> Get
                        Current = Me.vintMAX_NUM - Me.vintCUR_NUM
                    End Get
                End Property
            End Class 'Rb0desc

            Public Class RDesc
                Inherits RCTR
                <System.Diagnostics.DebuggerHidden()> Public Sub New(ByVal ur_max_num As Integer)
                    Call MyBase.New(ur_max_num)
                End Sub

                Public Shadows ReadOnly Property Current() As Integer
                    <System.Diagnostics.DebuggerHidden()> Get
                        Current = Me.vintMAX_NUM + 1 - Me.vintCUR_NUM
                    End Get
                End Property
            End Class 'RDesc

            Public Class RKvp
                Inherits RCTR
                Dim vsdaTEXT As Sdata
                <System.Diagnostics.DebuggerHidden()> Public Sub New(ByVal ur_data As Sdata)
                    Call MyBase.New(ur_data.Count)
                    Me.vsdaTEXT = ur_data
                End Sub 'New

                <System.Diagnostics.DebuggerHidden()> Public Sub New(ByVal ur_data As System.Collections.Generic.IList(Of String))
                    Call MyBase.New(ur_data.Count)
                    Me.vsdaTEXT = New Sdata().d(ur_data)
                End Sub 'New

                Public Shadows ReadOnly Property Current() As RKvp
                    <System.Diagnostics.DebuggerHidden()> Get
                        Current = Me
                    End Get
                End Property

                Public ReadOnly Property Entry() As String
                    <System.Diagnostics.DebuggerHidden()> Get
                        Entry = Me.vsdaTEXT.Entryb1(Me.vintCUR_NUM)
                    End Get
                End Property

                <System.Diagnostics.DebuggerHidden()> Public Shadows Function GetEnumerator() As RKvp
                    GetEnumerator = Me
                    Call Me.Reset()
                End Function

                Public ReadOnly Property Indexb1() As Integer
                    <System.Diagnostics.DebuggerHidden()> Get
                        Indexb1 = Me.vintCUR_NUM
                    End Get
                End Property
            End Class 'RKvp

            Public Class RKvp(Of T)
                Inherits RKvp

                <System.Diagnostics.DebuggerHidden()> Public Sub New(ByVal ur_data As Sdata)
                    Call MyBase.New(ur_data)
                End Sub
                
                Public Shadows ReadOnly Property Current() As RKvp(Of T)
                    <System.Diagnostics.DebuggerHidden()> Get
                        Current = Me
                    End Get
                End Property

                Public ReadOnly Property enm() As T
                    <System.Diagnostics.DebuggerHidden()> Get
                        enm = DirectCast(CObj(Me.Indexb1 - 1), T)
                    End Get
                End Property

                <System.Diagnostics.DebuggerHidden()> Public Shadows Function GetEnumerator() As RKvp(Of T)
                    GetEnumerator = Me
                    Call Me.Reset()
                End Function
            End Class 'RKvp(Of T)
        End Class 'RCTR

        Public Class Sdata
            Inherits System.Collections.Generic.List(Of String)

            <System.Diagnostics.DebuggerHidden()> Public Function d(ParamArray ur_val() As String) As Sdata
                d = Me
                If ur_val IsNot Nothing Then
                    For Each strENTRY In ur_val
                        Call Me.Add(strENTRY)
                    Next strENTRY
                End If
            End Function 'd

            <System.Diagnostics.DebuggerHidden()> Public Function d(ur_val As System.Collections.Generic.IList(Of String)) As Sdata
                d = Me
                If ur_val IsNot Nothing Then
                    For Each strENTRY In ur_val
                        Call Me.Add(strENTRY)
                    Next
                End If
            End Function 'd

            <System.Diagnostics.DebuggerHidden()> Public Function Entryb1(ur_index As Integer) As String
                Entryb1 = Me.Item(b0(ur_index))
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function DLoneb1(ur_index As Integer) As Dlone(Of String)
                DLoneb1 = New Dlone(Of String)
                If ur_index > 0 AndAlso
                   ur_index <= Me.Count Then
                    DLoneb1.d(Me.Item(b0(ur_index)))
                End If
            End Function 'Dloneb1

            <System.Diagnostics.DebuggerHidden()> Public Function RKvp() As RCTR.RKvp
                RKvp = New RCTR.RKvp(Me)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Shared Function Split(ur_text As String, ur_sprtr As String) As Sdata
                Dim sdaCMP = New Sdata
                Split = sdaCMP
                For Each strTEXT In ur_text.Split(ur_sprtr.ToCharArray()(0))
                    sdaCMP.Add(strTEXT)
                Next
            End Function 'Split
        End Class 'Sdata

        Public Class Sdnm(Of T)
            Inherits Sdata

            <System.Diagnostics.DebuggerHidden()> Public Sub New(Optional ur_flag_auto As Boolean = True)
                If ur_flag_auto Then
                    For Each kvpENTRY In enmV(Of T).Names
                        Me.Add(mt)
                    Next
                End If 'ur_flag_auto
            End Sub 'New

            Public Property enm(ur_index As T) As String
                <System.Diagnostics.DebuggerHidden()> Get
                    enm = Me.Item(DirectCast(CObj(ur_index), Integer))
                End Get
                <System.Diagnostics.DebuggerHidden()> Set(value As String)
                    Me.Item(DirectCast(CObj(ur_index), Integer)) = value
                End Set
            End Property

            Public ReadOnly Property IndexName(ur_key As T) As String
                <System.Diagnostics.DebuggerHidden()> Get
                    IndexName = enmV(Of T).Names.enm(ur_key)
                End Get
            End Property

            <System.Diagnostics.DebuggerHidden()> Public Shadows Function RKvp() As RCTR.RKvp(Of T)
                RKvp = New RCTR.RKvp(Of T)(Me)
            End Function
        End Class 'Sdnm

        Public Class Strap
            Private vstbTEXT As System.Text.StringBuilder

            <System.Diagnostics.DebuggerHidden()> Public Sub New()
                Me.vstbTEXT = New System.Text.StringBuilder
            End Sub

            <System.Diagnostics.DebuggerHidden()> Public Shared Widening Operator CType(b As Strap) As String
                Return b.ToString
            End Operator

            <System.Diagnostics.DebuggerHidden()> Public Function d(ParamArray ur_text() As String) As Strap
                d = Me.dSprtr(mt, ur_text)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function dClear(ParamArray ur_text() As String) As Strap
                dClear = Me
                Call Me.vstbTEXT.Clear()
                Call Me.d()
            End Function 'dClear

            <System.Diagnostics.DebuggerHidden()> Public Function dCSV(ParamArray ur_text() As String) As Strap
                dCSV = Me.dSprtr(",", ur_text)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function dLine(ParamArray ur_text() As String) As Strap
                dLine = Me.dSprtr(Chr(10), ur_text)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function dS(ParamArray ur_text() As String) As Strap
                dS = Me.dSprtr(s, ur_text)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function dSprtr(ur_sprtr As String, ParamArray ur_text() As String) As Strap
                dSprtr = Me
                If ur_text IsNot Nothing Then
                    For Each strENTRY In ur_text
                        Me.vstbTEXT.Append(ur_sprtr).Append(strENTRY)
                    Next strENTRY
                End If 'ur_text
            End Function 'dSprtr

            Public ReadOnly Property Length As Integer
                <System.Diagnostics.DebuggerHidden()> Get
                    Length = Me.vstbTEXT.Length
                End Get
            End Property

            <System.Diagnostics.DebuggerHidden()> Public Function r1(ur_text As String) As Strap
                r1 = Me
                Call Me.vstbTEXT.Replace("@r1", ur_text)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function r2(ur_text As String) As Strap
                r2 = Me
                Call Me.vstbTEXT.Replace("@r2", ur_text)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Shadows Function ToString() As String
                ToString = Me.vstbTEXT.ToString
            End Function
        End Class 'Strap


        <System.Diagnostics.DebuggerHidden()> Public Sub Write_ErrorReport(ur_text As String, ur_stat As Strap)
            Dim strFILE_PATH = ""
            Dim strDATA = ur_text
            Try
                If ur_stat.Length > 0 Then
                    strDATA &= vbCrLf & ur_stat.ToString
                End If

                Dim bolEMIT_BOM_MARK = False
                Dim bolVERIFY_ONLY_VALID_BYTES = False
                Dim objENCODE_FORMAT = New System.Text.UTF8Encoding(bolEMIT_BOM_MARK, bolVERIFY_ONLY_VALID_BYTES)
                strFILE_PATH = System.Reflection.Assembly.GetEntryAssembly().Location.Replace("\bin\Debug", mt) & ".err.txt"
                System.IO.File.WriteAllText(strFILE_PATH, strDATA, objENCODE_FORMAT)

            Catch ex As System.Exception
                System.Console.WriteLine(strDATA)
                System.Console.WriteLine("Cannot write Error Report to text file: " & "[" & strFILE_PATH & "]")
                System.Console.WriteLine(ex.Message)
            End Try
        End Sub 'Write_ErrorReport
    End Module 'PubOperations
End Namespace 'Mx
