Option Strict On
Namespace Mx
    Public Module ConstVar
        Public Const mt As String = ""
        Public Const qs As String = """"
        Public Const qt As String = "'"
        Public Const q4t As String = "''''"
        Public Const s As String = " "

        <System.Diagnostics.DebuggerHidden()> Public Function b0(ur_val As Integer) As Integer
            b0 = ur_val - 1
        End Function
        <System.Diagnostics.DebuggerHidden()> Public Function b1(ur_val As Integer) As Integer
            b1 = ur_val + 1
        End Function
        <System.Diagnostics.DebuggerHidden()> Public Function AreEqual(ur_val As String, ur_cmp As String) As Boolean
            AreEqual = String.Equals(ur_val, ur_cmp, StringComparison.CurrentCultureIgnoreCase)
        End Function
        <System.Diagnostics.DebuggerHidden()> Public Function ContainingText(ur_large_text As String, ur_small_text As String) As Boolean
            ContainingText = InStr(ur_large_text, ur_small_text, CompareMethod.Text) > 0
        End Function 'ContainingText
        <System.Diagnostics.DebuggerHidden()> Public Function HasText(ur_val As String) As Boolean
            HasText = Not String.IsNullOrWhiteSpace(ur_val)
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function Strapd() As Strap
            Strapd = New Strap
        End Function
    End Module ' ConstVar

    Public Class Dlone(Of T)
        Private vobjDATA As T
        Private vbolVAL_READY As Boolean

        <System.Diagnostics.DebuggerHidden()> Public Sub New(Optional ByVal ur_data As T = Nothing)
            Me.vobjDATA = ur_data
            Call Me.Reset()
        End Sub

        Public Shadows ReadOnly Property Current() As T
            <System.Diagnostics.DebuggerHidden()> Get
                Current = Me.vobjDATA
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()> Public Function d(ur_obj As T) As Dlone(Of T)
            d = Me
            Me.vobjDATA = ur_obj
            Call Me.Reset()
        End Function 'd

        <System.Diagnostics.DebuggerHidden()> Public Function GetEnumerator() As Dlone(Of T)
            GetEnumerator = Me
            Call Me.Reset()
        End Function

        Public ReadOnly Property v() As T
            <System.Diagnostics.DebuggerHidden()> Get
                v = Me.vobjDATA
            End Get
        End Property

        Public ReadOnly Property Found() As Boolean
            <System.Diagnostics.DebuggerHidden()> Get
                Found = (Me.vobjDATA IsNot Nothing)
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()> Public Function MoveNext() As Boolean
            MoveNext = Me.vbolVAL_READY
            Me.vbolVAL_READY = False
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function Reset() As Dlone(Of T)
            Reset = Me
            Me.vbolVAL_READY = Me.Found
        End Function
    End Class 'DLone

    Public Class RCTR
        Private vintCOUNT As Integer
        Private vintCUR_VAL As Integer

        <System.Diagnostics.DebuggerHidden()> Public Shared Widening Operator CType(ByVal b As RCTR) As Integer
            Return b.Indexb1
        End Operator 'CType

        <System.Diagnostics.DebuggerHidden()> Public Sub New(ur_len As Integer)
            Me.vintCOUNT = ur_len
        End Sub

        Public Shadows ReadOnly Property Current() As RCTR
            <System.Diagnostics.DebuggerHidden()> Get
                Current = Me
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()> Public Function GetEnumerator() As RCTR
            GetEnumerator = Me
            Call Me.Reset()
        End Function

        Public ReadOnly Property Indexb1() As Integer
            <System.Diagnostics.DebuggerHidden()> Get
                Indexb1 = Me.vintCUR_VAL
            End Get
        End Property

        Public ReadOnly Property Indexenm() As Integer
            <System.Diagnostics.DebuggerHidden()> Get
                Indexenm = b0(Me.vintCUR_VAL)
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()> Public Function MoveNext() As Boolean
            MoveNext = (Me.vintCUR_VAL < Me.vintCOUNT)
            Me.vintCUR_VAL += 1
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function Reset() As RCTR
            Reset = Me
            Me.vintCUR_VAL = 0
        End Function
    End Class 'RCTR

    Public Class SDACTR
        Inherits RCTR

        Private vsdaLIST As Sdata

        <System.Diagnostics.DebuggerHidden()> Public Sub New(ur_sdata As Sdata)
            Call MyBase.New(ur_sdata.Count)
            Me.vsdaLIST = ur_sdata
        End Sub

        Public Shadows ReadOnly Property Current() As SDACTR
            <System.Diagnostics.DebuggerHidden()> Get
                Current = Me
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()> Public Shadows Function GetEnumerator() As SDACTR
            GetEnumerator = Me
            Call Me.Reset()
        End Function

        Public Shadows ReadOnly Property v() As String
            <System.Diagnostics.DebuggerHidden()> Get
                v = Me.vsdaLIST.Item(Me.Indexenm)
            End Get
        End Property
    End Class 'SDACTR

    Public Class Sdata
        Inherits System.Collections.Generic.List(Of String)

        <System.Diagnostics.DebuggerHidden()> Public Function d(ur_val As String) As Sdata
            d = Me
            Call Me.Add(ur_val)
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function dMt(ur_count As Integer) As Sdata
            dMt = Me
            For ROWCTR = 1 To ur_count
                Call Me.Add(Mx.mt)
            Next ROWCTR
        End Function

        Public ReadOnly Property v_b1(ur_index As Integer) As String
            <System.Diagnostics.DebuggerHidden()> Get
                v_b1 = Me.Item(b0(ur_index))
            End Get
        End Property

        Public ReadOnly Property v_enm(ur_index As Integer) As String
            <System.Diagnostics.DebuggerHidden()> Get
                v_enm = Me.Item(ur_index)
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()> Public Shadows Function kvp() As SDACTR
            kvp = New SDACTR(Me)
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Shared Function Split(ur_text As String, ur_sprtr As Char) As Sdata
            Dim sdaCMP = New Sdata
            Split = sdaCMP
            For Each strTEXT In ur_text.Split(ur_sprtr)
                sdaCMP.Add(strTEXT)
            Next
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function TextList() As System.Collections.Generic.List(Of String)
            TextList = Me
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function w_b1(ur_index As Integer, ur_val As String) As Sdata
            w_b1 = Me
            Me.Item(b0(ur_index)) = ur_val
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function w_enm(ur_index As Integer, ur_val As String) As Sdata
            w_enm = Me
            Me.Item(ur_index) = ur_val
        End Function
    End Class 'Sdata

    Public Class Snlist(Of T)
        Inherits System.Collections.Generic.List(Of T)

        <System.Diagnostics.DebuggerHidden()> Public Shadows Function kvp() As SNCTR(Of T)
            kvp = New SNCTR(Of T)(Me)
        End Function
    End Class 'Snlist

    Public Class Snrow(Of T)
        Inherits Sdata

        <System.Diagnostics.DebuggerHidden()> Public Sub New()
            For Each intVAL In Me.RefParmNames
                Me.Add(mt)
            Next
        End Sub 'New

        <System.Diagnostics.DebuggerHidden()> Public Function RefParmNames() As Sdata
            RefParmNames = MxText.sdnGEN(Of T).TNames
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function IfRefParmName(ur_name As String) As Dlone(Of T)
            IfRefParmName = MxText.sdnGEN(Of T).IfRefName(ur_name)
        End Function


        Public ReadOnly Property v(ur_cl As T) As String
            <System.Diagnostics.DebuggerHidden()> Get
                v = Me.Item(DirectCast(CObj(ur_cl), Integer))
            End Get
        End Property

        Public WriteOnly Property w(ur_cl As T) As String
            <System.Diagnostics.DebuggerHidden()> Set(ur_val As String)
                Me.Item(DirectCast(CObj(ur_cl), Integer)) = ur_val
            End Set
        End Property 'w

        <System.Diagnostics.DebuggerHidden()> Public Shared Sub CommandParms_Init(ur_command_line As String, ur_row As Snrow(Of T))
            Dim objLINE = MxText.FirstSprtrSplit(ur_command_line, {"/"c}) 'System.Environment.CommandLine
            While objLINE.SearchForSprtr.Found
                objLINE = MxText.FirstSprtrSplit(objLINE.RemText, {"/"c})
                Dim objSPLIT = MxText.FirstSprtrSplit(objLINE.Key, {"="c, ":"c, " "c})
                Dim olnFOUND_KEY = ur_row.IfRefParmName(Trim(MxText.Unquote(objSPLIT.Key)).ToLower)
                If olnFOUND_KEY.Found Then
                    If objSPLIT.SearchForSprtr.Found Then
                        ur_row.w(olnFOUND_KEY.v) = MxText.Unquote(objSPLIT.RemText)
                    Else
                        ur_row.w(olnFOUND_KEY.v) = True.ToString
                    End If
                End If 'olnFOUND_KEY
            End While 'objLINE
        End Sub 'CommandParms_Init
    End Class 'Snrow

    Public Class SNCTR(Of T)
        Inherits RCTR

        Private vsdaLIST As Snlist(Of T)

        <System.Diagnostics.DebuggerHidden()> Public Sub New(ur_list As Snlist(Of T))
            Call MyBase.New(ur_list.Count)
            Me.vsdaLIST = ur_list
        End Sub

        Public Shadows ReadOnly Property Current() As SNCTR(Of T)
            <System.Diagnostics.DebuggerHidden()> Get
                Current = Me
            End Get
        End Property

        Public Shadows ReadOnly Property row() As T
            <System.Diagnostics.DebuggerHidden()> Get
                row = Me.vsdaLIST.Item(Me.Indexenm)
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()> Public Shadows Function GetEnumerator() As SNCTR(Of T)
            GetEnumerator = Me
            Call Me.Reset()
        End Function
    End Class 'SNCTR

    Public Class Strap
        Dim stpTEXT As System.Text.StringBuilder

        <System.Diagnostics.DebuggerHidden()> Public Shared Widening Operator CType(ByVal b As Strap) As String
            Return b.ToString
        End Operator 'CType

        <System.Diagnostics.DebuggerHidden()> Public Sub New()
            Me.stpTEXT = New System.Text.StringBuilder
        End Sub

        <System.Diagnostics.DebuggerHidden()> Public Function aCSV(ParamArray ur_text() As String) As Strap
            aCSV = Me
            If ur_text IsNot Nothing Then
                For Each strTEXT In ur_text
                    If Me.stpTEXT.Length > 0 Then
                        Me.stpTEXT.Append(",").Append(s)
                    End If

                    Me.stpTEXT.Append(strTEXT)
                Next strTEXT
            End If
        End Function 'aCSV

        <System.Diagnostics.DebuggerHidden()> Public Function aLine(ParamArray ur_text() As String) As Strap
            aLine = Me
            If ur_text IsNot Nothing Then
                For Each strTEXT In ur_text
                    If Me.stpTEXT.Length > 0 Then
                        Me.stpTEXT.Append(Constants.vbCrLf)
                    End If

                    Me.stpTEXT.Append(strTEXT)
                Next strTEXT
            End If
        End Function 'aLine

        <System.Diagnostics.DebuggerHidden()> Public Function Clear() As Strap
            Clear = Me
            Call Me.stpTEXT.Clear()
        End Function 'aLine

        <System.Diagnostics.DebuggerHidden()> Public Function d(ParamArray ur_text() As String) As Strap
            d = Me
            If ur_text IsNot Nothing Then
                For Each strTEXT In ur_text
                    Me.stpTEXT.Append(strTEXT)
                Next strTEXT
            End If
        End Function 'd

        <System.Diagnostics.DebuggerHidden()> Public Function dS(ParamArray ur_text() As String) As Strap
            dS = Me
            If ur_text IsNot Nothing Then
                For Each strTEXT In ur_text
                    Me.stpTEXT.Append(s & strTEXT)
                Next strTEXT
            End If
        End Function 'dS

        Public ReadOnly Property HasText() As Boolean
            <System.Diagnostics.DebuggerHidden()> Get
                HasText = (Me.stpTEXT.Length > 0)
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()> Public Function r(ur_suf As Integer, ur_text As String) As Strap
            r = Me
            Call Me.stpTEXT.Replace("@r" & ur_suf.ToString, ur_text)
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Function Wrap(ur_text As String) As Strap
            Wrap = Me
            Call Me.stpTEXT.Clear()
            Me.stpTEXT.Append(ur_text)
        End Function

        <System.Diagnostics.DebuggerHidden()> Public Shadows Function ToString() As String
            ToString = Me.stpTEXT.ToString
        End Function
    End Class 'Strap

    Partial Public Class MxText 'Cmd
        Public Class sdnGEN(Of T)
            Private Shared objEVNAME As Sdata

            <System.Diagnostics.DebuggerHidden()> Private Shared Sub Init()
                If objEVNAME Is Nothing Then
                    objEVNAME = New Sdata
                    For Each intVAL In System.Enum.GetValues(GetType(T))
                        Dim intCAST = DirectCast(CObj(intVAL), T)
                        objEVNAME.Add(intVAL.ToString.ToLower)
                    Next
                End If 'objEVNAME
            End Sub 'Init

            <System.Diagnostics.DebuggerHidden()> Public Shared Function TNames() As Sdata
                Call Init()
                TNames = sdnGEN(Of T).objEVNAME
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Shared Function IfRefName(ur_key As String) As Dlone(Of T)
                Dim olnPARM = New Dlone(Of T)
                IfRefName = olnPARM
                Dim intINDEX = MxText.sdnGEN(Of eprCL).TNames.IndexOf(ur_key)
                If intINDEX >= 0 Then
                    olnPARM.d(DirectCast(CObj(intINDEX), T))
                End If
            End Function 'IfRefName
        End Class 'sdnGEN

        <System.Diagnostics.DebuggerHidden()> Public Shared Function CmdOutput(ur_exec_path As String, Optional ur_exec_param As String = mt) As String
            Dim P As New System.Diagnostics.Process()
            With 1 : Dim prcINFO = P.StartInfo
                prcINFO.FileName = ur_exec_path
                prcINFO.Arguments = ur_exec_param
                prcINFO.UseShellExecute = False
                prcINFO.RedirectStandardOutput = True
                prcINFO.CreateNoWindow = True
            End With 'prcINFO

            P.Start()
            CmdOutput = P.StandardOutput.ReadToEnd()
            P.WaitForExit()
        End Function 'CmdOutput

        Public Class ResultSplit
            Public Key As String
            Public RemText As String
            Public SearchForSprtr As Dlone(Of String)
            <System.Diagnostics.DebuggerHidden()> Public Sub New()
                Me.SearchForSprtr = New Dlone(Of String)
            End Sub 'New
        End Class 'ResultSplit

        <System.Diagnostics.DebuggerHidden()> Public Shared Function FirstSprtrSplit(ur_line As String, ur_separator() As Char) As ResultSplit
            Dim sdaCMP = New MxText.ResultSplit
            sdaCMP.SearchForSprtr = New Dlone(Of String)
            FirstSprtrSplit = sdaCMP
            Dim arrCHAR = ur_line.ToCharArray
            Dim intPARSE_STATE = prv.enmSPRTR_STATE.start
            Dim intLAST_CHAR = UBound(arrCHAR)
            For CHRCTR = 0 To intLAST_CHAR
                Dim curCHR = arrCHAR(CHRCTR)
                Select Case intPARSE_STATE
                    Case prv.enmSPRTR_STATE.start
                        Dim bolANY_SPRTR_MATCH = False
                        For Each curSPRTR In ur_separator
                            If curCHR = curSPRTR Then
                                bolANY_SPRTR_MATCH = True
                                Exit For
                            End If 'objCHR
                        Next curSPRTR

                        If bolANY_SPRTR_MATCH Then
                            Dim intSPRTR_AT = b1(CHRCTR)
                            sdaCMP.RemText = Trim(Mid(ur_line, intSPRTR_AT + 1))
                            If curCHR = s AndAlso
                               HasText(sdaCMP.RemText) Then
                                Dim nxtCHR = CChar(Left(sdaCMP.RemText, 1))
                                Dim bolANY_SECOND_SPRTR_MATCH = False
                                For Each curSPRTR In ur_separator
                                    If curSPRTR <> curCHR AndAlso
                                       curSPRTR = nxtCHR Then
                                        bolANY_SECOND_SPRTR_MATCH = True
                                        Exit For
                                    End If 'curSPRTR
                                Next curSPRTR

                                If bolANY_SECOND_SPRTR_MATCH Then
                                    curCHR = nxtCHR
                                    sdaCMP.RemText = Trim(Mid(sdaCMP.RemText, 2))
                                End If
                            End If 'curCHR

                            sdaCMP.Key = Trim(Mid(ur_line, 1, intSPRTR_AT - 1))
                            sdaCMP.SearchForSprtr.d(curCHR)
                            Exit For

                        Else 'bolANY_SPRTR_MATCH
                            If curCHR = qs Then
                                intPARSE_STATE = prv.enmSPRTR_STATE.in_quotes
                            End If
                        End If 'objCHR

                    Case prv.enmSPRTR_STATE.in_quotes
                        If curCHR = qs Then
                            intPARSE_STATE = prv.enmSPRTR_STATE.start
                            Dim intNEXT_IX = CHRCTR + 1
                            If intNEXT_IX < intLAST_CHAR Then
                                If arrCHAR(intNEXT_IX) = qs Then
                                    intPARSE_STATE = prv.enmSPRTR_STATE.escaped_dbl_sprtr
                                End If 'intNEXT_IX
                            End If 'intNEXT_IX
                        End If 'objCHR

                    Case prv.enmSPRTR_STATE.escaped_dbl_sprtr
                        intPARSE_STATE = prv.enmSPRTR_STATE.in_quotes
                End Select 'intPARSE_STATE
            Next CHRCTR

            If sdaCMP.SearchForSprtr.Found = False Then
                sdaCMP.Key = ur_line
            End If 'sdaCMP
        End Function 'FirstSprtrSplit

        <System.Diagnostics.DebuggerHidden()> Public Shared Function Unquote(ur_line As String, Optional ur_sprtr As String = qs) As Strap
            Dim stpRET As New Strap
            Unquote = stpRET
            Dim arrCHAR = ur_line.ToCharArray
            Dim intPARSE_FROM = prv.enmSPRTR_STATE.start
            Dim intLAST_CHAR = UBound(arrCHAR)
            For CHRCTR = 0 To intLAST_CHAR
                Dim curCHAR = arrCHAR(CHRCTR)
                Select Case intPARSE_FROM
                    Case prv.enmSPRTR_STATE.start
                        If curCHAR = ur_sprtr Then
                            intPARSE_FROM = prv.enmSPRTR_STATE.in_quotes

                        Else 'objCHR
                            stpRET.d(curCHAR)
                        End If 'objCHR

                    Case prv.enmSPRTR_STATE.in_quotes
                        If curCHAR = ur_sprtr Then
                            intPARSE_FROM = prv.enmSPRTR_STATE.start
                            If CHRCTR < intLAST_CHAR AndAlso
                               arrCHAR(CHRCTR + 1) = ur_sprtr Then
                                intPARSE_FROM = prv.enmSPRTR_STATE.escaped_dbl_sprtr
                            End If

                        Else 'objCHR
                            stpRET.d(curCHAR)
                        End If

                    Case prv.enmSPRTR_STATE.escaped_dbl_sprtr
                        stpRET.d(curCHAR)
                        intPARSE_FROM = prv.enmSPRTR_STATE.in_quotes
                End Select 'intPARSE_STATE
            Next CHRCTR
        End Function 'Unquote

        <System.Diagnostics.DebuggerHidden()> Public Shared Function FirstWord(ur_word As String) As String
            FirstWord = ur_word.Split(CChar(s))(0)
        End Function 'FirstWord

        <System.Diagnostics.DebuggerHidden()> Public Shared Function LastWord(ur_word As String) As String
            Dim arrCMP = ur_word.Split(CChar(s))
            LastWord = arrCMP(b0(arrCMP.Length))
        End Function 'LastWord

        <System.Diagnostics.DebuggerHidden()> Public Shared Function StrMult(ur_word As String, ur_len As Integer) As String
            StrMult = Space(ur_len).Replace(s, ur_word)
        End Function 'StrMult

        <System.Diagnostics.DebuggerHidden()> Public Shared Function SQLQT(ur_text As String) As String
            SQLQT = qt & ur_text.Replace(qt, qt & qt) & qt
        End Function

        Private Class prv
            Public Enum enmSPRTR_STATE
                start
                escaped_dbl_sprtr
                in_quotes
            End Enum 'enmSPRTR_STATE
        End Class 'prv
    End Class 'MxText-Cmd

    Partial Public Class MxText 'Csv
        <System.Diagnostics.DebuggerHidden()> Public Shared Function CSVSplit(ByVal ur_line As String, Optional ur_separator As String = ",") As Sdata
            Dim sdaCMP = New Sdata
            CSVSplit = sdaCMP
            Dim objARRAY = ur_line.ToCharArray
            Dim objSPRTR = Mid(ur_separator, 1, 1).ToCharArray()(0)
            Dim objESCAPE_QUOTE = """"c

            Const cstSTART = 0
            Const cstESC = 1
            Const cstQS = 2
            Dim intPARSE_STATE = cstSTART
            Dim intLEN = Len(ur_line) - 1
            Dim stpFIELD As New Strap
            For intIX = 0 To intLEN
                Dim objCHR = objARRAY(intIX)
                Select Case intPARSE_STATE
                    Case cstESC
                        stpFIELD.d(objCHR)
                        intPARSE_STATE = cstQS

                    Case cstQS
                        If objCHR = objESCAPE_QUOTE Then
                            intPARSE_STATE = cstSTART
                            Dim intNEXT_IX = intIX + 1
                            If intNEXT_IX < intLEN Then
                                If objARRAY(intNEXT_IX) = objESCAPE_QUOTE Then
                                    intPARSE_STATE = cstESC
                                End If 'intNEXT_IX
                            End If 'intNEXT_IX

                        Else 'objCHR
                            stpFIELD.d(objCHR)
                        End If 'objCHR

                    Case cstSTART
                        If objCHR = objSPRTR Then
                            sdaCMP.d(stpFIELD.ToString)
                            Call stpFIELD.Clear()

                        ElseIf objCHR = objESCAPE_QUOTE Then
                            intPARSE_STATE = cstQS

                        Else 'objCHR
                            stpFIELD.d(objCHR)
                        End If 'objCHR
                End Select 'intPARSE_STATE
            Next intIX

            sdaCMP.d(stpFIELD)
        End Function 'CSVSplit
    End Class 'MxText-Csv

    Partial Public Class MxText 'File
        Public Class FileName
            Public FilePath As String
            <System.Diagnostics.DebuggerHidden()> Public Sub New()
                Me.FilePath = mt
            End Sub 'New

            <System.Diagnostics.DebuggerHidden()> Public Shared Widening Operator CType(b As FileName) As String
                Return b.FilePath
            End Operator 'CType
            <System.Diagnostics.DebuggerHidden()> Public Shared Widening Operator CType(b As String) As FileName
                Return New FileName().Wrap(b)
            End Operator 'CType
            <System.Diagnostics.DebuggerHidden()> Public Shadows Function ToString() As String
                ToString = Me.FilePath
            End Function 'ToString

            <System.Diagnostics.DebuggerHidden()> Public Function dAppendEXT(ur_ext As String) As FileName
                dAppendEXT = Me
                If ur_ext.StartsWith(".") = False Then
                    ur_ext = "." & ur_ext
                End If

                Me.FilePath &= ur_ext
            End Function 'dAppendEXT

            <System.Diagnostics.DebuggerHidden()> Public Function d(ur_file_name As String) As FileName
                d = Me
                If HasText(Me.FilePath) Then
                    Me.FilePath = System.IO.Path.Combine(Me.FilePath, ur_file_name)

                Else 'Me
                    Me.FilePath = ur_file_name
                End If 'Me
            End Function 'd

            <System.Diagnostics.DebuggerHidden()> Public Function dName(ur_file As FileName) As FileName
                dName = Me
                If ur_file IsNot Nothing Then
                    Me.d(ur_file.Name)
                End If 'ur_file
            End Function 'dName

            <System.Diagnostics.DebuggerHidden()> Public Function dNowTextYMDHMS() As FileName
                dNowTextYMDHMS = Me
                Me.FilePath &= "_" & Now().ToString("yyyy\mMM\dddthh\mmm\sss").Replace("P12", "N12").Replace("A12", "A00").ToLower
            End Function 'dNowTextYMDHMS

            <System.Diagnostics.DebuggerHidden()> Public Function Ext() As String
                Ext = System.IO.Path.GetExtension(Me.FilePath)
            End Function 'Ext

            <System.Diagnostics.DebuggerHidden()> Public Function ExtAll() As String
                ExtAll = Strapd().d(Me.ExtList.ToArray)
            End Function 'ExtAll

            <System.Diagnostics.DebuggerHidden()> Public Function ExtList() As Sdata
                Dim sdaDESC = Sdata.Split(Me.FilePath, "."c)
                ExtList = sdaDESC
                sdaDESC.RemoveAt(0)
                For Each kvpENTRY In sdaDESC.kvp
                    sdaDESC.Item(kvpENTRY.Indexenm) = "." & kvpENTRY.v
                Next kvpENTRY
            End Function 'ExtList

            <System.Diagnostics.DebuggerHidden()> Public Function FileGroup() As String
                FileGroup = System.IO.Path.GetFileNameWithoutExtension(Me.FilePath)
            End Function 'FileGroup

            <System.Diagnostics.DebuggerHidden()> Public Function FileBaseGroup() As String
                FileBaseGroup = mt
                For Each strENTRY In Sdata.Split(Me.Name, "."c)
                    FileBaseGroup = strENTRY
                    Exit For
                Next
            End Function 'FileBaseGroup

            <System.Diagnostics.DebuggerHidden()> Public Function Copy() As FileName
                Copy = New FileName().Wrap(Me)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function Name() As String
                Name = mt
                Dim strPATH = Me.FilePath
                If HasText(strPATH) Then
                    If HasText(System.IO.Path.GetFileName(strPATH)) = False Then
                        strPATH = System.IO.Path.GetDirectoryName(strPATH)
                    End If 'strPATH
                End If

                If HasText(strPATH) Then
                    Name = System.IO.Path.GetFileName(strPATH)
                End If
            End Function 'Name

            <System.Diagnostics.DebuggerHidden()> Public Function ParentDir() As FileName
                Dim flnRET = New FileName()
                ParentDir = flnRET
                Dim strPATH = Me.FilePath
                If HasText(strPATH) Then
                    If HasText(System.IO.Path.GetFileName(strPATH)) = False Then
                        strPATH = System.IO.Path.GetDirectoryName(strPATH)
                    End If 'strPATH
                End If 'strPATH

                If HasText(strPATH) Then
                    flnRET.d(System.IO.Path.GetDirectoryName(strPATH))
                End If 'strPATH
            End Function 'ParentDir

            <System.Diagnostics.DebuggerHidden()> Public Function ParentList() As System.Collections.Generic.List(Of FileName)
                Dim sdaPATH = Me.PathList
                ParentList = sdaPATH
                sdaPATH.RemoveAt(b0(sdaPATH.Count))
            End Function 'ParentList

            <System.Diagnostics.DebuggerHidden()> Public Function PathList() As System.Collections.Generic.List(Of FileName)
                Dim sdaPATH As New System.Collections.Generic.List(Of FileName)
                PathList = sdaPATH

                Dim lstDESC As New System.Collections.Generic.List(Of FileName)
                lstDESC.Add(Me.Copy)
                Dim objREDUCE = Me.ParentDir()
                While HasText(objREDUCE.FilePath)
                    lstDESC.Add(objREDUCE.Copy)
                    objREDUCE = Me.ParentDir
                End While 'objREDUCE

                For Each strENTRY In lstDESC
                    sdaPATH.Add(strENTRY)
                Next strENTRY
            End Function 'PathList

            <System.Diagnostics.DebuggerHidden()> Public Function wAssemblyDir(ur_assembly_info As Microsoft.VisualBasic.ApplicationServices.AssemblyInfo) As FileName
                wAssemblyDir = Me
                Me.FilePath = ur_assembly_info.DirectoryPath.Replace("\bin\Debug", mt)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function wEXT(ur_ext As String) As FileName
                wEXT = Me
                Dim strFILE_NAME = Me.FileGroup
                If Left(ur_ext, 1) <> "." Then
                    ur_ext = "." & ur_ext
                End If 'ur_ext

                Me.Wrap(Me.ParentDir).d(strFILE_NAME & ur_ext)
            End Function 'wEXT

            <System.Diagnostics.DebuggerHidden()> Public Function wFileBaseGroup(ur_val As String) As FileName
                wFileBaseGroup = Me
                Me.wName(ur_val & Me.ExtAll)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function wFileGroup(ur_val As String) As FileName
                wFileGroup = Me
                Me.wName(ur_val & Me.Ext)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function wName(ur_val As String) As FileName
                wName = Me
                Me.Wrap(Me.ParentDir).d(ur_val)
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function wParentDir(ur_val As String) As FileName
                wParentDir = Me
                Dim strFILE_NAME = Me.Name
                If HasText(ur_val) Then
                    Me.FilePath = System.IO.Path.Combine(ur_val, strFILE_NAME)

                Else 'value
                    Me.FilePath = strFILE_NAME
                End If 'value
            End Function

            <System.Diagnostics.DebuggerHidden()> Public Function Wrap(ur_path As String) As FileName
                Wrap = Me
                Me.FilePath = mt
                Call Me.d(ur_path)
            End Function 'Wrap

            <System.Diagnostics.DebuggerHidden()> Public Function Wrap(ur_path As FileName) As FileName
                Wrap = Me
                If ur_path IsNot Nothing Then
                    Me.FilePath = ur_path.FilePath

                Else 'ur_file
                    Me.FilePath = mt
                End If 'ur_file
            End Function 'Wrap

            <System.Diagnostics.DebuggerHidden()> Public Function wTempFileName(ur_fs_proxy As Microsoft.VisualBasic.MyServices.FileSystemProxy) As FileName
                wTempFileName = Me
                Me.FilePath = ur_fs_proxy.GetTempFileName
                Call ur_fs_proxy.DeleteFile(Me.FilePath)
            End Function 'wTempFileName
        End Class 'FileName

        Public Shared Function Std_FileEncoding() As System.Text.UTF8Encoding
            Std_FileEncoding = New System.Text.UTF8Encoding(encoderShouldEmitUTF8Identifier:=False, throwOnInvalidBytes:=True)
        End Function
    End Class 'MxText-File
End Namespace 'Mx
