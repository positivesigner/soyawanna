-Relpace ":C" with the last column of data
-A1:C1
-A2:C2
-Replace "D$" with the first column of CSE formulas
-D$1
- row one second blank column
="IF OBJECT_ID('TempDb..#tbTEST') IS NOT NULL BEGIN  DROP TABLE #tbTEST  END  SELECT CONVERT(NVARCHAR(MAX),'') AS "&TEXTJOIN(", CONVERT(NVARCHAR(MAX),'') AS ",FALSE,SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(A1:C1,"'","_qt_")," ","_"),"[","_br_"),"]","_bc_"),"/","_fslash"),"\","_bslash"))&" INTO #tbTEST WHERE 0 IS NULL"
" row one first blank column
="INSERT INTO #tbTEST ("&TEXTJOIN(", ",FALSE,SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(A1:C1,"'","_qt_")," ","_"),"[","_br_"),"]","_bc_"),"/","_fslash"),"\","_bslash"))&") VALUES"
" row two and down, firts blank column
=IF(MOD(ROW(),500)=2,D$1,",")&"('"&TEXTJOIN("','",FALSE,SUBSTITUTE(A2:C2,"'","''"))&"')"
- row one third blank column
="UPDATE ttbTEST SET "&TEXTJOIN(", ",FALSE,SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(A1:C1,"'","_qt_")," ","_"),"[","_br_"),"]","_bc_"),"/","_fslash"),"\","_bslash")&" = NULLIF("&SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(A1:C1,"'","_qt_")," ","_"),"[","_br_"),"]","_bc_"),"/","_fslash"),"\","_bslash")&",'')")&" FROM #tbTEST ttbTEST"
' check for issues
SELECT 'duplicate primary key' AS notice_msg, ttbTEST.Unit, ttbTEST.Item
FROM #tbTEST ttbTEST
GROUP BY ttbTEST.Unit, ttbTEST.Item
HAVING COUNT(1) > 1
- pull desired record
SELECT
	'x'AS spreadsheet_rec,
	 ttbTEST.Unit,
	  ttbTEST.Item AS sprsh_item,
	'x' AS fs_unit_rec,
	 fs_unit.ser_num,
	  fs_unit.item,
	fs_unit.stat
  FROM
	#tbTEST ttbTEST LEFT JOIN fs_unit ON
		fs_unit.ser_num = ttbTEST.Unit AND
		fs_unit.item = ttbTEST.Item
  ORDER BY
	unit,
	 sprsh_item
