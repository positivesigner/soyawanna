﻿Option Strict On
Namespace Mx
    Public Class subs
        Public Shared Sub Main(ur_startup_event As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs)
            Dim objERR_LIST = New ErrListBase : Try
                Call sln.RsrcCompile.TestReferencedAssemblies()
                'Next goes to frmInput_1_Load, then Proc_Exec

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                MsgBox(objERR_LIST.ToString, , My.Application.Info.Title)
                ur_startup_event.Cancel = True
            End If
        End Sub 'Main

        Public Shared Sub Proc_Exec(ur_form As frmInput_1, ur_command_text As String)
            Dim objERR_LIST = New ErrListBase : Try
                'List what resources to find
                Dim trwCPARM = New sln.CommandRow(ur_command_text)
                'Compile what resources you have
                Dim objFORM = New sln.FormCompile(ur_form)
                Dim flnINPUT_SCRIPT = sln.RsrcCompile.gInput_Script(trwCPARM)
                Dim stpOUTPUT_RESULT = sln.RsrcCompile.gOutput_Result(flnINPUT_SCRIPT)
                'Create output you want
                Call sln.ProcCompile.Format_FormTitle(objFORM.gWindowTitle, trwCPARM)
                Call sln.ProcCompile.Format_FormResult(objFORM.gNoticeMessage, objFORM.gWindowColor, objFORM.gWindowAction, stpOUTPUT_RESULT)

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                MsgBox(objERR_LIST.ToString, , My.Application.Info.Title)
                Call ur_form.Close()
            End If
        End Sub 'Input_Init
    End Class 'subs


    Public Class sln
        Public Enum enmCParm
            path
        End Enum 'enmCParm

        Public Class CommandRow
            Inherits TRow(Of enmCParm)

            <System.Diagnostics.DebuggerHidden()> Public Sub New(ur_command_parms As String)
                For Each kvpENTRY In MxText.CmdRow(Of enmCParm).Parse_Input(ur_command_parms).kvp
                    Me.v_enm(kvpENTRY.Indexenm) = kvpENTRY.v
                Next kvpENTRY

                If HasText(Me.v(enmCParm.path)) = False Then
                    For Each kvpENTRY In MxText.Parse_Quotes(ur_command_parms).kvp
                        Me.v_enm(kvpENTRY.Indexenm) = kvpENTRY.v
                    Next kvpENTRY
                End If 'Me
            End Sub 'New
        End Class 'CommandRow

        Public Class FormCompile
            Private pobjFORM As frmInput_1

            Public Sub New(ur_form As frmInput_1)
                Me.pobjFORM = ur_form
            End Sub

            Public Function gNoticeMessage() As NoticeMessage
                gNoticeMessage = New NoticeMessage(Me.pobjFORM.TextBox1)
            End Function

            Public Function gWindowAction() As WindowAction
                gWindowAction = New WindowAction(Me)
            End Function

            Public Function gWindowColor() As WindowColor
                gWindowColor = New WindowColor(Me)
            End Function

            Public Function gWindowTitle() As WindowTitle
                gWindowTitle = New WindowTitle(Me)
            End Function

            Public Property BackColor As Color
                Get
                    BackColor = pobjFORM.BackColor
                End Get
                Set(ur_val As Color)
                    pobjFORM.BackColor = ur_val
                End Set
            End Property 'BackColor

            Public Sub Close()
                Me.pobjFORM.Close()
            End Sub

            Public Property Text As String
                Get
                    Text = pobjFORM.Text
                End Get
                Set(ur_val As String)
                    pobjFORM.Text = ur_val
                End Set
            End Property 'Text

            Public Class NoticeMessage
                Private pobjTEXT_BOX As TextBox

                Public Sub New(ur_textbox As TextBox)
                    Me.pobjTEXT_BOX = ur_textbox
                End Sub

                Public Property Text As String
                    Get
                        Text = pobjTEXT_BOX.Text
                    End Get
                    Set(ur_val As String)
                        pobjTEXT_BOX.Text = ur_val
                    End Set
                End Property 'Text
            End Class 'NoticeMessage

            Public Class WindowAction
                Private pobjFORM As FormCompile

                Public Sub New(ur_form As FormCompile)
                    Me.pobjFORM = ur_form
                End Sub

                Public Sub Close()
                    Call Me.pobjFORM.Close()
                End Sub
            End Class 'WindowAction

            Public Class WindowColor
                Private pobjFORM As FormCompile

                Public Sub New(ur_form As FormCompile)
                    Me.pobjFORM = ur_form
                End Sub

                Public Property BackColor As Color
                    Get
                        BackColor = Me.pobjFORM.BackColor
                    End Get
                    Set(ur_val As Color)
                        pobjFORM.BackColor = ur_val
                    End Set
                End Property 'BackColor
            End Class 'WindowColor

            Public Class WindowTitle
                Private pobjFORM As FormCompile

                Public Sub New(ur_form As FormCompile)
                    Me.pobjFORM = ur_form
                End Sub

                Public Property Text As String
                    Get
                        Text = Me.pobjFORM.Text
                    End Get
                    Set(ur_val As String)
                        Me.pobjFORM.Text = ur_val
                    End Set
                End Property 'Text
            End Class 'WindowTitle
        End Class 'FormCompile

        Public Class ProcCompile
            Public Shared Sub Format_FormResult(ur_notice_msg As FormCompile.NoticeMessage, ur_window_color As FormCompile.WindowColor, ur_window_action As FormCompile.WindowAction, ur_output_result As Strap)
                Dim flgSHOW_FORM = True
                ur_notice_msg.Text = ur_output_result
                If StartingWithText(ur_notice_msg.Text.Trim, "Quit") Then
                    flgSHOW_FORM = False
                End If

                If StartingWithText(ur_notice_msg.Text, "RED") Then
                    ur_window_color.BackColor = Color.Red

                ElseIf StartingWithText(ur_notice_msg.Text.Trim, "GREEN") Then
                    ur_window_color.BackColor = Color.Green
                End If

                If flgSHOW_FORM = False Then
                    Call ur_window_action.Close()
                End If
            End Sub 'Format_FormResult

            Public Shared Sub Format_FormTitle(ur_window_title As FormCompile.WindowTitle, ur_cparm_list As CommandRow)
                ur_window_title.Text = ur_cparm_list.v(enmCParm.path)
            End Sub
        End Class 'ProcCompile

        Public Class RsrcCompile
            Public Shared Sub TestReferencedAssemblies()
                'Will error if DLL does is not available
                Dim objV1 = System.Data.SqlClient.SortOrder.Ascending
            End Sub 'TestReferencedAssemblies

            Public Shared Function gInput_Script(ur_cparm_list As CommandRow) As MxText.FileName
                Dim flnRET = New MxText.FileName
                gInput_Script = flnRET
                flnRET.Wrap(ur_cparm_list.v(enmCParm.path))
                If System.IO.File.Exists(flnRET) = False Then
                    flnRET.Wrap(mt)
                End If
            End Function 'gInput_Script

            Public Shared Function gOutput_Result(ur_input_script As MxText.FileName) As Strap
                Dim stpRET = Strapd()
                gOutput_Result = stpRET
                If HasText(ur_input_script) Then
                    stpRET.d(Mx.ScriptRun.RunCode(Mx.ScriptRun.enmC_V_J.VisualBasic, ur_input_script))
                Else
                    stpRET.d("No source code file provided.")
                End If
            End Function 'gOutput_Result
        End Class 'RsrcCompile
    End Class 'sln
End Namespace 'Mx