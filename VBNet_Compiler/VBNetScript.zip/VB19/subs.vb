﻿Option Strict On
Namespace Mx
    Public Class subs
        Public Shared Sub Main(ur_startup_event As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs)
            Dim objERR_LIST = New ErrListBase : Try
                Call Want.RsrcCompile.TestReferencedAssemblies()
                'Next goes to frmInput_1_Load, then Proc_Exec

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                MsgBox(objERR_LIST.ToString, , My.Application.Info.Title)
                ur_startup_event.Cancel = True
            End If
        End Sub 'Main
    End Class 'subs


    Public Class Want
        Public Shared Sub Proc_Exec(ur_form As frmInput_1, ur_command_text As String)
            Dim objERR_LIST = New ErrListBase : Try
                Dim objFORM = New Want.FormCompile(ur_form)
                Have.FileScript_Search_FromGlobal(db.UserBowl.SelKey(enmUN.path), objFORM.gWindowTitle)
                Use.FileScript_Execute(db.UserBowl.SelKey(enmUN.path), db.UserBowl)
                Want.ProcCompile.Format_FormResult(objFORM.gNoticeMessage, objFORM.gWindowColor, objFORM.gWindowAction, db.UserBowl.SelKey(enmUN.to_userform))

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                MsgBox(objERR_LIST.ToString, , My.Application.Info.Title)
                Call ur_form.Close()
            End If
        End Sub 'Proc_Exec


        Public Class FormCompile
            Private pobjFORM As frmInput_1

            Public Sub New(ur_form As frmInput_1)
                Me.pobjFORM = ur_form
            End Sub

            Public Function gNoticeMessage() As NoticeMessage
                gNoticeMessage = New NoticeMessage(Me.pobjFORM.TextBox1)
            End Function

            Public Function gWindowAction() As WindowAction
                gWindowAction = New WindowAction(Me)
            End Function

            Public Function gWindowColor() As WindowColor
                gWindowColor = New WindowColor(Me)
            End Function

            Public Function gWindowTitle() As WindowTitle
                gWindowTitle = New WindowTitle(Me)
            End Function

            Public Property BackColor As Color
                Get
                    BackColor = pobjFORM.BackColor
                End Get
                Set(ur_val As Color)
                    pobjFORM.BackColor = ur_val
                End Set
            End Property 'BackColor

            Public Sub Close()
                Me.pobjFORM.Close()
            End Sub

            Public Property Text As String
                Get
                    Text = pobjFORM.Text
                End Get
                Set(ur_val As String)
                    pobjFORM.Text = ur_val
                End Set
            End Property 'Text

            Public Class NoticeMessage
                Private pobjTEXT_BOX As TextBox

                Public Sub New(ur_textbox As TextBox)
                    Me.pobjTEXT_BOX = ur_textbox
                End Sub

                Public Property Text As String
                    Get
                        Text = pobjTEXT_BOX.Text
                    End Get
                    Set(ur_val As String)
                        pobjTEXT_BOX.Text = ur_val
                    End Set
                End Property 'Text
            End Class 'NoticeMessage

            Public Class WindowAction
                Private pobjFORM As FormCompile

                Public Sub New(ur_form As FormCompile)
                    Me.pobjFORM = ur_form
                End Sub

                Public Sub Close()
                    Call Me.pobjFORM.Close()
                End Sub
            End Class 'WindowAction

            Public Class WindowColor
                Private pobjFORM As FormCompile

                Public Sub New(ur_form As FormCompile)
                    Me.pobjFORM = ur_form
                End Sub

                Public Property BackColor As Color
                    Get
                        BackColor = Me.pobjFORM.BackColor
                    End Get
                    Set(ur_val As Color)
                        pobjFORM.BackColor = ur_val
                    End Set
                End Property 'BackColor
            End Class 'WindowColor

            Public Class WindowTitle
                Private pobjFORM As FormCompile

                Public Sub New(ur_form As FormCompile)
                    Me.pobjFORM = ur_form
                End Sub

                Public Property Text As String
                    Get
                        Text = Me.pobjFORM.Text
                    End Get
                    Set(ur_val As String)
                        Me.pobjFORM.Text = ur_val
                    End Set
                End Property 'Text
            End Class 'WindowTitle
        End Class 'FormCompile

        Public Class ProcCompile
            Public Shared Sub Format_FormResult(ur_notice_msg As FormCompile.NoticeMessage, ur_window_color As FormCompile.WindowColor, ur_window_action As FormCompile.WindowAction, ur_output_result As db.rUserBowl)
                Dim flgSHOW_FORM = True
                ur_notice_msg.Text = ur_output_result.v(enmUB.contents)
                If StartingWithText(ur_notice_msg.Text.Trim, "Quit") Then
                    flgSHOW_FORM = False
                End If

                If StartingWithText(ur_notice_msg.Text, "RED") Then
                    ur_window_color.BackColor = Color.Red

                ElseIf StartingWithText(ur_notice_msg.Text.Trim, "GREEN") Then
                    ur_window_color.BackColor = Color.Green
                End If

                If flgSHOW_FORM = False Then
                    Call ur_window_action.Close()
                End If
            End Sub 'Format_FormResult
        End Class 'ProcCompile

        Public Class RsrcCompile
            Public Shared Sub TestReferencedAssemblies()
                'Will error if DLL does is not available
                Dim objV1 = System.Data.SqlClient.SortOrder.Ascending
            End Sub 'TestReferencedAssemblies

            Public Shared Function gOutput_Result(ur_input_script As MxText.FileName) As Strap
                Dim stpRET = Strapd()
                gOutput_Result = stpRET
                If HasText(ur_input_script) AndAlso
                   System.IO.File.Exists(ur_input_script) Then
                    stpRET.d(Mx.ScriptRun.RunCode(Mx.ScriptRun.enmC_V_J.VisualBasic, ur_input_script))
                Else
                    stpRET.d("No source code file provided.")
                End If
            End Function 'gOutput_Result
        End Class 'RsrcCompile
    End Class 'Want


    Public Class Have
        Public Shared Sub FileScript_Search_FromGlobal(ur_file_path As db.rUserBowl, ur_window_title As Want.FormCompile.WindowTitle)
            Dim strFOUND_PATH = ur_file_path.v(enmUB.contents)
            If HasText(strFOUND_PATH) AndAlso
              System.IO.File.Exists(strFOUND_PATH) Then
                ur_window_title.Text = strFOUND_PATH

            Else
                Throw New System.Exception("File Script not found: " & strFOUND_PATH)
            End If
        End Sub 'InText_Search_FromGlobal
    End Class 'Have


    Public Class Use
        Public Shared Sub FileScript_Execute(ur_file_path As db.rUserBowl, ur_bowl_table As db.sUserBowl)
            ur_bowl_table.InsKey(enmUN.to_userform, Mx.ScriptRun.RunCode(Mx.ScriptRun.enmC_V_J.VisualBasic, ur_file_path.v(enmUB.contents)))
        End Sub 'FileScript_Execute
    End Class 'Use


    Partial Public Class db
        Private Shared tblUserBowl As sUserBowl

        <System.Diagnostics.DebuggerHidden()>
        Private Shared Sub Connect()
            If db.tblUserBowl Is Nothing Then
                db.tblUserBowl = New sUserBowl
            End If 'sdaTCOL_NAME
        End Sub 'Connect

        Partial Private Class prv
            Public Class bitCT
                Inherits bitBASE
            End Class

            Public Class enmCT
                Public Shared eq As bitCT = TRow(Of bitCT, enmCT).glbl.NewBitBase()
                Public Shared fslash As bitCT = TRow(Of bitCT, enmCT).glbl.NewBitBase()
                Public Shared qs As bitCT = TRow(Of bitCT, enmCT).glbl.NewBitBase()
                Public Shared txt As bitCT = TRow(Of bitCT, enmCT).glbl.NewBitBase()
                Public Shared ws As bitCT = TRow(Of bitCT, enmCT).glbl.NewBitBase()
            End Class

            Public Shared Function CommandLine_Chunk(ur_source_text As String) As Sdata
                Dim retCHUNK = New Sdata
                CommandLine_Chunk = retCHUNK
                For CHRCTR = 0 To ur_source_text.Length - 1
                    Dim chrC = ur_source_text(CHRCTR)
                    Dim intCHUNK_C = gChunkType(chrC)
                    Dim intSPAN = 1
                    For SPNCTR = CHRCTR + 1 To ur_source_text.Length - 1
                        Dim chrS = ur_source_text(SPNCTR)
                        If gChunkType(chrS) IsNot intCHUNK_C Then
                            intSPAN = SPNCTR - CHRCTR
                            Exit For
                        End If

                        If SPNCTR = ur_source_text.Length Then
                            intSPAN = SPNCTR + 1 - CHRCTR
                            Exit For
                        End If
                    Next SPNCTR

                    retCHUNK.d(ur_source_text.Substring(CHRCTR, intSPAN))
                    CHRCTR += intSPAN - 1
                Next CHRCTR
            End Function 'CommandLine_Chunk

            Public Shared Function gChunkType(ur_char As Char) As bitCT
                If ur_char = vbCr OrElse
                  ur_char = vbLf OrElse
                  ur_char = " "c OrElse
                  ur_char = vbTab Then
                    gChunkType = enmCT.ws

                ElseIf ur_char = "="c OrElse
                  ur_char = ":"c Then
                    gChunkType = enmCT.eq

                ElseIf ur_char = "/"c Then
                    gChunkType = enmCT.fslash

                ElseIf ur_char = """"c Then
                    gChunkType = enmCT.qs

                Else
                    gChunkType = enmCT.txt
                End If
            End Function 'gChunkType
        End Class 'prv
    End Class 'db

    Public Class bitUB
        Inherits bitBASE
    End Class

    Public Class enmUB
        Public Shared bowl_name As bitUB = TRow(Of bitUB, enmUB).glbl.NewBitBase()
        Public Shared contents As bitUB = TRow(Of bitUB, enmUB).glbl.NewBitBase()
    End Class

    Public Class bitUN
        Inherits bitBASE
    End Class

    Public Class enmUN
        Public Shared app_name As bitUN = TRow(Of bitUN, enmUN).glbl.NewBitBase()
        Public Shared cmdline_audit As bitUN = TRow(Of bitUN, enmUN).glbl.NewBitBase()
        Public Shared cmdline_orig As bitUN = TRow(Of bitUN, enmUN).glbl.NewBitBase()
        Public Shared cmdline_table As bitUN = TRow(Of bitUN, enmUN).glbl.NewBitBase()
        Public Shared compiler_exe As bitUN = TRow(Of bitUN, enmUN).glbl.NewBitBase()
        Public Shared path As bitUN = TRow(Of bitUN, enmUN).glbl.NewBitBase()
        Public Shared to_userform As bitUN = TRow(Of bitUN, enmUN).glbl.NewBitBase()
    End Class

    Partial Public Class db
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function UserBowl() As sUserBowl
            Dim bolFIRST_INIT = (db.tblUserBowl Is Nothing)
            Call db.Connect()
            UserBowl = db.tblUserBowl
            If bolFIRST_INIT Then
                Call db.tblUserBowl.InsFrom_Application()
                'db.tblUserBowl.InsKey(enmUN.cmdline_audit, "1")
                Call db.tblUserBowl.Cboard_CmdlineAudit()
            End If
        End Function

        Public Class rUserBowl
            Inherits TRow(Of bitUB, enmUB)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As bitUB, ur_val As String) As rUserBowl
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rUserBowl

        Public Class sUserBowl
            Private ttb As Objlist(Of rUserBowl)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Me.ttb = New Objlist(Of rUserBowl)
            End Sub

            <System.Diagnostics.DebuggerHidden()>
            Public Sub Cboard_CmdlineAudit()
                If HasText(Me.SelKey(enmUN.cmdline_audit).v(enmUB.contents)) Then
                    Dim strAUDIT = Me.ToString(True)
                    Dim ins_msg = db.MessageBox.Ins(
                        New db.rMessageBox().
                            vt(enmMB.title, Me.SelKey(enmUN.app_name).v(enmUB.contents)).
                            vt(enmMB.text, strAUDIT),
                        MsgBoxStyle.OkCancel
                        )
                    If ins_msg.vUserResponse = MsgBoxResult.Ok Then
                        db.Clipboard.Ins(
                            New db.rClipboard().
                            vt(enmCB.text, strAUDIT)
                            )
                    End If
                End If
            End Sub 'Cboard_CmdlineAudit

            <System.Diagnostics.DebuggerHidden()>
            Public Function ExistsKey(ur_key As bitUN) As Boolean
                ExistsKey = False
                Dim strUN = ur_key.name
                For Each row In Me.ttb
                    If AreEqual(row.v(enmUB.bowl_name), strUN) Then
                        ExistsKey = True
                        Exit For
                    End If
                Next
            End Function 'ExistsKey

            <System.Diagnostics.DebuggerHidden()>
            Public Function Ins(ur_from As rUserBowl) As rUserBowl
                Ins = ur_from
                Me.ttb.Add(ur_from)
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function InsFrom_Application() As rUserBowl
                Dim ret = New rUserBowl
                InsFrom_Application = ret
                'enmUN.compiler_exe, enmUN.path take the first non-prefixed parameters; they are just file paths but without /parameter_name=
                Dim arlCMD_RET = MxText.Cmdline_UB(Of bitUN, enmUN, bitUB, enmUB).CommandLine_UBParm(enmUB.bowl_name, enmUB.contents, System.Environment.CommandLine, enmUN.compiler_exe, enmUN.path)
                Me.InsKey(enmUN.cmdline_orig, qs & System.Environment.CommandLine.Replace(qs, qs & qs) & qs)
                Me.InsKey(enmUN.cmdline_table, qs & arlCMD_RET.ttbCMD_PARM.ToString(True).Replace(qs, qs & qs) & qs)
                For Each rowFOUND In arlCMD_RET.ttbUB_PARM
                    Me.Ins(
                        New db.rUserBowl().
                        vt(enmUB.bowl_name, rowFOUND.v(enmUB.bowl_name)).
                        vt(enmUB.contents, rowFOUND.v(enmUB.contents))
                        )
                Next
            End Function 'InsFrom_Application

            <System.Diagnostics.DebuggerHidden()>
            Public Function InsKey(ur_key As bitUN, ur_val As String) As rUserBowl
                Dim ret = New rUserBowl
                InsKey = ret
                Me.ttb.Add(
                    ret.
                    vt(enmUB.bowl_name, ur_key.name).
                    vt(enmUB.contents, ur_val)
                    )
            End Function 'InsKey

            <System.Diagnostics.DebuggerHidden()>
            Public Function Sel(ur_col As bitUB, ur_value As String) As sUserBowl
                Dim retUB = New sUserBowl
                Sel = retUB
                For Each rowUB In Me.ttb
                    If AreEqual(rowUB.v(ur_col), ur_value) Then
                        retUB.Ins(rowUB)
                    End If
                Next
            End Function 'Sel

            <System.Diagnostics.DebuggerHidden()>
            Public Function SelAll() As Objlist(Of rUserBowl)
                SelAll = ttb
            End Function 'SelAll

            <System.Diagnostics.DebuggerHidden()>
            Public Function SelFirst() As rUserBowl
                If Me.ttb.Count = 0 Then
                    SelFirst = New rUserBowl()
                Else
                    SelFirst = Me.ttb.tr_b1(1)
                End If
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function SelKey(ur_key As bitUN) As rUserBowl
                Dim ret As rUserBowl = Nothing
                Dim strUN = ur_key.name
                For Each row In Me.ttb
                    If AreEqual(row.v(enmUB.bowl_name), strUN) Then
                        ret = row
                        Exit For
                    End If
                Next
                If ret Is Nothing Then ret = New rUserBowl
                SelKey = ret
            End Function 'SelKey

            <System.Diagnostics.DebuggerHidden()>
            Public Overloads Function ToString(ur_hdr As Boolean) As String
                Dim stpRET = Strapd() : For Each kvpREC In Me.ttb.kvp
                    stpRET.d(kvpREC.row.ToString((kvpREC.Indexb1 = 1) And ur_hdr))
                Next kvpREC : ToString = stpRET
            End Function 'ToString
            <System.Diagnostics.DebuggerHidden()>
            Public Function ToCbrd(ur_hdr As Boolean) As Integer
                ToCbrd = Mx.glbl.gCboard.SetText(Me.ToString(ur_hdr))
            End Function
        End Class 'sUserBowl
    End Class 'UB, UN
End Namespace 'Mx