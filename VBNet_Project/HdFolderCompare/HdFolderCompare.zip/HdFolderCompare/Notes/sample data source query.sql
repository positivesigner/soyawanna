DECLARE @form_title_like NVARCHAR(128) = 'distrib%'
	SELECT DISTINCT
		--ISNULL(Strings.String, Strings.Name) AS form_title,
		--Forms.Name,
		--Forms.ScopeType,
		SUBSTRING(REPLACE(GridCollectionVar.Value, 'SYMIX.', ''), 1, CASE WHEN CHARINDEX('(', REPLACE(GridCollectionVar.Value, 'SYMIX.', '')) > 0 THEN CHARINDEX('(', REPLACE(GridCollectionVar.Value, 'SYMIX.', '')) - 1 ELSE LEN(CHARINDEX('(', REPLACE(GridCollectionVar.Value, 'SYMIX.', ''))) END) AS component_ido
	   FROM
		((Forms LEFT JOIN Strings ON
				Strings.ScopeType <= 1 AND
				NOT EXISTS (SELECT 1 FROM Strings bufF WHERE
					bufF.Name = Strings.Name AND
					bufF.ScopeType <= 1 AND
					bufF.ScopeType > Strings.ScopeType
				   ) AND
				Strings.Name = Forms.Caption
		 ) INNER JOIN FormComponents01 GridComponent ON
				GridComponent.FormID = Forms.ID AND
				GridComponent.type = 14
			 ) LEFT JOIN Variables GridCollectionVar ON
				GridCollectionVar.ScopeType <= 1 AND
				NOT EXISTS (SELECT 1 FROM Variables bufF WHERE
					bufF.Name = GridCollectionVar.Name AND
					bufF.ScopeType <= 1 AND
					bufF.ScopeType > GridCollectionVar.ScopeType AND
					bufF.FormID = GridCollectionVar.FormID
				   ) AND
				GridCollectionVar.FormID = Forms.ID AND
				GridCollectionVar.Name =
				  CASE
				  WHEN GridComponent.DataSource = 'objects' THEN 'fds_datasource'
				  WHEN GridComponent.DataSource LIKE 'objects%' THEN 'fds_sc' + SUBSTRING(GridComponent.DataSource, LEN('objects') + 1, LEN(GridComponent.DataSource) )
				  ELSE
				    NULL
				  END
	   WHERE
	    --ISNULL(Strings.String, Strings.Name) like @form_title_like AND
		Forms.ScopeType <= 1 AND
		NOT EXISTS (SELECT 1 FROM Forms bufF WHERE
			bufF.Name = Forms.Name AND
			bufF.ScopeType <= 1 AND
			bufF.ScopeType > Forms.ScopeType
		   )
