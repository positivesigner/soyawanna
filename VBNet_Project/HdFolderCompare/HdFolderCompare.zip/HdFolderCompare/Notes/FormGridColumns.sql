/*
SELECT TOP 90 *
FROM FormComponents01
WHERE --formid = 5216 and 
type = 14

SELECT top 90 *
FROM ISM_TPR_Train_Objects.dbo.Properties
where
collectionname = 'SLDistAccts' and
propertyname = 'Whse'

SELECT top 90 
ClassName,
ParentClassName,
LabelStringID
FROM ISM_TPR_Train_Objects.dbo.PropertyClasses
where
classname IN ('Whse', 'WhseBase')

SELECT TOP 90 *
FROM 
WhseType

SELECT TOP 90 *
FROM Variables
WHERE name like 'fds%'
*/

	DECLARE @form_title_like NVARCHAR(128) = 'distrib%'
	IF OBJECT_ID('TempDb..#tbFORM') IS NOT NULL BEGIN  DROP TABLE #tbFORM  END
	IF OBJECT_ID('TempDb..#tbGRID_COMPONENT') IS NOT NULL BEGIN  DROP TABLE #tbGRID_COMPONENT  END
	IF OBJECT_ID('TempDb..#tbGRID_COLUMN') IS NOT NULL BEGIN  DROP TABLE #tbGRID_COLUMN  END
	IF OBJECT_ID('TempDb..#tbGRID_IDO') IS NOT NULL BEGIN  DROP TABLE #tbGRID_IDO  END
	IF OBJECT_ID('TempDb..#tbCOL_PROP') IS NOT NULL BEGIN  DROP TABLE #tbCOL_PROP  END
	IF OBJECT_ID('TempDb..#tbPROPCLS') IS NOT NULL BEGIN  DROP TABLE #tbPROPCLS  END
	IF OBJECT_ID('TempDb..#tbCOL_LABEL') IS NOT NULL BEGIN  DROP TABLE #tbCOL_LABEL  END
	
	SELECT
		ISNULL(Strings.String, Strings.Name) AS form_title,
		 Forms.Name,
		  Forms.ScopeType,
		Forms.ID,
		 Forms.PrimaryDataSource
	  INTO #tbFORM
	  FROM
		Forms LEFT JOIN Strings ON
			Strings.ScopeType <= 1 AND
			NOT EXISTS (SELECT 1 FROM Strings bufF WHERE
				bufF.Name = Strings.Name AND
				bufF.ScopeType <= 1 AND
				bufF.ScopeType > Strings.ScopeType
			  ) AND
			Strings.Name = Forms.Caption
	  WHERE
	    ISNULL(Strings.String, Strings.Name) like @form_title_like AND
		Forms.ScopeType <= 1 AND
		NOT EXISTS (SELECT 1 FROM Forms bufF WHERE
			bufF.Name = Forms.Name AND
			bufF.ScopeType <= 1 AND
			bufF.ScopeType > Forms.ScopeType
	      )
	
	SELECT 'Form'x,* FROM #tbFORM

	SELECT
		ttbFORM.Name AS form_name,
		 GridComponent.Name AS grid_component_name,
		  GridComponent.DataSource AS component_collection,
		ISNULL(GridCollectionVar.Name, GridComponent.DataSource) AS collection_var,
		 SUBSTRING(REPLACE(GridCollectionVar.Value, 'SYMIX.', ''), 1, CASE WHEN CHARINDEX('(', REPLACE(GridCollectionVar.Value, 'SYMIX.', '')) > 0 THEN CHARINDEX('(', REPLACE(GridCollectionVar.Value, 'SYMIX.', '')) - 1 ELSE LEN(CHARINDEX('(', REPLACE(GridCollectionVar.Value, 'SYMIX.', ''))) END) AS component_ido
	  INTO #tbGRID_COMPONENT
	  FROM
		(#tbFORM ttbFORM INNER JOIN FormComponents01 GridComponent ON
			GridComponent.FormID = ttbFORM.ID AND
			GridComponent.type = 14
		) LEFT JOIN Variables GridCollectionVar ON
			GridCollectionVar.ScopeType <= 1 AND
			NOT EXISTS (SELECT 1 FROM Variables bufF WHERE
				bufF.Name = GridCollectionVar.Name AND
				bufF.ScopeType <= 1 AND
				bufF.ScopeType > GridCollectionVar.ScopeType AND
				bufF.FormID = GridCollectionVar.FormID
			  ) AND
			GridCollectionVar.FormID = ttbFORM.ID AND
			GridCollectionVar.Name =
				CASE
				  WHEN GridComponent.DataSource = 'objects' THEN 'fds_datasource'
				  WHEN GridComponent.DataSource LIKE 'objects%' THEN 'fds_sc' + SUBSTRING(GridComponent.DataSource, LEN('objects') + 1, LEN(GridComponent.DataSource) )
				  ELSE
				    NULL
				  END

	SELECT 'Grid Component'x,*
	  FROM #tbGRID_COMPONENT

	SELECT
		ttbGRID_COMPONENT.form_name,
		 ttbGRID_COMPONENT.grid_component_name,
		  GridColumn.Name AS grid_column_name,
		GridColumn.Caption AS grid_column_strlabel,
		 GridColumn.ContainerSequence AS grid_column_sequence,
		  GridColumn.DataSource,
		REPLACE(GridColumn.DataSource, REPLACE(ttbGRID_COMPONENT.component_collection, 'objects', 'object') + '.', '') AS ido_source
	  INTO #tbGRID_COLUMN
	  FROM
		(#tbFORM ttbFORM INNER JOIN #tbGRID_COMPONENT ttbGRID_COMPONENT ON
			ttbGRID_COMPONENT.form_name = ttbFORM.Name
		) INNER JOIN FormComponents01 GridColumn ON
			GridColumn.FormID = ttbFORM.ID AND
			GridColumn.type = 15

	SELECT 'Grid Column'x,*
	  FROM #tbGRID_COLUMN
	  ORDER BY
		form_name,
		grid_component_name,
		grid_column_sequence

	;WITH bufIDO AS (
		SELECT
			ttbGRID_COMPONENT.form_name,
			 ttbGRID_COMPONENT.grid_component_name,
			  Collections.CollectionName,
			1 AS rec_lvl,
			 CONVERT(NVARCHAR(MAX), Collections.CollectionName) AS extension_path
		  FROM
			(#tbFORM ttbFORM INNER JOIN #tbGRID_COMPONENT ttbGRID_COMPONENT ON
				ttbGRID_COMPONENT.form_name = ttbFORM.Name
			) INNER JOIN ISM_TPR_Train_Objects.dbo.Collections ON
				Collections.CollectionName = ttbGRID_COMPONENT.component_ido AND
				Collections.DevelopmentFlag = 0
	  ),
	  bufPREV AS (
		SELECT
			bufIDO.form_name,
			 bufIDO.grid_component_name,
			  bufIDO.CollectionName AS root_collection,
			bufIDO.CollectionName,
			 bufIDO.rec_lvl,
			  bufIDO.extension_path
		  FROM bufIDO
		  WHERE
			bufIDO.rec_lvl = 1
			
		  UNION ALL
		  SELECT
			bufPREV.form_name,
			 bufPREV.grid_component_name,
			  bufPREV.root_collection,
			Collections.CollectionName,
			 bufPREV.rec_lvl + 1 AS rec_lvl,
			  bufPREV.extension_path + ' \ ' + Collections.CollectionName AS extension_path
		  FROM
			bufPREV INNER JOIN ISM_TPR_Train_Objects.dbo.Collections ON
				Collections.Extends = bufPREV.CollectionName AND
				Collections.DevelopmentFlag = 0
	  )
	  SELECT
		bufPREV.form_name,
		 bufPREV.grid_component_name,
		  bufPREV.root_collection,
		bufPREV.CollectionName,
		 bufPREV.rec_lvl,
		  bufPREV.extension_path
	  INTO #tbGRID_IDO
	  FROM bufPREV

	  ORDER BY
		root_collection,
		 extension_path
	  OPTION (MAXRECURSION 10)

	SELECT
		ttbGRID_COLUMN.form_name,
		 ttbGRID_COLUMN.grid_component_name,
		  ttbGRID_COLUMN.grid_column_name,
		Properties.PropertyName,
		 (
			CASE Properties.propertytype
			  WHEN 0 THEN 'Bound'
			  WHEN 1 THEN 'Derived'
			  WHEN 2 THEN 'Unbound'
			  WHEN 3 THEN 'Subcollection'
			  ELSE
			    CONVERT(NVARCHAR(30), Properties.propertytype)
			  END
			) AS property_type,
		  ttbPROP_IDO.CollectionName,
		(
			CASE
			  WHEN Properties.propertytype = 0 THEN ISNULL(Tables.TableAlias, Properties.ColumnTableAlias)
			  ELSE
				NULL
			  END
			) AS property_table,
		 (
			CASE
			  WHEN Properties.propertytype = 0
			  THEN Properties.ColumnName
			  ELSE
				NULL
			  END
			) AS property_column,
		  Properties.LabelStringID AS ido_column_strlabel,
		   Properties.PropertyClass
	  INTO #tbCOL_PROP
	  FROM
		(((	((#tbFORM ttbFORM INNER JOIN #tbGRID_COMPONENT ttbGRID_COMPONENT ON
				ttbGRID_COMPONENT.form_name = ttbFORM.Name
			 ) INNER JOIN #tbGRID_IDO ttbPROP_IDO ON
				ttbPROP_IDO.form_name = ttbGRID_COMPONENT.form_name AND
				ttbPROP_IDO.grid_component_name = ttbGRID_COMPONENT.grid_component_name
			) INNER JOIN #tbGRID_COLUMN ttbGRID_COLUMN ON
				ttbGRID_COLUMN.form_name = ttbGRID_COMPONENT.form_name AND
				ttbGRID_COLUMN.grid_component_name = ttbGRID_COMPONENT.grid_component_name
		  ) LEFT JOIN ISM_TPR_Train_Objects.dbo.Properties ON
			Properties.DevelopmentFlag = 0 AND
			Properties.CollectionName = ttbPROP_IDO.CollectionName AND
			Properties.PropertyName = ttbGRID_COLUMN.ido_source AND
			NOT EXISTS (SELECT 1 FROM #tbGRID_IDO bufI WHERE
				bufI.form_name = ttbGRID_COMPONENT.form_name AND
				bufI.grid_component_name = ttbGRID_COMPONENT.grid_component_name AND
				bufI.rec_lvl < ttbPROP_IDO.rec_lvl AND
				EXISTS (SELECT 1 FROM ISM_TPR_Train_Objects.dbo.Properties bufP WHERE
					bufP.DevelopmentFlag = 0 AND
					bufP.CollectionName = bufI.CollectionName AND
					bufP.PropertyName = ttbGRID_COLUMN.ido_source
				  )
			  )
		 ) LEFT JOIN #tbGRID_IDO ttbTABLE_IDO ON
			ttbTABLE_IDO.form_name = ttbGRID_COMPONENT.form_name AND
			ttbTABLE_IDO.grid_component_name = ttbGRID_COMPONENT.grid_component_name AND
			ttbTABLE_IDO.rec_lvl <= ttbPROP_IDO.rec_lvl
		) LEFT JOIN ISM_TPR_Train_Objects.dbo.Tables ON
			Tables.DevelopmentFlag = 0 AND
			Tables.CollectionName = ttbTABLE_IDO.CollectionName AND
			Tables.TableAlias = Properties.ColumnTableAlias AND
			NOT EXISTS (SELECT 1 FROM #tbGRID_IDO bufI WHERE
				bufI.form_name = ttbGRID_COMPONENT.form_name AND
				bufI.grid_component_name = ttbGRID_COMPONENT.grid_component_name AND
				bufI.rec_lvl <= ttbPROP_IDO.rec_lvl AND
				bufI.rec_lvl < ttbTABLE_IDO.rec_lvl AND
				EXISTS (SELECT 1 FROM ISM_TPR_Train_Objects.dbo.Properties bufP WHERE
					bufP.DevelopmentFlag = 0 AND
					bufP.CollectionName = bufI.CollectionName AND
					bufP.PropertyName = ttbGRID_COLUMN.ido_source
				  )

			  )
	
	SELECT 'Property'x,*
	  FROM #tbCOL_PROP

	;WITH bufPROPCLS AS (
		SELECT DISTINCT
			PropertyClasses.ClassName,
			 1 AS rec_lvl,
			  CONVERT(NVARCHAR(MAX), PropertyClasses.ClassName) AS extension_path,
			PropertyClasses.LabelStringID AS propcls_column_strlabel,
			 PropertyClasses.ParentClassName
		  FROM
			(((#tbFORM ttbFORM INNER JOIN #tbGRID_COMPONENT ttbGRID_COMPONENT ON
				ttbGRID_COMPONENT.form_name = ttbFORM.Name
			  ) INNER JOIN #tbGRID_COLUMN ttbGRID_COLUMN ON
				ttbGRID_COLUMN.form_name = ttbGRID_COMPONENT.form_name AND
				ttbGRID_COLUMN.grid_component_name = ttbGRID_COMPONENT.grid_component_name
			 ) INNER JOIN #tbCOL_PROP ttbCOL_PROP ON
				ttbCOL_PROP.form_name = ttbGRID_COLUMN.form_name AND
				ttbCOL_PROP.grid_component_name = ttbGRID_COLUMN.grid_component_name AND
				ttbCOL_PROP.grid_column_name = ttbGRID_COLUMN.grid_column_name
			) INNER JOIN ISM_TPR_Train_Objects.dbo.PropertyClasses ON
				PropertyClasses.ClassName = ttbCOL_PROP.PropertyClass AND
				PropertyClasses.DevelopmentFlag = 0
	  ),
	  bufPREV AS (
		SELECT
			bufPROPCLS.ClassName AS root_class,
			 bufPROPCLS.ClassName,
			  bufPROPCLS.rec_lvl,
			bufPROPCLS.extension_path,
			 bufPROPCLS.propcls_column_strlabel,
			  bufPROPCLS.ParentClassName
		  FROM bufPROPCLS
		  WHERE
			bufPROPCLS.rec_lvl = 1
			
		  UNION ALL
		  SELECT
			bufPREV.root_class,
			 PropertyClasses.ClassName,
			  bufPREV.rec_lvl + 1 AS rec_lvl,
			bufPREV.extension_path + ' \ ' + PropertyClasses.ClassName AS extension_path,
			 PropertyClasses.LabelStringID AS propcls_column_strlabel,
			  PropertyClasses.ParentClassName
		  FROM
			bufPREV INNER JOIN ISM_TPR_Train_Objects.dbo.PropertyClasses ON
				PropertyClasses.ClassName = bufPREV.ParentClassName AND
				PropertyClasses.DevelopmentFlag = 0
	  )
	  SELECT
		bufPREV.root_class,
		 bufPREV.ClassName,
		  bufPREV.rec_lvl,
		bufPREV.extension_path,
		 bufPREV.propcls_column_strlabel
	  INTO #tbPROPCLS
	  FROM bufPREV

	  ORDER BY
		root_class,
		 extension_path
	  OPTION (MAXRECURSION 10)
	
	SELECT
		ttbGRID_COLUMN.form_name,
		 ttbGRID_COLUMN.grid_component_name,
		  ttbGRID_COLUMN.grid_column_name,
		ttbGRID_COLUMN.grid_column_sequence,
		 (
			ISNULL(
				bufS.String,
				ISNULL(
					ttbGRID_COLUMN.grid_column_strlabel,
					ISNULL(
						ttbCOL_PROP.ido_column_strlabel,
						ttbPROPCLS.propcls_column_strlabel
					  )
				  )
			  )
			) AS grid_column_title,
		  /*(
			ISNULL(
				ttbGRID_COLUMN.grid_column_strlabel,
				ISNULL(
					ttbCOL_PROP.ido_column_strlabel,
					ttbPROPCLS.propcls_column_strlabel
				  )
			  )
			) AS column_applied_strlabel,
		ttbCOL_PROP.PropertyClass*/
		  ttbCOL_PROP.property_type,
		ttbCOL_PROP.property_table,
		 ttbCOL_PROP.property_column
	  INTO #tbCOL_LABEL
	  FROM
		(((	(#tbFORM ttbFORM INNER JOIN #tbGRID_COMPONENT ttbGRID_COMPONENT ON
			ttbGRID_COMPONENT.form_name = ttbFORM.Name
			) INNER JOIN #tbGRID_COLUMN ttbGRID_COLUMN ON
				ttbGRID_COLUMN.form_name = ttbGRID_COMPONENT.form_name AND
				ttbGRID_COLUMN.grid_component_name = ttbGRID_COMPONENT.grid_component_name
		  ) INNER JOIN #tbCOL_PROP ttbCOL_PROP ON
			ttbCOL_PROP.form_name = ttbGRID_COLUMN.form_name AND
			ttbCOL_PROP.grid_component_name = ttbGRID_COLUMN.grid_component_name AND
			ttbCOL_PROP.grid_column_name = ttbGRID_COLUMN.grid_column_name
		 ) LEFT JOIN #tbPROPCLS ttbPROPCLS ON
			ttbPROPCLS.root_class = ttbCOL_PROP.PropertyClass AND
			ttbPROPCLS.propcls_column_strlabel IS NOT NULL AND
			NOT EXISTS (SELECT 1 FROM #tbPROPCLS bufP WHERE
				bufP.root_class = ttbCOL_PROP.PropertyClass AND
				bufP.propcls_column_strlabel IS NOT NULL AND
				bufP.rec_lvl < ttbPROPCLS.rec_lvl
			  )
		) LEFT JOIN Strings bufS ON
			bufS.ScopeType <= 1 AND
			NOT EXISTS (SELECT 1 FROM Strings bufF WHERE
				bufF.Name = bufS.Name AND
				bufF.ScopeType <= 1 AND
				bufF.ScopeType > bufS.ScopeType
			  ) AND
			bufS.Name = ISNULL(ttbGRID_COLUMN.grid_column_strlabel, ISNULL(ttbCOL_PROP.ido_column_strlabel, ttbPROPCLS.propcls_column_strlabel) )
	
	SELECT 'Column Label'x,*
	FROM #tbCOL_LABEL
	ORDER BY
		form_name,
		 grid_component_name,
		  grid_column_sequence

	/*
	  ORDER BY
		form_name,
		grid_component_name,
		grid_column_name

		ttbGRID_COLUMN.grid_column_sequence,
		 (
			ISNULL(ttbGRID_COLUMN.grid_column_strlabel, ISNULL(bufS.String, Properties.LabelStringID))
			) AS grid_column_strlabel,
	*/
