Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        My.Computer.Clipboard.SetText(Me.txtTEST.Text)
        Microsoft.VisualBasic.Interaction.AppActivate("CloudSuite Field Service")
        System.Windows.Forms.SendKeys.Send("^V{Tab}")
        Me.Timer1.Interval = 1000
        Me.Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Microsoft.VisualBasic.Interaction.AppActivate(Me.Text)
        Dim strFILE_PATH = "C:\Users\IT\Downloads\ABC123.txt"
        If System.IO.File.Exists(strFILE_PATH) Then
            Me.Timer1.Stop()
            System.IO.File.Delete(strFILE_PATH)
            MsgBox("Done")
        End If
    End Sub
End Class
