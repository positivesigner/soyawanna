﻿Option Strict On
Option Infer On

Namespace Mx
    Partial Class Have
        Partial Class sConfigManager
            Public Function Apply_errhnd(ret_ver_label As System.Windows.Forms.Label, ret_polling_timer As System.Windows.Forms.Timer, ret_lst_export_type As System.Windows.Forms.ComboBox) As Strap
                Dim stpRET = Strapd()
                Apply_errhnd = stpRET
                Dim objERR_LIST = New ErrListBase : Try
                    Call prv.Load_Configuration(Me, Have.UserBowl, Have.WindowsFS)
                    Call prv.Format_FormUI(ret_ver_label, ret_polling_timer, ret_lst_export_type, Have.UserBowl, Have.ExportType)
                    Call prv.Update_RepositoryPath(Have.Repository, Have.TicketList, Have.UserBowl)

                Catch ex As System.Exception
                    Call objERR_LIST.dError_Stack(ex)
                End Try

                If objERR_LIST.Found Then
                    stpRET.Clear().d(objERR_LIST.ToString)
                End If
            End Function 'ur_lst_folders

            Private Class prv
                Public Shared Sub Format_FormUI(ret_ver_label As System.Windows.Forms.Label, ret_polling_timer As System.Windows.Forms.Timer, ret_lst_export_type As System.Windows.Forms.ComboBox, ur_userbowl_cart As Have.sUserBowl, ur_exporttype_cart As Have.sExportType)
                    Dim app_version_bowlname = enmUN.app_version
                    ret_ver_label.Text = Strapd().d("Version:").dS(ur_userbowl_cart.SelKey(app_version_bowlname).Contents)
                    ret_polling_timer.Interval = 2000
                    ret_polling_timer.Start()
                    For Each strENTRY In ur_exporttype_cart.SelDistinct(enmEX.type_name)
                        ret_lst_export_type.Items.Add(strENTRY)
                    Next
                End Sub 'Format_FormUI

                Public Shared Sub Load_Configuration(ret_config_manager_cart As Have.sConfigManager, ret_userbowl_cart As Have.sUserBowl, ret_windows_fs As Have.sWindowsFS)
                    'load it from application folder (SpProcDef) parent folder (which has ".gitignore")
                    Dim app_name_bowlname = enmUN.app_name
                    Dim app_folder_bowlname = enmUN.app_folder
                    Dim app_config_file = enmUN.app_config_file
                    Dim app_settings_dir_bowlname = enmUN.app_settings_dir
                    Dim app_title_bowlname = enmUN.app_title
                    Dim app_version_bowlname = enmUN.app_version
                    Dim testing_repository_dir_bowlname = enmUN.testing_repository_dir
                    Dim beyond_compare_hunt_script_bowlname = enmUN.beyond_compare_hunt_script
                    Dim beyond_compare_hunt_path_bowlname = enmUN.beyond_compare_hunt_path
                    Dim hd_folder_search_bowlname = enmUN.hd_folder_search
                    Dim hosting_app_hunt_appsetting_bowlname = enmCM.hosting_app_title
                    Dim hosting_app_hunt_default_bowlname = enmUN.hosting_app_hunt_default
                    Dim notepad_pp_hunt_script_e1_bowlname = enmUN.notepad_pp_hunt_script_e1
                    Dim notepad_pp_hunt_script_e2_bowlname = enmUN.notepad_pp_hunt_script_e2
                    Dim notepad_pp_hunt_path_e1_bowlname = enmUN.notepad_pp_hunt_path_e1
                    Dim notepad_pp_hunt_path_e2_bowlname = enmUN.notepad_pp_hunt_path_e2
                    Dim spprocdef_export_hunt_appsetting_bowlname = enmCM.sqlprocdef_script
                    Dim spprocdef_export_hunt_script_bowlname = enmUN.spprocdef_export_hunt_script
                    Dim ticket_notes_subdir_bowlname = enmUN.ticket_notes_subdir
                    Dim user_download_dir_bowlname = enmUN.user_download_dir

                    'ur_ret.d(userbowl_cart.SelKey(app_name_bowlname).Contents)

                    ret_userbowl_cart.SelKey(app_config_file).vt(enmUB.contents, "HdFolderCompare.exe.config")
                    ret_userbowl_cart.SelKey(app_title_bowlname).vt(enmUB.contents, My.Application.Info.Title)
                    ret_userbowl_cart.SelKey(app_version_bowlname).vt(enmUB.contents, My.Application.Info.Version.ToString)
                    ret_userbowl_cart.SelKey(testing_repository_dir_bowlname).vt(enmUB.contents, "C:\BitBucket\tpr_gotoassisttickets")
                    ret_userbowl_cart.SelKey(beyond_compare_hunt_script_bowlname).vt(enmUB.contents, "BCompare_Timer.vbscript.cmd")
                    ret_userbowl_cart.SelKey(beyond_compare_hunt_path_bowlname).vt(enmUB.contents, "C:\Program Files\Beyond Compare 4\BCompare.exe")
                    ret_userbowl_cart.SelKey(hd_folder_search_bowlname).vt(enmUB.contents, "* hd*")
                    ret_userbowl_cart.SelKey(hosting_app_hunt_default_bowlname).vt(enmUB.contents, "CloudSuite Field Service")
                    ret_userbowl_cart.SelKey(notepad_pp_hunt_script_e1_bowlname).vt(enmUB.contents, "..\..\NotePadPP\Notepad++Portable.exe")
                    ret_userbowl_cart.SelKey(notepad_pp_hunt_script_e2_bowlname).vt(enmUB.contents, "Notepad++_Timer.vbscript.cmd")
                    ret_userbowl_cart.SelKey(notepad_pp_hunt_path_e1_bowlname).vt(enmUB.contents, "C:\Program Files\Notepad++\notepad++.exe")
                    ret_userbowl_cart.SelKey(notepad_pp_hunt_path_e2_bowlname).vt(enmUB.contents, "C:\Program Files (x86)\Notepad++\notepad++.exe")
                    ret_userbowl_cart.SelKey(spprocdef_export_hunt_script_bowlname).vt(enmUB.contents, "SqlProcDef_CollectionsNoQTA.vbscript.cmd")
                    ret_userbowl_cart.SelKey(ticket_notes_subdir_bowlname).vt(enmUB.contents, "Notes")
                    ret_userbowl_cart.SelKey(user_download_dir_bowlname).vt(enmUB.contents, System.Environment.ExpandEnvironmentVariables("%USERPROFILE%\downloads"))
                    Dim repository_dir_bowlname = ret_userbowl_cart.Apply(app_folder_bowlname, testing_repository_dir_bowlname)
                    Dim log_dir_bowlname = ret_userbowl_cart.Apply(repository_dir_bowlname)
                    Call ret_windows_fs.Apply(log_dir_bowlname, app_settings_dir_bowlname, app_config_file)
                    Call ret_config_manager_cart.Ins_AppSettings(System.Configuration.ConfigurationManager.AppSettings)

                    Dim session_save_path_bowlname = ret_userbowl_cart.Apply(log_dir_bowlname, app_name_bowlname)
                    Dim beyond_compare_exe_path_bowlname = ret_userbowl_cart.Apply(log_dir_bowlname, beyond_compare_hunt_script_bowlname, beyond_compare_hunt_path_bowlname)
                    Dim notepad_pp_exe_path_bowlname = ret_userbowl_cart.Apply(log_dir_bowlname, notepad_pp_hunt_script_e1_bowlname, notepad_pp_hunt_script_e2_bowlname, notepad_pp_hunt_path_e1_bowlname, notepad_pp_hunt_path_e2_bowlname)
                    Dim spprocdef_export_exe_path_bowlname = ret_userbowl_cart.Apply(ret_config_manager_cart, log_dir_bowlname, spprocdef_export_hunt_appsetting_bowlname, spprocdef_export_hunt_script_bowlname)
                    Dim spprocdef_export_error_search_bowlname = ret_userbowl_cart.Apply(spprocdef_export_exe_path_bowlname)
                    Dim hosting_app_appactivate_title_bowlname = ret_userbowl_cart.Apply(ret_config_manager_cart, hosting_app_hunt_appsetting_bowlname, hosting_app_hunt_default_bowlname)

                    Dim user_session_entry_bowlname_tuple = ret_userbowl_cart.Apply(session_save_path_bowlname)
                End Sub 'Load_Configuration

                Public Shared Sub Update_RepositoryPath(ret_repository As Have.sRepository, ret_ticket_list As Have.sTicket, ur_userbowl_cart As Have.sUserBowl)
                    Dim repository_dir_bowlname = enmUN.repository_dir
                    Dim flnREPOSITORY_PATH = FileNamed().d(ur_userbowl_cart.SelKey(repository_dir_bowlname).Contents)
                    ret_repository.Apply(flnREPOSITORY_PATH)
                End Sub 'ur_load_repository
            End Class 'prv
        End Class 'sConfigManager
    End Class 'Have


    Partial Class Have
        Partial Class sRepository
            Public Sub Apply(ur_folder As String)
                For Each row In Me.SelAll
                    Call row.ActiveTicket.Clear()
                    For Each trwTICKET In Me.TicketList.Sel(enmHD.folder_name, ur_folder).SelAll
                        row.ActiveTicket.Add(trwTICKET)
                        Exit For
                    Next trwTICKET
                Next row
            End Sub 'ur_folder

            Sub Apply(ur_name As String, ur_path As String)
                Call Me.Clear()
                Me.InsKey(ur_name).v(enmRP.server_folder_path) = ur_path
            End Sub 'ur_name

            Public Function Apply_errhnd(ret_lst_folders As System.Windows.Forms.ListBox, ur_chk_sortby_ticket As System.Windows.Forms.CheckBox) As Strap
                Dim stpRET = Strapd()
                Apply_errhnd = stpRET
                Dim objERR_LIST = New ErrListBase : Try
                    Call prv.Reload_TicketList(Have.TicketList, ret_lst_folders, Me, ur_chk_sortby_ticket.Checked, Have.UserBowl, Have.EnvConn)

                Catch ex As System.Exception
                    Call objERR_LIST.dError_Stack(ex)
                End Try

                If objERR_LIST.Found Then
                    stpRET.Clear().d(objERR_LIST.ToString)
                End If
            End Function 'ur_lst_folders

            'Public Function Apply_errhnd(ur_folder As System.Windows.Forms.ListBox, ur_primary_envver As System.Windows.Forms.ListBox, ur_secondary_envver As System.Windows.Forms.ListBox, ur_btn_ticket_folder As System.Windows.Forms.Button, ur_tab_selection As System.Windows.Forms.TabControl) As Strap
            '    Dim stpRET = Strapd()
            '    Apply_errhnd = stpRET
            '    Dim objERR_LIST = New ErrListBase : Try
            '        Call prv.Submit_UserSession_Ticket(ur_folder, ur_primary_envver, ur_secondary_envver, ur_btn_ticket_folder, ur_tab_selection, Me)

            '    Catch ex As System.Exception
            '        Call objERR_LIST.dError_Stack(ex)
            '    End Try

            '    If objERR_LIST.Found Then
            '        stpRET.Clear().d(objERR_LIST.ToString)
            '    End If
            'End Function 'ur_folder

            Public Function Apply_errhnd(ur_folder As System.Windows.Forms.ListBox, e As System.Windows.Forms.KeyPressEventArgs, ur_primary_envver As System.Windows.Forms.ListBox, ur_secondary_envver As System.Windows.Forms.ListBox, ur_btn_ticket_folder As System.Windows.Forms.Button, ur_tab_selection As System.Windows.Forms.TabControl) As Strap
                Dim stpRET = Strapd()
                Apply_errhnd = stpRET
                Dim objERR_LIST = New ErrListBase : Try
                    Call prv.Submit_UserSelection_Ticket(ur_folder, ur_primary_envver, ur_secondary_envver, ur_btn_ticket_folder, ur_tab_selection, Me, e)

                Catch ex As System.Exception
                    Call objERR_LIST.dError_Stack(ex)
                End Try

                If objERR_LIST.Found Then
                    stpRET.Clear().d(objERR_LIST.ToString)
                End If
            End Function 'ur_folder, e

            Private Class prv
                Public Shared Sub Reload_TicketList(ret_ticket_list As Have.sTicket, ret_lst_folders As System.Windows.Forms.ListBox, ur_repository As sRepository, ur_flag_sortby_ticketnum As Boolean, ur_userbowl_cart As Have.sUserBowl, ur_envconn_list As Have.sEnvConn)
                    'use file system to get *hd* folders
                    Dim repository_dir_bowlname = enmUN.repository_dir
                    Dim hd_folder_search_bowlname = enmUN.hd_folder_search
                    Call ret_ticket_list.Apply(ur_repository, ur_userbowl_cart, ur_envconn_list)

                    Dim sdaTICKET = New Sdata
                    For Each objTICKET In ur_repository.TicketList.SelAll
                        Dim strSORT = objTICKET.v(enmHD.folder_name)
                        If ur_flag_sortby_ticketnum Then
                            strSORT = objTICKET.v(enmHD.ticket_name)
                        End If

                        sdaTICKET.Add(strSORT)
                    Next objTICKET

                    Call sdaTICKET.Sort()
                    Call ret_lst_folders.Items.Clear()
                    For ROWCTR = sdaTICKET.Count To 1 Step -1
                        ret_lst_folders.Items.Add(sdaTICKET.v_b1(ROWCTR))
                    Next

                    If sdaTICKET.Count > 0 Then
                        ret_lst_folders.SelectedIndex = 0
                    End If

                    ret_lst_folders.Select()
                End Sub 'Reload_TicketList

                'Public Shared Sub Submit_UserSession_Ticket(ret_folder As System.Windows.Forms.ListBox, ret_primary_envver As System.Windows.Forms.ListBox, ret_secondary_envver As System.Windows.Forms.ListBox, ur_btn_ticket_folder As System.Windows.Forms.Button, ur_tab_selection As System.Windows.Forms.TabControl, ur_repository As sRepository)
                '    Dim user_hdfolder_entry_userbowl = enmUN.user_hdfolder_entry
                '    Dim strUSER_HDFOLDER = Have.UserBowl.SelKey(user_hdfolder_entry_userbowl).Contents
                '    Call ur_repository.Apply(strUSER_HDFOLDER)
                '    For Each row In ur_repository.SelAll
                '        Dim bolFOUND_TICKET = False
                '        For Each objTICKET In row.ActiveTicket
                '            Dim strACTIVE_FOLDER = objTICKET.v(enmHD.folder_name)
                '            If Mx.ListBoxSearch.Assign_SelectedIndex(ret_folder, strACTIVE_FOLDER) Then
                '                bolFOUND_TICKET = True
                '                Call prv.Submit_UserSelection_Ticket(ret_folder, ret_primary_envver, ret_secondary_envver, ur_btn_ticket_folder, ur_tab_selection, ur_repository, Nothing)
                '                Call Mx.Want.Submit_UserSession_Primary_EnvVer_errhnd(ret_primary_envver, ret_secondary_envver)
                '            End If 'ur_folder

                '            Exit For
                '        Next objTICKET

                '        If bolFOUND_TICKET = False Then
                '            Call row.ActiveTicket.Clear()
                '        End If
                '    Next row
                'End Sub 'Submit_UserSession_Ticket

                Public Shared Sub Submit_UserSelection_Ticket(ret_folder As System.Windows.Forms.ListBox, ret_primary_envver As System.Windows.Forms.ListBox, ur_secondary_envver As System.Windows.Forms.ListBox, ret_btn_ticket_folder As System.Windows.Forms.Button, ret_tab_selection As System.Windows.Forms.TabControl, ur_repository As Have.sRepository, e As System.Windows.Forms.KeyPressEventArgs)
                    Dim strSELECTED = ListBoxSearch.gCurEntry(ret_folder)
                    If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
                      HasText(strSELECTED) Then
                        Call ur_repository.Apply(strSELECTED)
                        For Each row In ur_repository.SelAll
                            For Each objTICKET In row.ActiveTicket
                                Dim strCURRENT_HDFOLDER = objTICKET.v(enmHD.path)

                                Call ret_primary_envver.Items.Clear()
                                For Each strENVVER In objTICKET.Apply(enmUTK.ordered_envver_list)
                                    ret_primary_envver.Items.Add(strENVVER)
                                Next strENVVER

                                Call ur_secondary_envver.Items.Clear()

                                '*** Call btnRefreshNotes_Click()
                                ret_btn_ticket_folder.Text = objTICKET.v(enmHD.folder_name)
                                ret_tab_selection.SelectedIndex = b0(2)
                                ret_folder.Select()
                            Next objTICKET
                        Next row
                    End If 'strSELECTED
                End Sub 'Submit_UserSelection_Ticket
            End Class 'prv
        End Class 'sRepository
    End Class 'Have


    Partial Class Have
        'Partial Class xSelTicket
        '    Public Sub Apply(ur_assign_primary_envver As enmUTK.zassign_primary_envver, ur_envver As Have.sSelEnvironment)
        '        Me.Secondary_EnvVer.Clear()
        '        For Each objENV_VER In Me.env_conn_filelist_ver_list
        '            If AreEqual(objENV_VER.Name, ur_folder) Then
        '                Me.Apply(ur_assign_secondary_envver, objENV_VER)
        '                Exit For
        '            End If
        '        Next objENV_VER
        '    End Sub 'ur_assign_primary_envver

        '    Public Sub Apply(ur_assign_secondary_envver As enmUTK.zassign_secondary_envver, ur_folder As String)
        '        Me.Secondary_EnvVer.Clear()
        '        For Each objENV_VER In Me.env_conn_filelist_ver_list
        '            If AreEqual(objENV_VER.Name, ur_folder) Then
        '                Me.Apply(ur_assign_secondary_envver, objENV_VER)
        '                Exit For
        '            End If
        '        Next objENV_VER
        '    End Sub 'ur_assign_secondary_envver
        'End Class 'sSelTicket
    End Class 'Have


    'Partial Public Class xApplyTicket
    '    Public Sub Apply(ur_reload_envver_list As enmUTK.zreload_envver_list)
    '        'use file system to get all folders under HD folder that matches a environment connection name
    '        Dim envver_cart = Have.EnvVer
    '        Dim envconn_cart = Have.EnvConn
    '        Call envver_cart.Apply(Me.env_conn_filelist_ver_list, Me.Primary_EnvVer, Me.Secondary_EnvVer, Me, envconn_cart)
    '    End Sub 'ur_reload_envver_list


    '    Public Sub Apply(ur_assign_addfile_envver As enmUTK.zassign_addfile_envver, ur_envver As Have.sSelEnvironment)
    '        Me.AddFile_EnvVer.Clear()
    '        Me.AddFile_EnvVer.Add(ur_envver)
    '    End Sub 'ur_assign_secondary_envver

    '    Public Sub Apply(ur_assign_addfile_envver As enmUTK.zassign_addfile_envver, ur_folder As String)
    '        Me.AddFile_EnvVer.Clear()
    '        For Each objENV_VER In Me.env_conn_filelist_ver_list
    '            If AreEqual(objENV_VER.Name, ur_folder) Then
    '                Me.Apply(ur_assign_addfile_envver, objENV_VER)
    '                Exit For
    '            End If
    '        Next objENV_VER
    '    End Sub 'ur_assign_addfile_envver
    'End Class 'Ticket

    'Partial Class xSelEnvironment
    '    'Public Function Open_DBConnection() As System.Data.SqlClient.SqlConnection
    '    'Dim retCONN As System.Data.SqlClient.SqlConnection = Nothing
    '    'Dim strSIDE = "First"
    '    'If Me.FileList Is Me.FoldersForm.lstC_FILE Then
    '    '    strSIDE = "Comparison"
    '    '    For Each env_entry In User_Selection.Comparison_Selected
    '    '        retCONN = New System.Data.SqlClient.SqlConnection(env_entry.DBConnection_String)
    '    '    Next

    '    'Else 'FileList
    '    '    For Each env_entry In User_Selection.Environment_Selected
    '    '        retCONN = New System.Data.SqlClient.SqlConnection(env_entry.DBConnection_String)
    '    '    Next
    '    'End If 'FileList

    '    'Open_DBConnection = retCONN

    '    'If retCONN Is Nothing Then
    '    '    Throw New System.Exception("Database parameters must be entered for " & strSIDE & " side")

    '    'Else
    '    '    If retCONN.State = System.Data.ConnectionState.Open Then
    '    '        retCONN.Close()
    '    '    End If 'State

    '    '    retCONN.Open()
    '    '    Call System.Data.SqlClient.SqlConnection.ClearPool(retCONN)
    '    'End If 'retCONN
    '    'End Function 'Open_DBConnection

    '    Public Sub Side_Export_Click()
    '        'If Me.FileList Is Me.FoldersForm.lstC_FILE Then
    '        '    Call Me.FoldersForm.btnC_Export_Click()
    '        'Else
    '        '    Call Me.FoldersForm.btnE_Export_Click()
    '        'End If
    '    End Sub 'Side_Export_Click
    'End Class

    'Public Class Want
    '    Public Shared Sub Save_UserTicket_Selection()
    '        Dim session_save_path_bowlname = enmUN.session_save_path
    '        Dim stpOUTPUT = Mx.Strapd()
    '        For Each objTICKET In sCompany.Company_Source_Code_Repository.Active_Ticket
    '            Dim strENTRY = objTICKET.row.v(enmHD.folder_name)
    '            stpOUTPUT.d(strENTRY)
    '            For Each objPRIMARY_ENVVER In objTICKET.Primary_EnvVer
    '                strENTRY = objPRIMARY_ENVVER.Name
    '                stpOUTPUT.dLine(strENTRY)
    '                For Each objSECONDARY_ENVVER In objTICKET.Primary_EnvVer
    '                    strENTRY = objSECONDARY_ENVVER.Name
    '                    stpOUTPUT.dLine(strENTRY)
    '                Next objSECONDARY_ENVVER
    '            Next objPRIMARY_ENVVER
    '        Next objTICKET

    '        If stpOUTPUT.HasText Then
    '            glbl.gWindowsFS.Apply(glbl.enmWF.write_all_text, Have.UserBowl.SelKey(session_save_path_bowlname).Contents, stpOUTPUT)
    '        End If
    '    End Sub 'Save_UserTicket_Selection
    '    Public Shared Function Save_UserTicket_Selection_errhnd() As Strap
    '        Dim stpRET = Strapd()
    '        Save_UserTicket_Selection_errhnd = stpRET
    '        Dim objERR_LIST = New ErrListBase : Try
    '            Call Save_UserTicket_Selection()

    '        Catch ex As System.Exception
    '            Call objERR_LIST.dError_Stack(ex)
    '        End Try

    '        If objERR_LIST.Found Then
    '            stpRET.Clear().d(objERR_LIST.ToString)
    '        End If
    '    End Function 'Save_UserTicket_Selection_errhnd

    '    Public Shared Sub Submit_UserAddb_Ticket(ur_folder As ListBox, ur_new_env As ComboBox, ur_new_exporttype As ComboBox, ur_chk_sortby_ticketnum As CheckBox)
    '        Dim flnROOT = FileNamed().d(sCompany.Company_Source_Code_Repository.Server_Folder_Path)
    '        Dim strNEW_ENV = ur_new_env.Text
    '        Dim strNEWEXPORT_TYPE = ur_new_exporttype.Text
    '        Dim strNEW_DIR = strNEW_ENV & " " & strNEWEXPORT_TYPE
    '        flnROOT.d(strNEW_DIR)
    '        If HasText(strNEW_ENV) = False Then
    '            Throw New System.Exception("You must select an Environment Name")
    '        ElseIf HasText(strNEWEXPORT_TYPE) = False Then
    '            Throw New System.Exception("You must select an Export Type")
    '        Else
    '            Call glbl.gWindowsFS.Apply(glbl.enmWF.create_directory, flnROOT)
    '            Dim stpRET_MSG = Have.Repository.Apply(enmRA.reload_ticket_list, ur_folder, ur_chk_sortby_ticketnum)
    '            If stpRET_MSG.HasText Then
    '                Throw New System.Exception(stpRET_MSG)

    '            Else
    '                Call Mx.ListBoxSearch.Assign_SelectedIndex(ur_folder, strNEW_DIR)
    '            End If
    '        End If
    '    End Sub 'Submit_UserAddb_Ticket
    '    Public Shared Function Submit_UserAddb_Ticket_errhnd(ur_folder As System.Windows.Forms.ListBox, ur_new_env As System.Windows.Forms.ComboBox, ur_new_exporttype As System.Windows.Forms.ComboBox, ur_chk_sortby_ticketnum As System.Windows.Forms.CheckBox) As Strap
    '        Dim stpRET = Strapd()
    '        Submit_UserAddb_Ticket_errhnd = stpRET
    '        Dim objERR_LIST = New ErrListBase : Try
    '            Call Submit_UserAddb_Ticket(ur_folder, ur_new_env, ur_new_exporttype, ur_chk_sortby_ticketnum)

    '        Catch ex As System.Exception
    '            Call objERR_LIST.dError_Stack(ex)
    '        End Try

    '        If objERR_LIST.Found Then
    '            stpRET.Clear().d(objERR_LIST.ToString)
    '        End If
    '    End Function 'Submit_UserAddb_Ticket_errhnd

    '    Public Shared Sub Submit_UserSelection_AddFile_EnvVer(ur_ticket As Have.sTicket, ur_envver As Have.sSelEnvironment)
    '        ur_ticket.AddFile_EnvVer.Clear()
    '        For Each objENVVER In ur_envver
    '            ur_ticket.AddFile_EnvVer.Add(objENVVER)
    '        Next
    '    End Sub 'Submit_UserSelection_AddFile_EnvVer
    '    Public Shared Function Submit_UserSelection_AddFile_EnvVer_Primary_errhnd() As Strap
    '        Dim stpRET = Strapd()
    '        Submit_UserSelection_AddFile_EnvVer_Primary_errhnd = stpRET
    '        Dim objERR_LIST = New ErrListBase : Try
    '            For Each objTICKET In sCompany.Company_Source_Code_Repository.Active_Ticket
    '                Call Submit_UserSelection_AddFile_EnvVer(objTICKET, objTICKET.Primary_EnvVer)
    '            Next objTICKET

    '        Catch ex As System.Exception
    '            Call objERR_LIST.dError_Stack(ex)
    '        End Try

    '        If objERR_LIST.Found Then
    '            stpRET.Clear().d(objERR_LIST.ToString)
    '        End If
    '    End Function 'Submit_UserSelection_AddFile_EnvVer_Primary_errhnd
    '    Public Shared Function Submit_UserSelection_AddFile_EnvVer_Secondary_errhnd() As Strap
    '        Dim stpRET = Strapd()
    '        Submit_UserSelection_AddFile_EnvVer_Secondary_errhnd = stpRET
    '        Dim objERR_LIST = New ErrListBase : Try
    '            For Each objTICKET In sCompany.Company_Source_Code_Repository.Active_Ticket
    '                Call Submit_UserSelection_AddFile_EnvVer(objTICKET, objTICKET.Secondary_EnvVer)
    '            Next objTICKET

    '        Catch ex As System.Exception
    '            Call objERR_LIST.dError_Stack(ex)
    '        End Try

    '        If objERR_LIST.Found Then
    '            stpRET.Clear().d(objERR_LIST.ToString)
    '        End If
    '    End Function 'Submit_UserSelection_AddFile_EnvVer_Secondary_errhnd



    '    Public Shared Sub Submit_UserSession_Primary_EnvVer(ur_primary_envver As System.Windows.Forms.ListBox, ur_secondary_envver As System.Windows.Forms.ListBox)
    '        Dim user_primary_envver_entry_userbowl = enmUN.user_primary_envver_entry
    '        Dim strUSER_PRIMARY_ENVVER = Have.UserBowl.SelKey(user_primary_envver_entry_userbowl).Contents
    '        Dim company_repo = sCompany.Company_Source_Code_Repository
    '        For Each objTICKET In company_repo.Active_Ticket
    '            objTICKET.Apply(enmUTK.assign_primary_envver, strUSER_PRIMARY_ENVVER)
    '            objTICKET.Apply(enmUTK.assign_secondary_envver, mt)
    '            Call ur_secondary_envver.Items.Clear()
    '            For Each objENVVER In objTICKET.Primary_EnvVer
    '                If Mx.ListBoxSearch.Assign_SelectedIndex(ur_primary_envver, objENVVER.Name) Then
    '                    Dim stpRET = Submit_UserSession_Secondary_EnvVer_errhnd(ur_secondary_envver)
    '                    If stpRET.HasText Then
    '                        Throw New System.Exception(stpRET)

    '                    Else
    '                        For Each objENTRY In ur_primary_envver.Items
    '                            If AreEqual(objENTRY.ToString, objENVVER.Name) = False Then
    '                                Call ur_secondary_envver.Items.Add(objENTRY)
    '                            End If
    '                        Next objENTRY
    '                    End If 'stpRET

    '                Else
    '                    Call objTICKET.Primary_EnvVer.Clear()
    '                End If 'ur_folder

    '                Exit For
    '            Next objENVVER

    '            Exit For
    '        Next objTICKET
    '    End Sub 'Submit_UserSession_Primary_EnvVer
    '    Public Shared Function Submit_UserSession_Primary_EnvVer_errhnd(ur_primary_envver As System.Windows.Forms.ListBox, ur_secondary_envver As System.Windows.Forms.ListBox) As Strap
    '        Dim stpRET = Strapd()
    '        Submit_UserSession_Primary_EnvVer_errhnd = stpRET
    '        Dim objERR_LIST = New ErrListBase : Try
    '            Call Submit_UserSession_Primary_EnvVer(ur_primary_envver, ur_secondary_envver)

    '        Catch ex As System.Exception
    '            Call objERR_LIST.dError_Stack(ex)
    '        End Try

    '        If objERR_LIST.Found Then
    '            stpRET.Clear().d(objERR_LIST.ToString)
    '        End If
    '    End Function 'Submit_UserSession_Primary_EnvVer_errhnd

    '    Public Shared Sub Submit_UserSession_Secondary_EnvVer(ur_secondary_envver As System.Windows.Forms.ListBox)
    '        Dim user_secondary_envver_entry_userbowl = enmUN.user_compare_envver_entry
    '        Dim strUSER_SECONDARY_ENVVER = Have.UserBowl.SelKey(user_secondary_envver_entry_userbowl).Contents
    '        Dim company_repo = sCompany.Company_Source_Code_Repository
    '        For Each objTICKET In company_repo.Active_Ticket
    '            objTICKET.Apply(enmUTK.assign_secondary_envver, strUSER_SECONDARY_ENVVER)
    '            For Each objENVVER In objTICKET.Secondary_EnvVer
    '                If Mx.ListBoxSearch.Assign_SelectedIndex(ur_secondary_envver, objENVVER.Name) Then

    '                Else
    '                    Call objTICKET.Secondary_EnvVer.Clear()
    '                End If 'ur_folder

    '                Exit For
    '            Next objENVVER

    '            Exit For
    '        Next objTICKET
    '    End Sub 'Submit_UserSession_Secondary_EnvVer
    '    Public Shared Function Submit_UserSession_Secondary_EnvVer_errhnd(ur_secondary_envver As System.Windows.Forms.ListBox) As Strap
    '        Dim stpRET = Strapd()
    '        Submit_UserSession_Secondary_EnvVer_errhnd = stpRET
    '        Dim objERR_LIST = New ErrListBase : Try
    '            Call Submit_UserSession_Secondary_EnvVer(ur_secondary_envver)

    '        Catch ex As System.Exception
    '            Call objERR_LIST.dError_Stack(ex)
    '        End Try

    '        If objERR_LIST.Found Then
    '            stpRET.Clear().d(objERR_LIST.ToString)
    '        End If
    '    End Function 'Submit_UserSession_Secondary_EnvVer_errhnd
    'End Class 'Want

    Public Class Have
        Partial Class sEnvVer
            Public Sub Apply(ur_ticket As Have.rTicket, ur_envconn_cart As Have.sEnvConn)
                Dim strADDFILE_ENVVER = mt
                For Each row In Me.tteSelEnvironmentAddFile
                    strADDFILE_ENVVER = row.v(enmEV.env_name)
                    Exit For
                Next

                Dim strPRIMARY_ENVVER = mt
                For Each row In Me.tteSelEnvironmentBase
                    strPRIMARY_ENVVER = row.v(enmEV.env_name)
                    Exit For
                Next

                Dim strSECONDARY_ENVVER = mt
                For Each row In Me.tteSelEnvironmentCompare
                    strSECONDARY_ENVVER = row.v(enmEV.env_name)
                    Exit For
                Next

                Call Me.Clear()
                Dim bolFOUND_PRIMARY_ENVVER = False
                Dim bolFOUND_SECONDARY_ENVVER = False
                For Each flnENTRY As MxText.FileName In glbl.gWindowsFS.Apply(glbl.enmWF.get_directories, ur_ticket.v(enmHD.path), "*.*", System.IO.SearchOption.TopDirectoryOnly)
                    Dim strDIR_NAME = flnENTRY.Name
                    Dim strENV_CONN = strDIR_NAME
                    Dim strFILE_VER = mt
                    Dim intFOUND_SPRTR = InStrRev(strDIR_NAME, s)
                    If intFOUND_SPRTR > 0 Then
                        strENV_CONN = Mid(strDIR_NAME, 1, intFOUND_SPRTR - 1).Trim
                        strFILE_VER = Mid(strDIR_NAME, intFOUND_SPRTR + 1).Trim
                    End If

                    If ur_envconn_cart.ExistsKey(strENV_CONN) Then
                        Dim new_envver = New Have.rEnvVer()
                        'strDIR_NAME, ur_ticket, ur_envconn_cart.SelKey(strENV_CONN), strFILE_VER)
                        Me.InsKey(strDIR_NAME)
                        new_envver.vt(enmEV.file_ver, strFILE_VER)
                        new_envver.vt(enmEV.connection_string, ur_envconn_cart.SelKey(strENV_CONN).v(enmEC.connection_string))
                        new_envver.vt(enmEV.folder_name, strDIR_NAME)
                        If AreEqual(strDIR_NAME, strADDFILE_ENVVER) Then
                            Me.tteSelEnvironmentAddFile.Add(new_envver)
                            bolFOUND_PRIMARY_ENVVER = True
                        End If

                        If AreEqual(strDIR_NAME, strPRIMARY_ENVVER) Then
                            Me.tteSelEnvironmentBase.Add(new_envver)
                            bolFOUND_PRIMARY_ENVVER = True
                        End If

                        If AreEqual(strDIR_NAME, strSECONDARY_ENVVER) Then
                            Me.tteSelEnvironmentCompare.Add(new_envver)
                            bolFOUND_SECONDARY_ENVVER = True
                        End If
                    End If
                Next flnENTRY
            End Sub 'ur_env_ver
        End Class 'sEnvVer

        Partial Class rTicket
            Public Function Apply(ur_ordered_envver_list As enmUTK.zordered_envver_list) As Sdata
                Dim ret = New Sdata
                Apply = ret
                For Each objENV_VER In Me.EnvVerList.SelAll
                    Dim strNAME = objENV_VER.v(enmEV.env_name)
                    If ret.Contains(strNAME) = False Then
                        ret.Add(strNAME)
                    End If
                Next objENV_VER

                Call ret.Sort()
            End Function 'ur_ordered_envver_list
        End Class 'rTicket

        Partial Class sTicket
            Public Sub Apply(ur_repository As Have.sRepository, ur_userbowl_cart As Have.sUserBowl, ur_envconn As Have.sEnvConn)
                Dim repository_dir_bowlname = enmUN.repository_dir
                Dim hd_folder_search_bowlname = enmUN.hd_folder_search
                Dim strACTIVE_TICKET = mt
                For Each objTICKET In Me.ActiveTicket
                    strACTIVE_TICKET = objTICKET.v(enmHD.folder_name)
                    Exit For
                Next

                Call Me.Clear()
                Dim bolFOUND_ACTIVE_TICKET = False
                For Each flnENTRY As MxText.FileName In glbl.gWindowsFS.Apply(glbl.enmWF.get_directories, Have.UserBowl.SelKey(repository_dir_bowlname).Contents, Have.UserBowl.SelKey(hd_folder_search_bowlname).Contents, System.IO.SearchOption.TopDirectoryOnly)
                    Dim strDIR_NAME = flnENTRY.Name
                    Dim intHD_SUFFIX = InStr(strDIR_NAME, " hd")
                    Dim strTICKET = Trim(Mid(strDIR_NAME, intHD_SUFFIX))
                    Dim new_row = Me.InsKey(strTICKET)
                    new_row.vt(enmHD.folder_name, strDIR_NAME)
                    new_row.vt(enmHD.path, flnENTRY)
                    If AreEqual(strACTIVE_TICKET, strDIR_NAME) Then
                        Me.ActiveTicket.Add(new_row)
                        new_row.EnvVerList.Apply(new_row, Have.EnvConn)
                    End If
                Next flnENTRY
            End Sub 'Apply(ur_log_dir
        End Class 'sTicket

        Partial Class sUserBowl
            Public Function Apply(ur_app_folder As enmUN.zapp_folder, ur_testing_repository_dir As enmUN.ztesting_repository_dir) As enmUN.zrepository_dir
                Dim retKEY = enmUN.repository_dir
                Apply = retKEY
                Dim flnREPOSITORY_DIR = FileNamed().d(Me.SelKey(ur_app_folder).Contents).gParentDir
                If glbl.gWindowsFS.Apply(glbl.enmWF.has_file, flnREPOSITORY_DIR.gCopy.d(".gitignore")) = False Then
                    flnREPOSITORY_DIR.wClear().d(Me.SelKey(ur_testing_repository_dir).Contents)
                End If

                Me.SelKey(retKEY).Contents = flnREPOSITORY_DIR
            End Function 'Apply(ur_app_folder

            Public Function Apply(config_manager_cart As Have.sConfigManager, ur_log_dir As enmUN.zlog_dir, ur_spprocdef_export_hunt_appsetting As enmCM.zsqlprocdef_script, ur_spprocdef_export_hunt_script As enmUN.zspprocdef_export_hunt_script) As enmUN.zspprocdef_export_exe_path
                Dim retKEY = enmUN.spprocdef_export_exe_path
                Apply = retKEY
                Dim flnLOG_DIR = FileNamed().d(Me.SelKey(ur_log_dir).Contents)
                Dim sdaHUNT_PATH = New Sdata
                sdaHUNT_PATH.d(flnLOG_DIR.gCopy.d(config_manager_cart.SelKeyValue(ur_spprocdef_export_hunt_appsetting)).dAppendEXT(".vbscript.cmd"))
                sdaHUNT_PATH.d(flnLOG_DIR.gCopy.d(Me.SelKey(ur_spprocdef_export_hunt_script).Contents))
                For Each strENTRY In sdaHUNT_PATH
                    If glbl.gWindowsFS.Apply(glbl.enmWF.has_file, strENTRY) Then
                        Me.SelKey(retKEY).Contents = strENTRY
                        Exit For
                    End If
                Next strENTRY
            End Function 'Apply(config_manager_cart

            Public Function Apply(config_manager_cart As Have.sConfigManager, ur_hosting_app_hunt_title As enmCM.zhosting_app_title, ur_hosting_app_hunt_default As enmUN.zhosting_app_hunt_default) As enmUN.zhosting_app_appactivate_title
                Dim retKEY = enmUN.hosting_app_appactivate_title
                Apply = retKEY
                Dim sdaHUNT_PATH = New Sdata
                sdaHUNT_PATH.d(config_manager_cart.SelKeyValue(ur_hosting_app_hunt_title))
                sdaHUNT_PATH.d(Me.SelKey(ur_hosting_app_hunt_default).Contents)
                For Each strENTRY In sdaHUNT_PATH
                    If HasText(strENTRY) Then
                        Me.SelKey(retKEY).Contents = strENTRY
                        Exit For
                    End If
                Next strENTRY
            End Function 'Apply(config_manager_cart

            Public Function Apply(ur_session_save_path As enmUN.zsession_save_path) As System.Tuple(Of enmUN.zuser_hdfolder_entry, enmUN.zuser_primary_envver_entry, enmUN.zuser_compare_envver_entry)
                Dim user_hdfolder_entry_bowlname = enmUN.user_hdfolder_entry
                Dim user_primary_envver_entry_bowlname = enmUN.user_primary_envver_entry
                Dim user_compare_envver_entry_bowlname = enmUN.user_compare_envver_entry
                Apply = New System.Tuple(Of enmUN.zuser_hdfolder_entry, enmUN.zuser_primary_envver_entry, enmUN.zuser_compare_envver_entry)(user_hdfolder_entry_bowlname, user_primary_envver_entry_bowlname, user_compare_envver_entry_bowlname)
                Dim flnSESSION_DATA_PATH = FileNamed().d(Mx.Have.UserBowl.SelKey(ur_session_save_path).Contents)
                For Each strFILE_PATH In glbl.gWindowsFS.Apply(glbl.enmWF.get_files, flnSESSION_DATA_PATH.gParentDir, flnSESSION_DATA_PATH.Name, System.IO.SearchOption.TopDirectoryOnly)
                    Using stmSESSION_DATA = New System.IO.StreamReader(strFILE_PATH, gUTF8_FileEncoding)
                        Dim intINDEX = 0
                        While stmSESSION_DATA.EndOfStream = False
                            Dim strLINE = stmSESSION_DATA.ReadLine
                            intINDEX += 1
                            Select Case intINDEX
                                Case 1
                                    Have.UserBowl.SelKey(user_hdfolder_entry_bowlname).Contents = strLINE
                                Case 2
                                    Have.UserBowl.SelKey(user_primary_envver_entry_bowlname).Contents = strLINE
                                Case 3
                                    Have.UserBowl.SelKey(user_compare_envver_entry_bowlname).Contents = strLINE
                            End Select 'intINDEX
                        End While
                    End Using 'stmSESSION_DATA
                Next strFILE_PATH
            End Function 'Apply(ur_session_save_path

            Public Function Apply(ur_log_dir As enmUN.zlog_dir, ur_app_name As enmUN.zapp_name) As enmUN.zsession_save_path
                Dim retKEY = enmUN.session_save_path
                Apply = retKEY
                Dim flnLOG_DIR = FileNamed().d(Me.SelKey(ur_log_dir).Contents)
                Dim flnSESSION_FILE_PATH = flnLOG_DIR.gCopy.d(Me.SelKey(ur_app_name).Contents).dAppendEXT(".session")
                Me.SelKey(retKEY).Contents = flnSESSION_FILE_PATH
            End Function 'Apply(ur_log_dir

            Public Function Apply(ur_log_dir As enmUN.zlog_dir, ur_beyond_compare_hunt_script As enmUN.zbeyond_compare_hunt_script, ur_beyond_compare_hunt_path As enmUN.zbeyond_compare_hunt_path) As enmUN.zbeyond_compare_exe_path
                Dim retKEY = enmUN.beyond_compare_exe_path
                Apply = retKEY
                Dim flnLOG_DIR = FileNamed().d(Me.SelKey(ur_log_dir).Contents)
                Dim sdaHUNT_PATH = New Sdata
                sdaHUNT_PATH.d(flnLOG_DIR.gCopy.d(Me.SelKey(ur_beyond_compare_hunt_script).Contents))
                sdaHUNT_PATH.d(FileNamed().d(Me.SelKey(ur_beyond_compare_hunt_path).Contents))
                For Each strENTRY In sdaHUNT_PATH
                    If glbl.gWindowsFS.Apply(glbl.enmWF.has_file, strENTRY) Then
                        Me.SelKey(retKEY).Contents = strENTRY
                        Exit For
                    End If
                Next strENTRY
            End Function 'Apply(ur_log_dir

            Public Function Apply(ur_log_dir As enmUN.zlog_dir, ur_notepad_pp_hunt_script_e1 As enmUN.znotepad_pp_hunt_script_e1, ur_notepad_pp_hunt_script_e2 As enmUN.znotepad_pp_hunt_script_e2, ur_notepad_pp_hunt_path_e1 As enmUN.znotepad_pp_hunt_path_e1, ur_notepad_pp_hunt_path_e2 As enmUN.znotepad_pp_hunt_path_e2) As enmUN.znotepad_pp_exe_path
                Dim retKEY = enmUN.notepad_pp_exe_path
                Apply = retKEY
                Dim flnLOG_DIR = FileNamed().d(Me.SelKey(ur_log_dir).Contents)
                Dim sdaHUNT_PATH = New Sdata
                sdaHUNT_PATH.d(FileNamed().d(Me.SelKey(ur_notepad_pp_hunt_path_e1).Contents))
                sdaHUNT_PATH.d(FileNamed().d(Me.SelKey(ur_notepad_pp_hunt_path_e2).Contents))
                sdaHUNT_PATH.d(flnLOG_DIR.gCopy.d(Me.SelKey(ur_notepad_pp_hunt_script_e1).Contents))
                sdaHUNT_PATH.d(flnLOG_DIR.gCopy.d(Me.SelKey(ur_notepad_pp_hunt_script_e2).Contents))
                For Each strENTRY In sdaHUNT_PATH
                    If glbl.gWindowsFS.Apply(glbl.enmWF.has_file, strENTRY) Then
                        Me.SelKey(retKEY).Contents = strENTRY
                        Exit For
                    End If
                Next strENTRY
            End Function 'Apply(ur_log_dir

            Public Function Apply(ur_repository_dir As enmUN.zrepository_dir) As enmUN.zlog_dir
                Dim retKEY = enmUN.log_dir
                Apply = retKEY
                Dim flnLOG_DIR = FileNamed().d(Me.SelKey(ur_repository_dir).Contents).d("SpProcDef")
                Me.SelKey(retKEY).Contents = flnLOG_DIR
            End Function 'Apply(ur_repository_dir

            Public Function Apply(ur_spprocdef_export_exe_path As enmUN.zspprocdef_export_exe_path) As enmUN.zspprocdef_export_error_search
                Dim retKEY = enmUN.spprocdef_export_error_search
                Apply = retKEY
                Dim flnSPPROCDEF_PATH = FileNamed().d(Me.SelKey(ur_spprocdef_export_exe_path).Contents)
                Me.SelKey(retKEY).Contents = flnSPPROCDEF_PATH.gParentDir.d(flnSPPROCDEF_PATH.Name & "*").dAppendEXT(".err.txt")
            End Function 'Apply(ur_spprocdef_export_exe_path
        End Class 'sUserBowl


        Partial Class sWindowsFS
            Public Sub Apply(ur_log_dir As enmUN.zlog_dir, ur_app_settings_dir As enmUN.zapp_settings_dir, ur_app_config_file As enmUN.zapp_config_file)
                Dim flnLOG_DIR = FileNamed().d(Have.UserBowl.SelKey(ur_log_dir).Contents)
                Dim flnAPP_SETTING_DIR = FileNamed().d(Have.UserBowl.SelKey(ur_app_settings_dir).Contents)
                Dim strCONFIG_FILE = Have.UserBowl.SelKey(ur_app_config_file).Contents
                If AreEqual(flnLOG_DIR, flnAPP_SETTING_DIR) = False Then
                    Call glbl.gWindowsFS.Apply(glbl.enmWF.copy, flnLOG_DIR.gCopy.d(strCONFIG_FILE), flnAPP_SETTING_DIR.gCopy.d(strCONFIG_FILE))
                End If
            End Sub 'Apply(ur_log_dir
        End Class 'sWindowsFS
    End Class 'Have



    'Public Class HDFolders
    '    Inherits System.Collections.Generic.List(Of OneHDFolder)

    '    Public Class OneHDFolder
    '        Public Name As String
    '        Public Sort_Value As String
    '        Public Path As String
    '        Public Environment_Folders As Environment_Folders
    '        Public Notes_Files As Notes_Files

    '        Public Function Refresh_Environment_Folders() As Environment_Folders
    '            Me.Environment_Folders = New Environment_Folders(Me.Path)
    '            Refresh_Environment_Folders = Me.Environment_Folders
    '        End Function

    '        Public Function Refresh_Notes_Files() As Notes_Files
    '            Me.Notes_Files = New Notes_Files(Me.Path)
    '            Refresh_Notes_Files = Me.Notes_Files
    '        End Function
    '    End Class 'OneHDFolder

    '    Public Class Environment_Folders
    '        Inherits System.Collections.Generic.List(Of OneEnvironmentFolder)

    '        Public Class OneEnvironmentFolder
    '            Public Name As String
    '            Public BaseConnection_String As String
    '            Public IsAppActivate As Boolean
    '            Public DBConnection_String As String
    '            Public Environment_Name As String
    '            Public Path As String
    '            Public Environment_Files As Environment_Files

    '            Public Function Refresh_Environment_Files() As Environment_Files
    '                Me.Environment_Files = New Environment_Files(Me.Path)
    '                Refresh_Environment_Files = Me.Environment_Files
    '            End Function
    '        End Class 'OneEnvironmentFolder

    '        Public Sub New(ur_hdfolder_path As String)
    '            Dim strcSERVER = "server="
    '            Dim strcAPPDB = "appdb="

    '            For Each strPATH In System.IO.Directory.EnumerateDirectories(ur_hdfolder_path, "*", System.IO.SearchOption.TopDirectoryOnly)
    '                Dim new_environment_folder = New OneEnvironmentFolder
    '                new_environment_folder.Name = System.IO.Path.GetFileName(strPATH)
    '                new_environment_folder.Environment_Name = new_environment_folder.Name.Split(" "c).First
    '                new_environment_folder.Path = strPATH

    '                For Each entry In From row In Database.Environments Where row.Name = new_environment_folder.Environment_Name
    '                    new_environment_folder.Environment_Files = New Environment_Files(new_environment_folder.Path)
    '                    new_environment_folder.BaseConnection_String = entry.Connection_String
    '                    new_environment_folder.IsAppActivate = Mx.AreEqual(new_environment_folder.BaseConnection_String, "AppActivate")
    '                    Dim strSERVER_NAME = ""
    '                    Dim strAPPDB_NAME = ""
    '                    For Each strENTRY In entry.Connection_String.Split("/"c)
    '                        If Mid(strENTRY.ToLower, 1, Len(strcSERVER)) = strcSERVER Then
    '                            strSERVER_NAME = Trim(Mid(strENTRY, Len(strcSERVER) + 1))
    '                        End If

    '                        If Mid(strENTRY.ToLower, 1, Len(strcAPPDB)) = strcAPPDB Then
    '                            strAPPDB_NAME = Trim(Mid(strENTRY, Len(strcAPPDB) + 1))
    '                        End If
    '                    Next strENTRY

    '                    new_environment_folder.DBConnection_String = String.Format("Server={0};Database={1};Integrated Security=SSPI", strSERVER_NAME, strAPPDB_NAME)
    '                    Me.Add(new_environment_folder)
    '                Next entry
    '            Next strPATH
    '        End Sub 'New

    '        Public Class Environment_Files
    '            Inherits System.Collections.Generic.List(Of OneEnvironmentFolder)

    '            Public Class OneEnvironmentFolder
    '                Public Name As String
    '                Public Path As String
    '            End Class

    '            Public Sub New(ur_envfolder_path As String)
    '                For Each strPATH In System.IO.Directory.EnumerateFiles(ur_envfolder_path, "*.*", System.IO.SearchOption.AllDirectories)
    '                    Dim new_environment_folder = New OneEnvironmentFolder
    '                    new_environment_folder.Name = System.IO.Path.Combine(System.IO.Path.GetFileName(System.IO.Path.GetDirectoryName(strPATH)), System.IO.Path.GetFileName(strPATH))
    '                    new_environment_folder.Path = strPATH
    '                    Me.Add(new_environment_folder)
    '                Next strPATH
    '            End Sub 'New
    '        End Class 'Environment_Files
    '    End Class 'Environment_Folders


    '    Public Class Notes_Files
    '        Inherits System.Collections.Generic.List(Of OneNotesFile)

    '        Public Class OneNotesFile
    '            Public Name As String
    '            Public Path As String
    '        End Class

    '        Public Sub New(ur_hdfolder_path As String)
    '            For Each strNOTE_DIR In System.IO.Directory.EnumerateDirectories(ur_hdfolder_path, "Notes")
    '                For Each strPATH In System.IO.Directory.EnumerateDirectories(strNOTE_DIR, "*", System.IO.SearchOption.TopDirectoryOnly)
    '                    Dim new_notes_file = New OneNotesFile
    '                    new_notes_file.Name = System.IO.Path.GetFileName(strPATH)
    '                    new_notes_file.Path = strPATH
    '                    Me.Add(new_notes_file)
    '                Next strPATH
    '            Next strNOTE_DIR
    '        End Sub 'New
    '    End Class 'Notes_Files

    'End Class 'HDFolders


    Public Class ListBoxSearch
        Public Shared Function Assign_SelectedIndex(ur_listbox As System.Windows.Forms.ListBox, ur_text As String) As Boolean
            Assign_SelectedIndex = False
            ur_listbox.SelectedIndex = -1
            Dim intFOUND_INDEX = ListBoxSearch.IndexOf_c(ur_listbox, ur_text)
            If intFOUND_INDEX >= 0 Then
                Assign_SelectedIndex = True
                ur_listbox.SelectedIndex = intFOUND_INDEX
            End If
        End Function 'Assign_SelectedIndex

        Public Shared Function IndexOf_c(ur_listbox As System.Windows.Forms.ListBox, ur_text As String) As Integer
            IndexOf_c = -1
            For ENTCTR = 0 To ur_listbox.Items.Count - 1
                If String.Equals(ur_listbox.Items.Item(ENTCTR).ToString, ur_text, System.StringComparison.CurrentCultureIgnoreCase) Then
                    IndexOf_c = ENTCTR
                    Exit For
                End If
            Next ENTCTR
        End Function 'IndexOf_c

        Public Shared Function gCurEntry(ur_cbo_box As System.Windows.Forms.ComboBox) As String
            gCurEntry = mt
            Dim strSRCH_TEXT = ur_cbo_box.Text
            For ENTCTR = 0 To ur_cbo_box.Items.Count - 1
                If String.Equals(ur_cbo_box.Items.Item(ENTCTR).ToString, strSRCH_TEXT, System.StringComparison.CurrentCultureIgnoreCase) Then
                    gCurEntry = ur_cbo_box.Items.Item(ENTCTR).ToString
                    Exit For
                End If
            Next ENTCTR
        End Function 'gCurEntry

        Public Shared Function gCurEntry(ur_listbox As System.Windows.Forms.ListBox) As String
            gCurEntry = mt
            Dim intFOUND_INDEX = ur_listbox.SelectedIndex
            If intFOUND_INDEX >= 0 Then
                gCurEntry = ur_listbox.Items.Item(intFOUND_INDEX).ToString
            End If
        End Function 'gCurEntry
    End Class 'ListBoxSearch

    Public Class WindowSearch
        Public Sub Example_Exec_ListAdd()
            Mx.WindowSearch.EnumWindowsDllImport(New Mx.WindowSearch.EnumWindowsCallback(AddressOf Example_FillActiveWindowsList_InListBox), 0)
        End Sub

        Public Function Example_FillActiveWindowsList_InListBox(ByVal hWnd As Integer, ByVal lParam As Integer) As Boolean
            Example_FillActiveWindowsList_InListBox = True
            Dim stbFOUND_TITLE As New System.Text.StringBuilder(255)
            Mx.WindowSearch.GetWindowText(hWnd, stbFOUND_TITLE, 255)
            Dim bolIS_ACTIVE = Mx.WindowSearch.ProcessIsActiveWindow(hWnd)
            Dim strFOUND_TITLE = stbFOUND_TITLE.ToString
            Dim strFOLDER = strFOUND_TITLE
            Dim intFOLDER = InStr(strFOUND_TITLE.ToUpper, " - XYPLORER")
            If intFOLDER > 0 Then
                strFOLDER = Mid(strFOUND_TITLE, 1, intFOLDER - 1)
            End If

            Dim intHD_FOLDER = InStr(strFOLDER, " hd")
            'Dim bolEXISTS_IN_LIST = Me.lstFolder.Items.Contains(strFOLDER)
            If bolIS_ACTIVE AndAlso
              intFOLDER > 0 AndAlso
              intHD_FOLDER > 0 Then 'AndAlso
                'bolEXISTS_IN_LIST = False Then
                'Me.lstFolder.Items.Insert(0, strFOLDER)
            End If
        End Function 'Example_FillActiveWindowsList_InListBox


        Public Delegate Function EnumWindowsCallback _
          (
            ByVal hWnd As Integer,
            ByVal lParam As Integer
          ) As Boolean

        Public Declare Function EnumWindows Lib "user32.dll" Alias "EnumWindows" _
          (
            ByVal callback As EnumWindowsCallback,
            ByVal lParam As Integer
          ) As Integer

        <System.Runtime.InteropServices.DllImport(
            "user32.dll",
            EntryPoint:="EnumWindows", SetLastError:=True,
            CharSet:=System.Runtime.InteropServices.CharSet.Ansi,
            ExactSpelling:=True,
            CallingConvention:=System.Runtime.InteropServices.CallingConvention.StdCall
          )>
        Public Shared Function EnumWindowsDllImport _
          (
            ByVal callback As EnumWindowsCallback,
            ByVal lParam As Integer
          ) As Integer
        End Function

        Public Declare Sub GetWindowText Lib "user32.dll" Alias "GetWindowTextA" _
          (
            ByVal hWnd As Integer,
            ByVal lpString As System.Text.StringBuilder,
            ByVal nMaxCount As Integer
          )

        Public Declare Function GetWindowLong Lib "user32.dll" Alias "GetWindowLongA" _
          (
            ByVal hwnd As Integer,
            ByVal nIndex As Integer
          ) As Integer

        Public Declare Function GetWindow Lib "user32.dll" Alias "GetWindow" _
          (
            ByVal hwnd As Integer,
            ByVal wCmd As Integer
          ) As Integer

        Public Declare Function IsWindowVisible Lib "user32.dll" Alias "IsWindowVisible" _
          (
            ByVal hwnd As Integer
          ) As Boolean

        Public Declare Function GetParent Lib "user32.dll" Alias "GetParent" _
          (
            ByVal hwnd As Integer
          ) As Integer

        Public Const GWL_EXSTYLE As Integer = (-20)
        Public Const WS_EX_TOOLWINDOW As Integer = &H80
        Public Const WS_EX_APPWINDOW As Integer = &H40000

        Public Shared Function ProcessIsActiveWindow(ByVal ur_window_hdl As Integer) As Boolean
            Dim stbWINDOW_TEXT As New System.Text.StringBuilder(255)
            Call GetWindowText(ur_window_hdl, stbWINDOW_TEXT, 255)
            Dim bolWINDOW_IS_OWNED = GetWindow(ur_window_hdl, 4) <> 0
            Dim intWINDOW_STYLE_CODE = GetWindowLong(ur_window_hdl, GWL_EXSTYLE)

            If Not IsWindowVisible(ur_window_hdl) Then
                Return False
            End If

            If System.String.IsNullOrWhiteSpace(stbWINDOW_TEXT.ToString) Then
                Return False
            End If

            If Mx.WindowSearch.GetParent(ur_window_hdl) <> 0 Then
                Return False
            End If

            If (intWINDOW_STYLE_CODE And WS_EX_TOOLWINDOW) <> 0 And bolWINDOW_IS_OWNED = False Then
                Return False
            End If

            If (intWINDOW_STYLE_CODE And WS_EX_APPWINDOW) = 0 And bolWINDOW_IS_OWNED Then
                Return False
            End If

            Return True
        End Function
    End Class 'WindowsSearch
End Namespace 'Mx