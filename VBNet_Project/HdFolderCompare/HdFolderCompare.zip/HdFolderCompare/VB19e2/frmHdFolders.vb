﻿Option Strict On
Option Infer On

Imports System.ComponentModel
Imports System.Windows.Forms
Imports HdFolderCompare.Mx

Public Class frmHdFolders
    'Public objvCOMPARE_LIST As System.Windows.Forms.ListBox
    'Public bolvLEAVE_FILE As Boolean
    'Public strvDB_PARM As String
    'Public strvCOMPARE_FILE As String
    'Public strvCURRENT_EXPORT_FOLDER As String
    'Public strvCURRENT_COMPARE_FOLDER As String
#Region "Start Up"
    Private Sub frmHdFolders_Load(sender As Object, e As System.EventArgs) Handles MyBase.Load
        Dim stpRET = Mx.Have.ConfigManager.Apply_errhnd(Me.lblVerNum, Me.Timer1, Me.cboNewExport_Type)

        If stpRET.HasText = False Then
            stpRET = Mx.Have.Repository.Apply_errhnd(Me.lstFolder, Me.chkSortByTicket)
        End If

        If stpRET.HasText = False Then
            stpRET = Mx.Have.Repository.Apply_errhnd(Me.lstFolder, Nothing, Me.lstEnv, Me.lstCompare, Me.btnTicket_Folder, Me.TabControl1)
        End If

        If stpRET.HasText Then
            Mx.Have.MessageDialog.Apply(enmMSB.ok_only, stpRET)
            Me.Close()

        Else
            'Call lstFolder_KeyPress()

            'Dim found_environment_folder = User_Selection.Environment_Selected
            'If found_environment_folder.Count = 0 Then
            '    User_Selection.Environment_Entry = ""
            '    User_Selection.Comparison_Entry = ""

            'Else
            '    Me.lstEnv.SelectedIndex = Mx.ListBoxSearch.IndexOf_c(Me.lstEnv, User_Selection.Environment_Entry)
            '    Call lstEnv_KeyPress()

            '    Dim found_compare_folder = User_Selection.Comparison_Selected
            '    If found_compare_folder.Count = 0 Then
            '        User_Selection.Comparison_Entry = ""

            '    Else
            '        Me.lstCompare.SelectedIndex = Mx.ListBoxSearch.IndexOf_c(Me.lstCompare, User_Selection.Comparison_Entry)
            '        Call lstCompare_KeyPress()
            '    End If 'found_environment_folder

            'End If 'found_environment_folder
        End If 'stpRET
    End Sub 'frmHdFolders_Load

    'Private Sub frmHdFolders_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
    '    Dim stpRET = Mx.Want.Save_UserTicket_Selection_errhnd()
    '    Mx.Have.MessageDialog.Apply(enmMSB.ok_only, stpRET)
    'End Sub 'frmHdFolders_Closing
#End Region

#Region "Folders tab"
#End Region

    'Private Sub btnAddEnv_Click(sender As Object, e As System.EventArgs) Handles btnAddEnv.Click
    '    Dim stpRET = Mx.Want.Submit_UserAddb_Ticket_errhnd(Me.lstFolder, Me.cboNew_Env, Me.cboNewExport_Type, Me.chkSortByTicket)
    '    If stpRET.HasText = False Then
    '        stpRET = Mx.Want.Submit_UserSelection_Ticket_errhnd(Me.lstFolder, Nothing, Me.lstEnv, Me.lstCompare, Me.btnTicket_Folder, Me.TabControl1)
    '    End If

    '    Mx.Have.MessageDialog.Apply(enmMSB.ok_only, stpRET)
    'End Sub 'btnAddEnv_Click

    'Private Sub btnAddFileCompare_Click(sender As Object, e As System.EventArgs) Handles btnAddFileCompare.Click
    '    Dim stpRET = Mx.Want.Submit_UserSelection_AddFile_EnvVer_Secondary_errhnd()
    '    If stpRET.HasText = False Then
    '        Call frmFileSearch.ShowDialog()
    '    End If

    '    Mx.Have.MessageDialog.Apply(enmMSB.ok_only, stpRET)
    'End Sub 'btnAddFileCompare_Click

    'Private Sub btnAddFileFirst_Click(sender As Object, e As System.EventArgs) Handles btnAddFileFirst.Click
    '    Dim stpRET = Mx.Want.Submit_UserSelection_AddFile_EnvVer_Primary_errhnd()
    '    If stpRET.HasText = False Then
    '        Call frmFileSearch.ShowDialog()
    '    End If

    '    Mx.Have.MessageDialog.Apply(enmMSB.ok_only, stpRET)
    'End Sub 'btnAddFileFirst_Click

    'Public Enum enmEXPORT_OPTION
    '    none
    '    one
    '    multiple
    'End Enum

    'Public Sub btnAddFile_Return(ur_file As String, Optional ur_export_option As enmEXPORT_OPTION = enmEXPORT_OPTION.one)
    '    If ur_export_option = enmEXPORT_OPTION.multiple Then
    '        Call Database.FolderCallback.Side_Export_Click()

    '    Else 'ur_export_option
    '        Dim lstCOMP = Database.FolderCallback.FileList
    '        Dim strCOMP_FOLDER = User_Selection.Environment_Entry
    '        For Each curHDFolder In User_Selection.HDFolder_Selected
    '            Dim strROOT = curHDFolder.Path
    '            Dim intCOMP_FOUND = Mx.ListBoxSearch.IndexOf_c(lstCOMP, ur_file)
    '            If ur_file <> "" AndAlso
    '              intCOMP_FOUND < 0 Then
    '                intCOMP_FOUND = lstCOMP.Items.Add(ur_file)
    '                Dim strFILE_PATH = System.IO.Path.Combine(strROOT, strCOMP_FOLDER & ur_file)
    '                Dim strPARENT_PATH = System.IO.Path.GetDirectoryName(strFILE_PATH)
    '                If System.IO.Directory.Exists(strPARENT_PATH) = False Then
    '                    Call System.IO.Directory.CreateDirectory(strPARENT_PATH)
    '                End If

    '                If System.IO.File.Exists(strFILE_PATH) = False Then
    '                    Call System.IO.File.WriteAllText(strFILE_PATH, "")
    '                End If
    '            End If 'ur_file

    '            If ur_file <> "" Then
    '                lstCOMP.SelectedIndex = intCOMP_FOUND
    '                If ur_export_option = enmEXPORT_OPTION.one Then
    '                    Call Database.FolderCallback.Side_Export_Click()
    '                End If
    '            End If
    '        Next curHDFolder
    '    End If 'ur_export_option
    'End Sub 'btnAddFile_Return

    'Private Sub btnAddNote_Click(sender As Object, e As System.EventArgs) Handles btnAddNote.Click
    '    Dim strNEW_NOTE = Me.lstNoteType.Text
    '    If strNEW_NOTE <> "" Then
    '        strNEW_NOTE = "\NOTES\" & strNEW_NOTE & ".TXT"
    '        Dim intNOTE_FOUND = Mx.ListBoxSearch.IndexOf_c(Me.lstNoteFile, strNEW_NOTE)
    '        If intNOTE_FOUND < 0 Then
    '            For Each curHDFolder In User_Selection.HDFolder_Selected
    '                Dim strROOT = curHDFolder.Path
    '                Dim strNOTE_DIR = System.IO.Path.Combine(strROOT, "Notes")
    '                If System.IO.Directory.Exists(strNOTE_DIR) = False Then
    '                    Call System.IO.Directory.CreateDirectory(strNOTE_DIR)
    '                End If

    '                Dim strNOTE_PATH = strROOT & strNEW_NOTE
    '                If System.IO.File.Exists(strNOTE_PATH) = False Then
    '                    System.IO.File.WriteAllText(strNOTE_PATH, "")
    '                End If

    '                Me.lstNoteFile.Items.Add(strNEW_NOTE)
    '                intNOTE_FOUND = Mx.ListBoxSearch.IndexOf_c(Me.lstNoteFile, strNEW_NOTE)
    '            Next curHDFolder
    '        End If 'Me.lstNoteFile

    '        lstNoteFile.SelectedIndex = intNOTE_FOUND
    '        lstNoteFile_KeyPress()
    '    End If 'strNEW_NOTE
    'End Sub 'btnAddNote_Click

    'Public Sub btnAddTicket_Click(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing, Optional ur_ticket_folder As String = "") Handles btnAddTicket.Click
    '    Dim strTICKET = ""
    '    Dim intFOUND_INDEX = InStr(ur_ticket_folder, " hd")
    '    If intFOUND_INDEX > 0 Then
    '        strTICKET = Mid(ur_ticket_folder, intFOUND_INDEX + Len(" hd"))
    '    End If

    '    If strTICKET = "" Then
    '        strTICKET = InputBox("Please enter ticket number", "New Ticket Folder")
    '    End If

    '    If strTICKET <> "" Then
    '        Dim strNEW_FOLDER = ur_ticket_folder
    '        Dim bolENTRY_FOUND = False
    '        If ur_ticket_folder = "" Then
    '            strNEW_FOLDER = Today.ToString("yyyy") & "m" & Today.ToString("MM") & "d" & Today.ToString("dd") & " hd" & strTICKET
    '            For ENTCTR = 0 To Me.lstFolder.Items.Count - 1
    '                Dim strCUR_ENTRY = Me.lstFolder.Items(ENTCTR).ToString().ToUpper
    '                Dim intFOUND_SPRTR = InStrRev(strCUR_ENTRY, " hd")
    '                If intFOUND_SPRTR >= 0 Then
    '                    strCUR_ENTRY = Mid(strCUR_ENTRY, intFOUND_SPRTR + Len(" hd"))
    '                End If

    '                If strCUR_ENTRY = strTICKET.ToUpper Then
    '                    Me.lstFolder.SelectedIndex = ENTCTR
    '                    bolENTRY_FOUND = True
    '                    Exit For
    '                End If
    '            Next ENTCTR
    '        End If 'ur_ticket_folder

    '        If bolENTRY_FOUND = False Then
    '            Dim strNEW_PATH = System.IO.Path.Combine(Mx.Have.UserBowl.SelKey(Mx.enmUN.repository_dir).Contents, strNEW_FOLDER)
    '            If System.IO.Directory.Exists(strNEW_PATH) = False Then
    '                Call System.IO.Directory.CreateDirectory(strNEW_PATH)
    '            End If

    '            Me.lstFolder.Items.Insert(0, strNEW_FOLDER)
    '            Me.lstFolder.SelectedIndex = 0
    '        End If

    '        Me.ActiveControl = Me.lstFolder
    '        Call btnRefresh_Folders_Click()
    '    End If 'strTICKET
    'End Sub 'btnAddTicket_Click

    'Public Sub btnC_Export_Click(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles btnC_Export.Click
    '    For Each env_entry In User_Selection.Comparison_Selected
    '        Call FolderExport(env_entry)
    '    Next
    '    Call Reable_All_Buttons(False)
    'End Sub

    'Private Sub btnC_Folder_Click(sender As Object, e As System.EventArgs) Handles btnC_Folder.Click
    '    Me.TabControl1.SelectedTab = Me.tabCompare
    'End Sub

    'Private Sub btnClear_Click(sender As Object, e As System.EventArgs) Handles btnClear.Click
    '    For Each curHDFolder In User_Selection.HDFolder_Selected
    '        Dim strROOT = curHDFolder.Path
    '        Dim flnSEARCH_PATH = Mx.FileNamed().d(Mx.Have.UserBowl.SelKey(Mx.enmUN.spprocdef_export_error_search).Contents)
    '        For Each strFILE_PATH In System.IO.Directory.EnumerateFiles(flnSEARCH_PATH.gParentDir, flnSEARCH_PATH.Name)
    '            System.IO.File.Delete(strFILE_PATH)
    '        Next

    '        For Each strFOLDER_PATH In System.IO.Directory.EnumerateDirectories(strROOT)
    '            For Each entry In Database.Environments
    '                If System.IO.Path.GetFileName(strFOLDER_PATH).ToUpper = entry.Name.ToUpper Then
    '                    System.IO.Directory.Delete(strFOLDER_PATH, True)
    '                    Exit For
    '                End If
    '            Next entry
    '        Next strFOLDER_PATH

    '        Call Reable_All_Buttons(False)
    '    Next curHDFolder
    'End Sub 'btnClear_Click

    'Private Sub btnCompare_Click(sender As Object, e As System.EventArgs) Handles btnCompare.Click
    '    For Each curHDFolder In User_Selection.HDFolder_Selected
    '        Dim strROOT = curHDFolder.Path
    '        Dim strE_PATH = ""
    '        If Me.lstEnv.SelectedIndex >= 0 Then
    '            strE_PATH = System.IO.Path.Combine(strROOT, Me.lstEnv.SelectedItem.ToString)
    '        End If

    '        Dim strC_PATH = ""
    '        If Me.lstCompare.SelectedIndex >= 0 Then
    '            strC_PATH = System.IO.Path.Combine(strROOT, Me.lstCompare.SelectedItem.ToString)
    '        End If

    '        If System.IO.File.Exists(Mx.Have.UserBowl.SelKey(Mx.enmUN.beyond_compare_exe_path).Contents) = False Then
    '            MsgBox("Cannot find path to run program: " & Mx.Have.UserBowl.SelKey(Mx.enmUN.beyond_compare_exe_path).Contents)
    '        ElseIf Microsoft.VisualBasic.Right(Mx.Have.UserBowl.SelKey(Mx.enmUN.beyond_compare_exe_path).Contents, 4).ToLower = ".cmd" Then
    '            System.Diagnostics.Process.Start(Mx.Have.UserBowl.SelKey(Mx.enmUN.beyond_compare_exe_path).Contents, "/root_dir=" & """" & strROOT.Replace("""", """""") & """" & " /out_subdir=" & """" & strE_PATH.Replace("""", """""") & """" & " /in_subdir=" & """" & strC_PATH.Replace("""", """""") & """")
    '        Else
    '            System.Diagnostics.Process.Start(Mx.Have.UserBowl.SelKey(Mx.enmUN.beyond_compare_exe_path).Contents, """" & strE_PATH.Replace("""", """""") & """" & " " & """" & strC_PATH.Replace("""", """""") & """")
    '        End If

    '        Call Reable_All_Buttons(False)
    '    Next curHDFolder
    'End Sub 'btnCompare_Click

    'Private Sub btnCopyFileCompare_Click(sender As Object, e As System.EventArgs) Handles btnCopyFileCompare.Click
    '    Call btnCopyFile_Return("C")
    'End Sub

    'Private Sub btnCopyFileFirst_Click(sender As Object, e As System.EventArgs) Handles btnCopyFileFirst.Click
    '    Call btnCopyFile_Return("E")
    'End Sub

    'Public Sub btnCopyFile_Return(ur_file_side As String)
    '    Dim lstSRC = Me.lstE_FILE
    '    Dim lstCOMP = Me.lstC_FILE
    '    Dim strCOMP_FOLDER = Me.lstCompare.SelectedItem.ToString
    '    If ur_file_side = "C" Then
    '        lstSRC = Me.lstC_FILE
    '        lstCOMP = Me.lstE_FILE
    '        strCOMP_FOLDER = Me.lstEnv.SelectedItem.ToString
    '    End If

    '    For Each curHDFolder In User_Selection.HDFolder_Selected
    '        Dim strROOT = curHDFolder.Path
    '        Dim strFILE = ""
    '        Dim intSELECTED = lstSRC.SelectedIndex
    '        If intSELECTED >= 0 Then
    '            strFILE = lstSRC.SelectedItem.ToString
    '        End If
    '        Dim intCOMP_FOUND = Mx.ListBoxSearch.IndexOf_c(lstCOMP, strFILE)
    '        If strFILE <> "" AndAlso
    '          intCOMP_FOUND < 0 Then
    '            intCOMP_FOUND = lstCOMP.Items.Add(strFILE)
    '            Dim strFILE_PATH = System.IO.Path.Combine(strROOT, strCOMP_FOLDER & strFILE)
    '            Dim strPARENT_PATH = System.IO.Path.GetDirectoryName(strFILE_PATH)
    '            If System.IO.Directory.Exists(strPARENT_PATH) = False Then
    '                Call System.IO.Directory.CreateDirectory(strPARENT_PATH)
    '            End If

    '            If System.IO.File.Exists(strFILE_PATH) = False Then
    '                Call System.IO.File.WriteAllText(strFILE_PATH, "")
    '            End If
    '        End If 'strFILE

    '        If strFILE <> "" Then
    '            lstCOMP.SelectedIndex = intCOMP_FOUND
    '            If ur_file_side = "C" Then
    '                Call lstE_FILE_KeyPress()
    '            Else
    '                Call lstC_FILE_KeyPress()
    '            End If
    '        End If
    '    Next curHDFolder
    'End Sub 'btnCopyFile_Return

    'Private Sub btnDupFile_Check_Click(sender As Object, e As System.EventArgs) Handles btnDupFile_Check.Click, btnDup_File_Check_Env.Click
    '    For Each curHDFolder In User_Selection.HDFolder_Selected
    '        Dim strROOT = curHDFolder.Path
    '        Dim strEXEC_PATH = strROOT & "\..\SpProcDef\DEV_UniqueFileCheck.cmd"
    '        If System.IO.File.Exists(strEXEC_PATH) = False Then
    '            MsgBox("Cannot find path to run program: " & strEXEC_PATH)
    '        Else
    '            System.Diagnostics.Process.Start(strEXEC_PATH)
    '        End If

    '        Call Reable_All_Buttons(False)
    '    Next curHDFolder
    'End Sub 'btnDupFile_Check_Click

    'Public Sub btnE_Export_Click(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles btnE_Export.Click
    '    For Each env_entry In User_Selection.Environment_Selected
    '        Call FolderExport(env_entry)
    '    Next env_entry

    '    Call Reable_All_Buttons(False)
    'End Sub 'btnE_Export_Click

    'Private Sub btnE_Folder_Click(sender As Object, e As System.EventArgs) Handles btnE_Folder.Click
    '    Me.TabControl1.SelectedTab = Me.tabEnv
    'End Sub

    'Private Sub btnExportLogs_Click(sender As Object, e As System.EventArgs) Handles btnExportLogs.Click
    '    Call frmExportLog.ShowDialog()
    'End Sub

    'Private Sub btnFolderSearch_Click(sender As Object, e As System.EventArgs) Handles btnFolderSearch.Click
    '    Call frmFolderSearch.ShowDialog()
    'End Sub

    'Private Sub btnRefresh_Click(sender As Object, e As System.EventArgs) Handles btnRefresh.Click
    '    Call lstFolder_KeyPress()
    'End Sub

    'Private Sub btnRefresh_Files_Click(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles btnRefresh_Files.Click
    '    Call Reable_All_Buttons(False)
    'End Sub

    'Private Sub btnRefresh_Folders_Click(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles btnRefresh_Folders.Click
    '    Dim stpRET_MSG = Mx.Have.Repository.Apply(enmRA.reload_ticket_list, Me.lstFolder, Me.chkSortByTicket)
    '    Mx.Want.Display_errmsg(stpRET_MSG)
    'End Sub 'btnRefresh_Folders_Click

    'Public Sub btnShowFolder_Click(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles btnShowFolder.Click, btnShowFolder2.Click
    '    For Each curHDFolder In User_Selection.HDFolder_Selected
    '        Dim strROOT = curHDFolder.Path
    '        Dim strEXEC_PATH = System.Environment.ExpandEnvironmentVariables("%WINDIR%\explorer.exe")

    '        If System.IO.File.Exists(strEXEC_PATH) = False Then
    '            MsgBox("Cannot find path to run program: " & strEXEC_PATH)
    '        Else
    '            System.Diagnostics.Process.Start(strEXEC_PATH, """" & strROOT.Replace("""", """""") & """")
    '        End If
    '    Next curHDFolder
    'End Sub

    'Private Sub chkSortByTicket_CheckedChanged(sender As Object, e As System.EventArgs) Handles chkSortByTicket.CheckedChanged
    '    If sCompany.Company_Source_Code_Repository IsNot Nothing Then
    '        Call btnRefresh_Folders_Click()
    '    End If
    'End Sub 'chkSortByTicket_CheckedChanged

    'Private Sub chkUsedFolders_CheckedChanged(sender As Object, e As System.EventArgs)
    '    Call btnRefresh_Folders_Click()
    'End Sub 'chkUsedFolders_CheckedChanged

    'Private Sub FolderExport(ur_env As HDFolders.Environment_Folders.OneEnvironmentFolder, Optional ur_file As String = "")
    '    For Each curHDFolder In User_Selection.HDFolder_Selected
    '        Dim strEXEC_PATH = Mx.Have.UserBowl.SelKey(Mx.enmUN.spprocdef_export_exe_path).Contents
    '        Dim strEXEC_PARAM = ""
    '        If Mx.HasText(ur_env.BaseConnection_String) Then
    '            If ur_env.IsAppActivate = False Then
    '                strEXEC_PARAM = ur_env.BaseConnection_String & Mx.s & "/nointerface /root_dir=" & curHDFolder.Path & " /in_subdir=" & ur_env.Name & " /out_subdir=" & ur_env.Environment_Name & " /cmp_subdir=" & ur_env.Name
    '            End If

    '        Else
    '            MsgBox("Database parameters must be entered for " & ur_env.Name,, My.Application.Info.Title)
    '        End If

    '        If ur_env.IsAppActivate Then
    '            Call Reable_All_Buttons(False)
    '            Me.strvCURRENT_EXPORT_FOLDER = System.IO.Path.Combine(curHDFolder.Path, ur_env.Name)
    '            Me.strvCURRENT_COMPARE_FOLDER = System.IO.Path.Combine(curHDFolder.Path, ur_env.Environment_Name)
    '            Me.objvCOMPARE_LIST = Me.lstE_FILE
    '            Me.strvCOMPARE_FILE = ur_file
    '            Me.bolvLEAVE_FILE = False
    '            Call frmHostedProcDef.ShowDialog()

    '        ElseIf System.IO.File.Exists(strEXEC_PATH) = False Then
    '            MsgBox("Cannot find path to run program: " & strEXEC_PATH)

    '        ElseIf strEXEC_PARAM <> "" Then
    '            If ur_file <> "" Then
    '                strEXEC_PARAM &= " /file=" & System.IO.Path.GetFileName(ur_file)
    '            End If

    '            Dim objSTART_INFO = New System.Diagnostics.ProcessStartInfo()
    '            objSTART_INFO.FileName = strEXEC_PATH
    '            objSTART_INFO.Arguments = strEXEC_PARAM
    '            objSTART_INFO.UseShellExecute = False
    '            objSTART_INFO.CreateNoWindow = True

    '            Dim objPROCESS = New System.Diagnostics.Process()
    '            objPROCESS.StartInfo = objSTART_INFO
    '            objPROCESS.Start()
    '        End If 'strEXEC_PARAM
    '    Next 'curHDFolder
    'End Sub 'FolderExport

    'Private Sub HdFolders_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
    '    Dim intFORM_WIDTH = Me.Width
    '    If intFORM_WIDTH > 100 Then
    '        Me.pnlE_File.Width = (intFORM_WIDTH - 20) / 2
    '    End If
    'End Sub 'HdFolders_Resize

    'Public Sub lstC_FILE_DoubleClick(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles lstC_FILE.DoubleClick
    '    Call lstC_FILE_KeyPress()
    'End Sub 'lstC_FILE_DoubleClick

    'Private Sub lstC_FILE_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstC_FILE.KeyPress
    '    Dim intSELECTED = Me.lstC_FILE.SelectedIndex
    '    If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
    '      intSELECTED >= 0 Then
    '        Dim strFILE = lstC_FILE.SelectedItem.ToString
    '        For Each env_entry In User_Selection.Comparison_Selected
    '            Call FolderExport(env_entry, strFILE)
    '        Next
    '    End If
    'End Sub 'lstC_FILE_KeyPress

    'Private Sub lstCompare_DoubleClick(sender As Object, e As System.EventArgs) Handles lstCompare.DoubleClick
    '    Call lstCompare_KeyPress()
    'End Sub

    'Private Sub lstCompare_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstCompare.KeyPress
    '    Dim intSELECTED = Me.lstEnv.SelectedIndex
    '    If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
    '      intSELECTED >= 0 Then
    '        User_Selection.Comparison_Entry = Me.lstCompare.SelectedItem.ToString
    '        Me.btnC_Folder.Text = User_Selection.Comparison_Entry
    '        Call Me.lstC_FILE.Items.Clear()
    '        For Each env_entry In User_Selection.Comparison_Selected
    '            For Each file_entry In env_entry.Refresh_Environment_Files()
    '                Me.lstC_FILE.Items.Add(file_entry.Name)
    '            Next file_entry
    '        Next env_entry

    '        Me.TabControl1.SelectedTab = Me.tabFile
    '        Me.btnCompare.Select()
    '    End If 'intSELECTED
    'End Sub 'lstCompare_KeyPress

    'Public Sub lstE_FILE_DoubleClick(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles lstE_FILE.DoubleClick
    '    Call lstE_FILE_KeyPress()
    'End Sub

    'Private Sub lstE_FILE_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstE_FILE.KeyPress
    '    Dim intSELECTED = lstE_FILE.SelectedIndex
    '    If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
    '      intSELECTED >= 0 Then
    '        Dim strFILE = lstE_FILE.SelectedItem.ToString
    '        For Each env_entry In User_Selection.Environment_Selected
    '            Call FolderExport(env_entry, strFILE)
    '        Next env_entry
    '    End If
    'End Sub 'lstE_FILE_KeyPress

    'Private Sub lstEnv_DoubleClick(sender As Object, e As System.EventArgs) Handles lstEnv.DoubleClick
    '    Call lstEnv_KeyPress()
    'End Sub

    'Private Sub lstEnv_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstEnv.KeyPress
    '    Dim intSELECTED = Me.lstEnv.SelectedIndex
    '    If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
    '      intSELECTED >= 0 Then
    '        Call Me.lstCompare.Items.Clear()
    '        User_Selection.Environment_Entry = Me.lstEnv.SelectedItem.ToString
    '        Me.btnE_Folder.Text = User_Selection.Environment_Entry

    '        Call Me.lstE_FILE.Items.Clear()
    '        For Each env_entry In User_Selection.Environment_Selected
    '            For Each file_entry In env_entry.Refresh_Environment_Files()
    '                Me.lstE_FILE.Items.Add(file_entry.Name)
    '            Next file_entry
    '        Next env_entry

    '        For Each objENTRY In Me.lstEnv.Items
    '            Dim strENTRY = objENTRY.ToString
    '            If strENTRY <> User_Selection.Environment_Entry Then
    '                Me.lstCompare.Items.Add(strENTRY)
    '            End If
    '        Next

    '        Me.TabControl1.SelectedTab = Me.tabCompare
    '        Me.lstCompare.Select()
    '    End If 'intSELECTED
    'End Sub 'lstEnv_KeyPress

    'Private Sub lstFolder_DoubleClick(sender As Object, e As System.EventArgs) Handles lstFolder.DoubleClick
    '    Dim stpRET = Mx.Have.Repository.Apply_errhnd(Me.lstFolder, Me.lstEnv, Me.lstCompare, Me.btnTicket_Folder, Me.TabControl1)
    '    Mx.Have.MessageDialog.Apply(enmMSB.ok_only, stpRET)
    'End Sub

    'Public Sub lstFolder_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstFolder.KeyPress
    '    Dim stpRET = Mx.Have.Repository.Apply_errhnd(Me.lstFolder, e, Me.lstEnv, Me.lstCompare, Me.btnTicket_Folder, Me.TabControl1)
    '    Mx.Have.MessageDialog.Apply(enmMSB.ok_only, stpRET)
    'End Sub

    'Private Sub lstNoteFile_DoubleClick(sender As Object, e As System.EventArgs) Handles lstNoteFile.DoubleClick
    '    Call lstNoteFile_KeyPress()
    'End Sub

    'Private Sub lstNoteFile_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstNoteFile.KeyPress
    '    Dim intSELECTED = Me.lstNoteFile.SelectedIndex
    '    If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
    '      intSELECTED >= 0 Then
    '        For Each curHDFolder In User_Selection.HDFolder_Selected
    '            Dim strROOT = curHDFolder.Path
    '            Dim strNOTE_PATH = strROOT & Me.lstNoteFile.SelectedItem.ToString
    '            If System.IO.File.Exists(Mx.Have.UserBowl.SelKey(Mx.enmUN.notepad_pp_exe_path).Contents) = False Then
    '                MsgBox("Cannot find path to run program: " & Mx.Have.UserBowl.SelKey(Mx.enmUN.notepad_pp_exe_path).Contents)
    '            Else
    '                System.Diagnostics.Process.Start(Mx.Have.UserBowl.SelKey(Mx.enmUN.notepad_pp_exe_path).Contents, """" & strNOTE_PATH.Replace("""", """""") & """")
    '            End If
    '        Next curHDFolder
    '    End If
    'End Sub 'lstNoteFile_KeyPress

    'Private Sub Reable_All_Buttons(ur_reable As Boolean)
    '    If ur_reable = False Then
    '        Call lstCompare_KeyPress()
    '    End If

    '    Dim bolNEEDED_RESET = False
    '    If Me.btnC_Export.Enabled = False OrElse
    '      Me.btnE_Export.Enabled = False OrElse
    '      Me.btnCompare.Enabled = False OrElse
    '      Me.btnClear.Enabled = False OrElse
    '      Me.btnDupFile_Check.Enabled = False Then
    '        bolNEEDED_RESET = True
    '    End If

    '    Me.btnC_Export.Enabled = ur_reable
    '    Me.btnE_Export.Enabled = ur_reable
    '    Me.btnCompare.Enabled = ur_reable
    '    Me.btnClear.Enabled = ur_reable
    '    Me.btnDupFile_Check.Enabled = ur_reable
    '    If ur_reable = True AndAlso
    '      bolNEEDED_RESET = True AndAlso
    '        Me.TabControl1.SelectedTab Is Me.tabFile Then
    '        Me.btnCompare.Select()
    '    End If
    'End Sub 'Reable_All_Buttons

    'Private Sub Timer1_Tick(sender As Object, e As System.EventArgs) Handles Timer1.Tick
    '    Me.Timer1.Stop()
    '    Call Reable_All_Buttons(True)
    '    Me.Timer1.Start()
    'End Sub 'Timer1_Tick

    'Private Sub btnRenameWaiting_Click(sender As Object, e As System.EventArgs) Handles btnRenameWaiting.Click
    '    Const lit_WAITING_sp = "Waiting "
    '    For Each curHDFolder In User_Selection.HDFolder_Selected
    '        Dim strSRC_ROOT = curHDFolder.Path
    '        Dim strROOT_PARENT = System.IO.Path.GetDirectoryName(strSRC_ROOT)
    '        Dim strDEST_ROOT = System.IO.Path.GetFileName(strSRC_ROOT)
    '        Dim strSRC_SUFFIX = ""
    '        Dim strDEST_SUFFIX = ""
    '        If Mx.StartingWithText(System.IO.Path.GetFileName(strSRC_ROOT), lit_WAITING_sp) Then
    '            strDEST_ROOT = System.IO.Path.Combine(strROOT_PARENT, Mid(strDEST_ROOT, lit_WAITING_sp.Length + 1))
    '            strSRC_SUFFIX = "Branch"
    '        Else
    '            strDEST_ROOT = System.IO.Path.Combine(strROOT_PARENT, lit_WAITING_sp & strDEST_ROOT)
    '            strDEST_SUFFIX = "Branch"
    '        End If

    '        For Each strSRC_PATH In System.IO.Directory.GetDirectories(strSRC_ROOT, "*", System.IO.SearchOption.TopDirectoryOnly)
    '            Dim strSRC_FOLDER = System.IO.Path.GetFileName(strSRC_PATH)
    '            Dim sdaFOLDER_SUFFIX = strSRC_FOLDER.Split(" ")
    '            Call Array.Reverse(sdaFOLDER_SUFFIX)
    '            Dim strFOUND_SUFFIX = sdaFOLDER_SUFFIX(0)
    '            Dim strFOUND_PREFIX = Mid(strSRC_FOLDER, 1, strSRC_FOLDER.Length - strFOUND_SUFFIX.Length)

    '            For Each entry In Database.ExportTypes
    '                If Mx.AreEqual(strFOUND_SUFFIX, strSRC_SUFFIX & entry.Name) AndAlso
    '                  Mx.AreEqual(strFOUND_SUFFIX, strDEST_SUFFIX & entry.Name) = False Then
    '                    Dim strDEST_FOLDER = strFOUND_PREFIX & strDEST_SUFFIX & entry.Name
    '                    Dim strDEST_PATH = System.IO.Path.Combine(strSRC_ROOT, strDEST_FOLDER)
    '                    Call System.IO.Directory.Move(strSRC_PATH, strDEST_PATH)
    '                End If
    '            Next entry
    '        Next strSRC_PATH

    '        Call System.IO.Directory.Move(strSRC_ROOT, strDEST_ROOT)
    '        Call btnRefresh_Folders_Click()
    '    Next curHDFolder
    'End Sub 'btnRenameWaiting_Click

    'Private Sub btnTicket_Folder_Click(sender As Object, e As System.EventArgs) Handles btnTicket_Folder.Click
    '    Me.TabControl1.SelectedTab = Me.tabFolder
    'End Sub

    'Private Sub btnRefreshNotes_Click(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles btnRefreshNotes.Click
    '    Dim strCURRENT_HDFOLDER = User_Selection.HDFolder_Path
    '    Call Me.lstNoteFile.Items.Clear()
    '    For Each curHDFolder In User_Selection.HDFolder_Selected
    '        For Each entry In curHDFolder.Refresh_Notes_Files()
    '            Call Me.lstNoteFile.Items.Add(entry.Name)
    '        Next
    '    Next curHDFolder
    'End Sub 'btnRefreshNotes_Click
End Class 'frmHdFolders
