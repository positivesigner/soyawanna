﻿Option Strict On
Option Infer On
Imports System.ComponentModel.Design

Namespace Mx
    Partial Public Class Have
        Public Shared objClipboard As sClipboard
        Public Shared objMessageDialog As sMessageDialog
        Public Shared tblConfigManager As sConfigManager
        Public Shared tblEnvConn As sEnvConn
        Public Shared tblExportType As sExportType
        Public Shared tblFile_Ver As sFile_Ver
        Public Shared tblNoteType As sNoteType
        Public Shared tblUserBowl As sUserBowl
        Public Shared objWindowsFS As sWindowsFS

        <System.Diagnostics.DebuggerHidden()>
        Private Shared Sub Connect()
            If Have.tblUserBowl Is Nothing Then
                Have.tblUserBowl = New sUserBowl
                Have.objClipboard = New sClipboard
                Have.objMessageDialog = New sMessageDialog
                Have.tblConfigManager = New sConfigManager
                Have.tblEnvConn = New sEnvConn
                Have.tblExportType = New sExportType
                Have.tblFile_Ver = New sFile_Ver
                Have.tblNoteType = New sNoteType
                Have.objWindowsFS = New sWindowsFS
            End If 'sdaTCOL_NAME
        End Sub 'Connect
    End Class 'Have


    Public Class enmCBD
        Public Shared set_text As zset_text = New zset_text : Public Class zset_text : Inherits enmCBD : End Class
    End Class 'enmCBD

    Partial Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function Clipboard() As sClipboard
            Call Have.Connect()
            Clipboard = Have.objClipboard
        End Function

        Public Class sClipboard
            Public Sub Apply(ur_set_text As enmCBD.zset_text, ur_text As String)
                My.Computer.Clipboard.SetText(ur_text)
            End Sub 'Apply
        End Class 'sClipboard
    End Class 'enmCBD


    Public Class enmCFG
        Public Shared load_settings As zload_settings = New zload_settings : Public Class zload_settings : Inherits enmCFG : End Class
    End Class

    Public Class enmCM
        Inherits bitBASE
        Public Shared uk As enmCM = TRow(Of enmCM).glbl.NewBitBase()
        Public Shared db_connection_string As enmCM = TRow(Of enmCM).glbl.NewBitBase()
        Public Shared env_name As enmCM = TRow(Of enmCM).glbl.NewBitBase()
        Public Shared export_type As enmCM = TRow(Of enmCM).glbl.NewBitBase()
        Public Shared file_type As enmCM = TRow(Of enmCM).glbl.NewBitBase()
        Public Shared hosting_app_title As zhosting_app_title = TRow(Of enmCM).glbl.Trbase(Of zhosting_app_title).NewBitBase() : Public Class zhosting_app_title : Inherits enmCM : End Class
        Public Shared note_type As enmCM = TRow(Of enmCM).glbl.NewBitBase()
        Public Shared sqlprocdef_script As zsqlprocdef_script = TRow(Of enmCM).glbl.Trbase(Of zsqlprocdef_script).NewBitBase() : Public Class zsqlprocdef_script : Inherits enmCM : End Class
    End Class 'enmCM

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function ConfigManager() As sConfigManager
            Call Have.Connect()
            ConfigManager = Have.tblConfigManager
        End Function

        Public Class rConfigManager
            Inherits TRow(Of enmCM)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmCM, ur_val As String) As rConfigManager
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rConfigManager

        Public Class sConfigManager
            Inherits TablePKStr(Of enmCM, rConfigManager)

            Public Repository As sRepository

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Call MyBase.New(ur_pk_count:=1)
                Me.Repository = New sRepository
            End Sub 'New

            <System.Diagnostics.DebuggerHidden()>
            Public Function Ins_AppSettings(ur_collection As System.Collections.Specialized.NameValueCollection) As sConfigManager
                Ins_AppSettings = Me
                For Each strNAME In ur_collection.AllKeys
                    If StartingWithText(strNAME, "Env") Then
                        Dim strVAL_LIST = ur_collection.Item(strNAME)
                        For Each strENV_NAME In strVAL_LIST.Split(","c)
                            If HasText(strENV_NAME) Then
                                Dim trwCM = Me.InsKey(Me.Count.ToString)
                                trwCM.v(enmCM.env_name) = strENV_NAME
                                For Each strENV_ENTRY In ur_collection.AllKeys
                                    If AreEqual(strENV_ENTRY, strENV_NAME) Then
                                        Dim strDB_CONN = ur_collection.Item(strENV_ENTRY)
                                        trwCM.v(enmCM.db_connection_string) = strDB_CONN
                                        Dim new_envconn = Have.EnvConn.InsKey(strENV_NAME)
                                        new_envconn.v(enmEC.connection_string) = strDB_CONN
                                        Exit For
                                    End If
                                Next strENV_ENTRY
                            End If
                        Next strENV_NAME

                    ElseIf StartingWithText(strNAME, "Export") Then
                        Dim strVAL_LIST = ur_collection.Item(strNAME)
                        For Each strENTRY In strVAL_LIST.Split(","c)
                            If HasText(strENTRY) Then
                                Dim trwCM = Me.InsKey(Me.Count.ToString)
                                trwCM.v(enmCM.export_type) = strENTRY
                                Dim new_exporttype = Have.ExportType.InsKey(strENTRY)
                            End If
                        Next strENTRY

                    ElseIf StartingWithText(strNAME, "FileType") Then
                        Dim strVAL_LIST = ur_collection.Item(strNAME)
                        For Each strENTRY In strVAL_LIST.Split(","c)
                            If HasText(strENTRY) Then
                                Dim trwCM = Me.InsKey(Me.Count.ToString)
                                trwCM.v(enmCM.file_type) = strENTRY
                                Dim new_file_ver = Have.File_Ver.InsKey(strENTRY)
                            End If
                        Next strENTRY

                    ElseIf StartingWithText(strNAME, "HOSTING_APP") Then
                        Dim strVAL = ur_collection.Item(strNAME)
                        If HasText(strVAL) Then
                            Dim trwCM = Me.InsKey(Me.Count.ToString)
                            trwCM.v(enmCM.hosting_app_title) = strVAL
                        End If

                    ElseIf StartingWithText(strNAME, "Note") Then
                        Dim strVAL_LIST = ur_collection.Item(strNAME)
                        For Each strENTRY In strVAL_LIST.Split(","c)
                            If HasText(strENTRY) Then
                                Dim trwCM = Me.InsKey(Me.Count.ToString)
                                trwCM.v(enmCM.note_type) = strENTRY
                                Dim new_notetype = Have.NoteType.InsKey(strENTRY)
                            End If
                        Next strENTRY

                    ElseIf StartingWithText(strNAME, "SQLPROCDEF") Then
                        Dim strVAL = ur_collection.Item(strNAME)
                        If HasText(strVAL) Then
                            Dim trwCM = Me.InsKey(Me.Count.ToString)
                            trwCM.v(enmCM.sqlprocdef_script) = strVAL
                        End If
                    End If
                Next strNAME
            End Function 'Ins_AppSettings

            <System.Diagnostics.DebuggerHidden()>
            Public Function SelKeyList(ur_col As enmCM) As Sdata
                Dim sdaRET = New Sdata
                SelKeyList = sdaRET
                For Each row In Me.SelNe(ur_col, mt).SelAll
                    sdaRET.Add(row.v(ur_col))
                Next row
            End Function 'SelKeyList

            <System.Diagnostics.DebuggerHidden()>
            Public Function SelKeyValue(ur_key As enmCM) As String
                SelKeyValue = mt
                For Each row In Me.SelNe(ur_key, mt).SelAll
                    SelKeyValue = row.v(ur_key)
                    Exit For
                Next row
            End Function 'SelKeyValue

            <System.Diagnostics.DebuggerHidden()>
            Public Sub ToCbrd(ur_hdr As Boolean)
                Call Have.Clipboard.Apply(enmCBD.set_text, Me.ToString(ur_hdr))
            End Sub
        End Class 'sConfigManager
    End Class 'CFG, CM


    Public Class enmEC
        Inherits bitBASE
        Public Shared env_name As enmEC = TRow(Of enmEC).glbl.NewBitBase()
        Public Shared connection_string As enmEC = TRow(Of enmEC).glbl.NewBitBase()
    End Class 'enmEC

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function EnvConn() As sEnvConn
            Call Have.Connect()
            EnvConn = Have.tblEnvConn
        End Function

        Public Class rEnvConn
            Inherits TRow(Of enmEC)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmEC, ur_val As String) As rEnvConn
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rEnvConn

        Public Class sEnvConn
            Inherits TablePKStr(Of enmEC, rEnvConn)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Call MyBase.New(ur_pk_count:=1)
            End Sub 'New
        End Class 'sEnvConn
    End Class 'EC


    Public Class enmUEV
        Inherits bitBASE
        Public Shared assign_primary_envver As zassign_primary_envver = New zassign_primary_envver : Public Class zassign_primary_envver : Inherits enmUEV : End Class
    End Class 'enmUEV

    Public Class enmEV
        Inherits bitBASE
        Public Shared env_name As enmEV = TRow(Of enmEV).glbl.NewBitBase()
        Public Shared folder_name As enmEV = TRow(Of enmEV).glbl.NewBitBase()
        Public Shared connection_string As enmEV = TRow(Of enmEV).glbl.NewBitBase()
        Public Shared file_ver As enmEV = TRow(Of enmEV).glbl.NewBitBase()
    End Class 'enmEV

    Partial Public Class Have
        Public Class rEnvVer
            Inherits TRow(Of enmEV)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmEV, ur_val As String) As rEnvVer
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rEnvVer

        Public Class sEnvVer
            Inherits TablePKStr(Of enmEV, rEnvVer)

            Public tteSelEnvironmentAddFile As Objlist(Of rEnvVer)
            Public tteSelEnvironmentBase As Objlist(Of rEnvVer)
            Public tteSelEnvironmentCompare As Objlist(Of rEnvVer)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Call MyBase.New(ur_pk_count:=1)
                Me.tteSelEnvironmentAddFile = New Objlist(Of rEnvVer)
                Me.tteSelEnvironmentBase = New Objlist(Of rEnvVer)
                Me.tteSelEnvironmentCompare = New Objlist(Of rEnvVer)
            End Sub 'New

            <System.Diagnostics.DebuggerHidden()>
            Public Sub Clear()
                Call Me.DelAll()
                Me.tteSelEnvironmentAddFile.Clear()
                Me.tteSelEnvironmentBase.Clear()
                Me.tteSelEnvironmentCompare.Clear()
            End Sub
        End Class 'sEnvVer
    End Class 'EV


    Public Class enmEX
        Inherits bitBASE
        Public Shared type_name As enmEX = TRow(Of enmEX).glbl.NewBitBase()
    End Class 'enmEX

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function ExportType() As sExportType
            Call Have.Connect()
            ExportType = Have.tblExportType
        End Function

        Public Class rExportType
            Inherits TRow(Of enmEX)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmEX, ur_val As String) As rExportType
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rExportType

        Public Class sExportType
            Inherits TablePKStr(Of enmEX, rExportType)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Call MyBase.New(ur_pk_count:=1)
            End Sub 'New
        End Class 'sExportType
    End Class 'EX


    Public Class enmFV
        Inherits bitBASE
        Public Shared version_type As enmFV = TRow(Of enmFV).glbl.NewBitBase()
    End Class 'enmEC

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function File_Ver() As sFile_Ver
            Call Have.Connect()
            File_Ver = Have.tblFile_Ver
        End Function

        Public Class rFile_Ver
            Inherits TRow(Of enmFV)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmFV, ur_val As String) As rFile_Ver
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rEnvConn

        Public Class sFile_Ver
            Inherits TablePKStr(Of enmFV, rFile_Ver)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Call MyBase.New(ur_pk_count:=1)
            End Sub 'New
        End Class 'sEnvConn
    End Class 'FV


    Public Class enmUTK
        Inherits bitBASE
        Public Shared assign_primary_envver As zassign_primary_envver = New zassign_primary_envver : Public Class zassign_primary_envver : Inherits enmUTK : End Class
        Public Shared assign_secondary_envver As zassign_secondary_envver = New zassign_secondary_envver : Public Class zassign_secondary_envver : Inherits enmUTK : End Class
        Public Shared assign_addfile_envver As zassign_addfile_envver = New zassign_addfile_envver : Public Class zassign_addfile_envver : Inherits enmUTK : End Class
        Public Shared ordered_envver_list As zordered_envver_list = New zordered_envver_list : Public Class zordered_envver_list : Inherits enmUTK : End Class
        Public Shared reload_envver_list As zreload_envver_list = New zreload_envver_list : Public Class zreload_envver_list : Inherits enmUTK : End Class
    End Class 'enmUTK

    Public Class enmHD
        Inherits bitBASE
        Public Shared ticket_name As enmHD = TRow(Of enmHD).glbl.NewBitBase()
        Public Shared path As enmHD = TRow(Of enmHD).glbl.NewBitBase()
        Public Shared folder_name As enmHD = TRow(Of enmHD).glbl.NewBitBase()
    End Class 'enmHD

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function TicketList() As sTicket
            Call Have.Connect()
            TicketList = Have.Repository.TicketList
        End Function

        Public Class rTicket
            Inherits TRow(Of enmHD)

            Public EnvVerList As sEnvVer

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Me.EnvVerList = New sEnvVer
            End Sub 'New

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmHD, ur_val As String) As rTicket
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rTicket

        Public Class sTicket
            Inherits TablePKStr(Of enmHD, rTicket)

            Public ActiveTicket As Objlist(Of rTicket)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Call MyBase.New(ur_pk_count:=1)
                Me.ActiveTicket = New Objlist(Of rTicket)
            End Sub

            <System.Diagnostics.DebuggerHidden()>
            Public Sub Clear()
                Call Me.DelAll()
                Call Me.ActiveTicket.Clear()
            End Sub
        End Class 'sTicket
    End Class 'UTK HD


    Public Class enmMSB
        Public Shared ok_only As zok_only = New zok_only : Public Class zok_only : Inherits enmMSB : End Class
    End Class 'enmMSB

    Partial Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function MessageDialog() As sMessageDialog
            Call Have.Connect()
            MessageDialog = Have.objMessageDialog
        End Function

        Public Class sMessageDialog
            <System.Diagnostics.DebuggerHidden()>
            Public Sub Apply(ur_ok_only As enmMSB.zok_only, ur_notice_msg As String)
                Dim app_title_bowlname = enmUN.app_title
                If HasText(ur_notice_msg) Then
                    MsgBox(ur_notice_msg, Microsoft.VisualBasic.MsgBoxStyle.OkOnly, Have.UserBowl.SelKey(app_title_bowlname).Contents)
                End If
            End Sub 'Apply
        End Class 'sMessageDialog
    End Class 'enmMSB


    Public Class enmNT
        Inherits bitBASE
        Public Shared note_topic As enmNT = TRow(Of enmNT).glbl.NewBitBase()
    End Class 'enmNT

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function NoteType() As sNoteType
            Call Have.Connect()
            NoteType = Have.tblNoteType
        End Function

        Public Class rNoteType
            Inherits TRow(Of enmNT)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmNT, ur_val As String) As rNoteType
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rNoteType

        Public Class sNoteType
            Inherits TablePKStr(Of enmNT, rNoteType)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Call MyBase.New(ur_pk_count:=1)
            End Sub 'New
        End Class 'sNoteType
    End Class 'NT


    Public Class enmRA
        Inherits bitBASE
        Public Shared assign_active_ticket As zassign_active_ticket = New zassign_active_ticket : Public Class zassign_active_ticket : Inherits enmRA : End Class
        Public Shared assign_label As zassign_label = New zassign_label : Public Class zassign_label : Inherits enmRA : End Class
        Public Shared usersession_ticxet As zusersession_ticxet = New zusersession_ticxet : Public Class zusersession_ticxet : Inherits enmRA : End Class
    End Class 'enmRA

    Public Class enmRP
        Inherits bitBASE
        Public Shared repository_name As zrepository_name = TRow(Of enmRP).glbl.Trbase(Of zrepository_name).NewBitBase() : Public Class zrepository_name : Inherits enmRP : End Class
        Public Shared server_folder_path As zserver_folder_path = TRow(Of enmRP).glbl.Trbase(Of zserver_folder_path).NewBitBase() : Public Class zserver_folder_path : Inherits enmRP : End Class
    End Class 'enmRP

    Partial Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function Repository() As sRepository
            Call Have.Connect()
            Repository = Have.ConfigManager.Repository
        End Function

        Public Class rRepository
            Inherits TRow(Of enmRP)

            Public ActiveTicket As Objlist(Of rTicket)

            <System.Diagnostics.DebuggerHidden()>
            Sub New()
                Me.ActiveTicket = New Objlist(Of rTicket)
            End Sub
        End Class 'rRepository

        Public Class sRepository
            Inherits TablePKStr(Of enmRP, rRepository)

            Public TicketList As sTicket

            <System.Diagnostics.DebuggerHidden()>
            Sub New()
                Call MyBase.New(ur_pk_count:=1)
                Me.TicketList = New sTicket
            End Sub 'New

            <System.Diagnostics.DebuggerHidden()>
            Sub Clear()
                Call Me.DelAll()
                Call Me.TicketList.Clear()
            End Sub 'New
        End Class 'sRepository
    End Class 'enmRA, enmRP


    Public Class enmUB
        Inherits bitBASE
        Public Shared bowl_name As enmUB = TRow(Of enmUB).glbl.NewBitBase()
        Public Shared contents As enmUB = TRow(Of enmUB).glbl.NewBitBase()
    End Class

    Public Class enmUN
        Inherits bitBASE
        Public Shared app_folder As zapp_folder = TRow(Of enmUN).glbl.Trbase(Of zapp_folder).NewBitBase() : Public Class zapp_folder : Inherits enmUN : End Class
        Public Shared app_name As zapp_name = TRow(Of enmUN).glbl.Trbase(Of zapp_name).NewBitBase() : Public Class zapp_name : Inherits enmUN : End Class
        Public Shared app_path As zapp_path = TRow(Of enmUN).glbl.Trbase(Of zapp_path).NewBitBase() : Public Class zapp_path : Inherits enmUN : End Class
        Public Shared app_config_file As zapp_config_file = TRow(Of enmUN).glbl.Trbase(Of zapp_config_file).NewBitBase() : Public Class zapp_config_file : Inherits enmUN : End Class
        Public Shared app_settings_dir As zapp_settings_dir = TRow(Of enmUN).glbl.Trbase(Of zapp_settings_dir).NewBitBase() : Public Class zapp_settings_dir : Inherits enmUN : End Class
        Public Shared app_settings_path As zapp_settings_path = TRow(Of enmUN).glbl.Trbase(Of zapp_settings_path).NewBitBase() : Public Class zapp_settings_path : Inherits enmUN : End Class
        Public Shared app_title As zapp_title = TRow(Of enmUN).glbl.Trbase(Of zapp_title).NewBitBase() : Public Class zapp_title : Inherits enmUN : End Class
        Public Shared app_version As zapp_version = TRow(Of enmUN).glbl.Trbase(Of zapp_version).NewBitBase() : Public Class zapp_version : Inherits enmUN : End Class
        Public Shared beyond_compare_exe_path As zbeyond_compare_exe_path = TRow(Of enmUN).glbl.Trbase(Of zbeyond_compare_exe_path).NewBitBase() : Public Class zbeyond_compare_exe_path : Inherits enmUN : End Class
        Public Shared beyond_compare_hunt_path As zbeyond_compare_hunt_path = TRow(Of enmUN).glbl.Trbase(Of zbeyond_compare_hunt_path).NewBitBase() : Public Class zbeyond_compare_hunt_path : Inherits enmUN : End Class
        Public Shared beyond_compare_hunt_script As zbeyond_compare_hunt_script = TRow(Of enmUN).glbl.Trbase(Of zbeyond_compare_hunt_script).NewBitBase() : Public Class zbeyond_compare_hunt_script : Inherits enmUN : End Class
        Public Shared cmdline_audit As zcmdline_audit = TRow(Of enmUN).glbl.Trbase(Of zcmdline_audit).NewBitBase() : Public Class zcmdline_audit : Inherits enmUN : End Class
        Public Shared cmdline_orig As zcmdline_orig = TRow(Of enmUN).glbl.Trbase(Of zcmdline_orig).NewBitBase() : Public Class zcmdline_orig : Inherits enmUN : End Class
        Public Shared cmdline_table As zcmdline_table = TRow(Of enmUN).glbl.Trbase(Of zcmdline_table).NewBitBase() : Public Class zcmdline_table : Inherits enmUN : End Class
        Public Shared hd_folder_search As zhd_folder_search = TRow(Of enmUN).glbl.Trbase(Of zhd_folder_search).NewBitBase() : Public Class zhd_folder_search : Inherits enmUN : End Class
        Public Shared hosting_app_appactivate_title As zhosting_app_appactivate_title = TRow(Of enmUN).glbl.Trbase(Of zhosting_app_appactivate_title).NewBitBase() : Public Class zhosting_app_appactivate_title : Inherits enmUN : End Class
        Public Shared hosting_app_hunt_default As zhosting_app_hunt_default = TRow(Of enmUN).glbl.Trbase(Of zhosting_app_hunt_default).NewBitBase() : Public Class zhosting_app_hunt_default : Inherits enmUN : End Class
        Public Shared log_dir As zlog_dir = TRow(Of enmUN).glbl.Trbase(Of zlog_dir).NewBitBase() : Public Class zlog_dir : Inherits enmUN : End Class
        Public Shared notepad_pp_exe_path As znotepad_pp_exe_path = TRow(Of enmUN).glbl.Trbase(Of znotepad_pp_exe_path).NewBitBase() : Public Class znotepad_pp_exe_path : Inherits enmUN : End Class
        Public Shared notepad_pp_hunt_script_e1 As znotepad_pp_hunt_script_e1 = TRow(Of enmUN).glbl.Trbase(Of znotepad_pp_hunt_script_e1).NewBitBase() : Public Class znotepad_pp_hunt_script_e1 : Inherits enmUN : End Class
        Public Shared notepad_pp_hunt_script_e2 As znotepad_pp_hunt_script_e2 = TRow(Of enmUN).glbl.Trbase(Of znotepad_pp_hunt_script_e2).NewBitBase() : Public Class znotepad_pp_hunt_script_e2 : Inherits enmUN : End Class
        Public Shared notepad_pp_hunt_path_e1 As znotepad_pp_hunt_path_e1 = TRow(Of enmUN).glbl.Trbase(Of znotepad_pp_hunt_path_e1).NewBitBase() : Public Class znotepad_pp_hunt_path_e1 : Inherits enmUN : End Class
        Public Shared notepad_pp_hunt_path_e2 As znotepad_pp_hunt_path_e2 = TRow(Of enmUN).glbl.Trbase(Of znotepad_pp_hunt_path_e2).NewBitBase() : Public Class znotepad_pp_hunt_path_e2 : Inherits enmUN : End Class
        Public Shared repository_dir As zrepository_dir = TRow(Of enmUN).glbl.Trbase(Of zrepository_dir).NewBitBase() : Public Class zrepository_dir : Inherits enmUN : End Class
        Public Shared session_save_path As zsession_save_path = TRow(Of enmUN).glbl.Trbase(Of zsession_save_path).NewBitBase() : Public Class zsession_save_path : Inherits enmUN : End Class
        Public Shared spprocdef_export_exe_path As zspprocdef_export_exe_path = TRow(Of enmUN).glbl.Trbase(Of zspprocdef_export_exe_path).NewBitBase() : Public Class zspprocdef_export_exe_path : Inherits enmUN : End Class
        Public Shared spprocdef_export_error_search As zspprocdef_export_error_search = TRow(Of enmUN).glbl.Trbase(Of zspprocdef_export_error_search).NewBitBase() : Public Class zspprocdef_export_error_search : Inherits enmUN : End Class
        Public Shared spprocdef_export_hunt_appsetting As zspprocdef_export_hunt_appsetting = TRow(Of enmUN).glbl.Trbase(Of zspprocdef_export_hunt_appsetting).NewBitBase() : Public Class zspprocdef_export_hunt_appsetting : Inherits enmUN : End Class
        Public Shared spprocdef_export_hunt_script As zspprocdef_export_hunt_script = TRow(Of enmUN).glbl.Trbase(Of zspprocdef_export_hunt_script).NewBitBase() : Public Class zspprocdef_export_hunt_script : Inherits enmUN : End Class
        Public Shared testing_repository_dir As ztesting_repository_dir = TRow(Of enmUN).glbl.Trbase(Of ztesting_repository_dir).NewBitBase() : Public Class ztesting_repository_dir : Inherits enmUN : End Class
        Public Shared ticket_notes_subdir As zticket_notes_subdir = TRow(Of enmUN).glbl.Trbase(Of zticket_notes_subdir).NewBitBase() : Public Class zticket_notes_subdir : Inherits enmUN : End Class
        Public Shared user_download_dir As zuser_download_dir = TRow(Of enmUN).glbl.Trbase(Of zuser_download_dir).NewBitBase() : Public Class zuser_download_dir : Inherits enmUN : End Class
        Public Shared user_hdfolder_entry As zuser_hdfolder_entry = TRow(Of enmUN).glbl.Trbase(Of zuser_hdfolder_entry).NewBitBase() : Public Class zuser_hdfolder_entry : Inherits enmUN : End Class
        Public Shared user_primary_envver_entry As zuser_primary_envver_entry = TRow(Of enmUN).glbl.Trbase(Of zuser_primary_envver_entry).NewBitBase() : Public Class zuser_primary_envver_entry : Inherits enmUN : End Class
        Public Shared user_compare_envver_entry As zuser_compare_envver_entry = TRow(Of enmUN).glbl.Trbase(Of zuser_compare_envver_entry).NewBitBase() : Public Class zuser_compare_envver_entry : Inherits enmUN : End Class
    End Class 'enmUN

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function UserBowl() As sUserBowl
            Dim bolFIRST_INIT = (Have.tblUserBowl Is Nothing)
            Call Have.Connect()
            UserBowl = Have.tblUserBowl
            If bolFIRST_INIT Then
                Call Have.tblUserBowl.Ins_CommandLine(System.Reflection.Assembly.GetExecutingAssembly, System.Environment.CommandLine)
                'Have.tblUserBowl.InsKey(enmUN.cmdline_audit, "1")
                Call Have.tblUserBowl.Cboard_CmdlineAudit()
            End If
        End Function 'UserBowl

        Public Class rUserBowl
            Inherits TRow(Of enmUB)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmUB, ur_val As String) As rUserBowl
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Property Contents() As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Contents = Me.v(enmUB.contents)
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(ur_val As String)
                    Me.v(enmUB.contents) = ur_val
                End Set
            End Property
        End Class 'rUserBowl

        Public Class sUserBowl
            Inherits TablePKEnum(Of enmUB, enmUN, rUserBowl)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub Cboard_CmdlineAudit()
                If HasText(Me.SelKey(enmUN.cmdline_audit).v(enmUB.contents)) Then
                    Dim strAUDIT = Me.ToString(True)
                    If MsgBox(strAUDIT, MsgBoxStyle.OkCancel, Me.SelKey(enmUN.app_name).v(enmUB.contents)) = MsgBoxResult.Ok Then
                        My.Computer.Clipboard.SetText(strAUDIT)
                    End If
                End If
            End Sub 'Cboard_CmdlineAudit

            <System.Diagnostics.DebuggerHidden()>
            Public Function Ins_CommandLine(ur_assembly_path As System.Reflection.Assembly, ur_command_line As String) As sUserBowl
                Ins_CommandLine = Me
                Dim flnAPP_SETTINGS_FILE = FileNamed().d(ur_assembly_path.Location).dAppendEXT(".config")
                Dim flnAPP_PATH = FileNamed().d(ur_assembly_path.Location.Replace("\bin\Debug", ""))
                Me.SelKey(enmUN.app_path).vt(enmUB.contents, flnAPP_PATH)
                Me.SelKey(enmUN.app_name).vt(enmUB.contents, flnAPP_PATH.FileGroup)
                Me.SelKey(enmUN.app_folder).vt(enmUB.contents, flnAPP_PATH.gParentDir)
                Me.SelKey(enmUN.app_settings_path).vt(enmUB.contents, flnAPP_SETTINGS_FILE)
                Me.SelKey(enmUN.app_settings_dir).vt(enmUB.contents, flnAPP_SETTINGS_FILE.gParentDir)

                Dim arlCMD_RET = MxText.Cmdline_UB(Of enmUN, enmUB).CommandLine_UBParm(enmUB.bowl_name, enmUB.contents, ur_command_line)
                Me.SelKey(enmUN.cmdline_orig).vt(enmUB.contents, qs & System.Environment.CommandLine.Replace(qs, qs & qs) & qs)
                Me.SelKey(enmUN.cmdline_table).vt(enmUB.contents, qs & arlCMD_RET.ttbCMD_PARM.ToString(True).Replace(qs, qs & qs) & qs)
                For Each rowFOUND In arlCMD_RET.ttbUB_PARM
                    Me.Ins(
                        New Have.rUserBowl().
                        vt(enmUB.bowl_name, rowFOUND.v(enmUB.bowl_name)).
                        vt(enmUB.contents, rowFOUND.v(enmUB.contents))
                        )
                Next
            End Function 'Ins_CommandLine

            <System.Diagnostics.DebuggerHidden()>
            Public Sub ToCbrd(ur_hdr As Boolean)
                Call Have.Clipboard.Apply(enmCBD.set_text, Me.ToString(ur_hdr))
            End Sub
        End Class 'sUserBowl
    End Class 'UB, UN


    Partial Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsFS() As sWindowsFS
            Call Have.Connect()
            WindowsFS = Have.objWindowsFS
        End Function

        Public Class sWindowsFS
            <System.Diagnostics.DebuggerHidden()>
            Sub Apply(ur_copy As glbl.enmWF.zcopy, ur_source_path As String, ur_dest_path As String)
                Call glbl.gWindowsFS.Apply(ur_copy, ur_source_path, ur_dest_path)
            End Sub 'ur_copy
        End Class 'sWindowsFS
    End Class 'glbl.enmWF
End Namespace 'Mx
