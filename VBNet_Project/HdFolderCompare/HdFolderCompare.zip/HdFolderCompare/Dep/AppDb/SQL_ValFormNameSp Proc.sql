IF OBJECT_ID('SQL_ValFormNameSp') IS NOT NULL BEGIN  DROP PROCEDURE SQL_ValFormNameSp  END
GO
CREATE PROCEDURE [dbo].[SQL_ValFormNameSp]
  (
    @ur_prefix NVARCHAR(128),
    @ur_filetype NVARCHAR(30)
  ) AS
    DECLARE @lit_bslash NVARCHAR(MAX) = CHAR(92)
    SET @ur_filetype = NULLIF(@ur_filetype, '')

  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE table_name = 'catalog') BEGIN
    SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Form' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Forms
      WHERE
        ISNULL(@ur_filetype, 'FORM') LIKE 'FORM%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Form' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Forms
      WHERE
        ISNULL(@ur_filetype, 'FORM') LIKE 'FORM%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Form' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Forms
      WHERE
        ISNULL(@ur_filetype, 'FORM') LIKE 'FORM%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Form' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Forms
      WHERE
        ISNULL(@ur_filetype, 'FORM') LIKE 'FORM%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Form' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Forms
      WHERE
        ISNULL(@ur_filetype, 'FORM') LIKE 'FORM%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Form' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Forms
      WHERE
        ISNULL(@ur_filetype, 'FORM') LIKE 'FORM%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + PropertyName + ' CmpntCls' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..PropertyDefaults
      WHERE
        ISNULL(@ur_filetype, 'CMPNTCLS') LIKE 'CMPNTCLS%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        PropertyName LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + PropertyName + ' CmpntCls' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..PropertyDefaults
      WHERE
        ISNULL(@ur_filetype, 'CMPNTCLS') LIKE 'CMPNTCLS%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        PropertyName LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        PropertyName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + PropertyName + ' CmpntCls' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..PropertyDefaults
      WHERE
        ISNULL(@ur_filetype, 'CMPNTCLS') LIKE 'CMPNTCLS%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        PropertyName LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        PropertyName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        PropertyName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + PropertyName + ' CmpntCls' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..PropertyDefaults
      WHERE
        ISNULL(@ur_filetype, 'CMPNTCLS') LIKE 'CMPNTCLS%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        PropertyName LIKE '%' + @ur_prefix + '%' AND
        PropertyName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        PropertyName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        PropertyName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + PropertyName + ' CmpntCls' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..PropertyDefaults
      WHERE
        ISNULL(@ur_filetype, 'CMPNTCLS') LIKE 'CMPNTCLS%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        PropertyName LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        PropertyName NOT LIKE '%' + @ur_prefix + '%' AND
        PropertyName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        PropertyName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        PropertyName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + PropertyName + ' CmpntCls' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..PropertyDefaults
      WHERE
        ISNULL(@ur_filetype, 'CMPNTCLS') LIKE 'CMPNTCLS%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        PropertyName LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        PropertyName NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        PropertyName NOT LIKE '%' + @ur_prefix + '%' AND
        PropertyName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        PropertyName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        PropertyName NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' GScript' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Scripts
      WHERE
        ISNULL(@ur_filetype, 'GSCRIPT') LIKE 'GSCRIPT%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' GScript' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Scripts
      WHERE
        ISNULL(@ur_filetype, 'GSCRIPT') LIKE 'GSCRIPT%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' GScript' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Scripts
      WHERE
        ISNULL(@ur_filetype, 'GSCRIPT') LIKE 'GSCRIPT%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' GScript' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Scripts
      WHERE
        ISNULL(@ur_filetype, 'GSCRIPT') LIKE 'GSCRIPT%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' GScript' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Scripts
      WHERE
        ISNULL(@ur_filetype, 'GSCRIPT') LIKE 'GSCRIPT%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' GScript' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Scripts
      WHERE
        ISNULL(@ur_filetype, 'GSCRIPT') LIKE 'GSCRIPT%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Menu' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Menus
      WHERE
        ISNULL(@ur_filetype, 'MENU') LIKE 'MENU%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Menu' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Menus
      WHERE
        ISNULL(@ur_filetype, 'MENU') LIKE 'MENU%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Menu' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Menus
      WHERE
        ISNULL(@ur_filetype, 'MENU') LIKE 'MENU%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Menu' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Menus
      WHERE
        ISNULL(@ur_filetype, 'MENU') LIKE 'MENU%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Menu' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Menus
      WHERE
        ISNULL(@ur_filetype, 'MENU') LIKE 'MENU%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Menu' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Menus
      WHERE
        ISNULL(@ur_filetype, 'MENU') LIKE 'MENU%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' StrLabel' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Strings
      WHERE
        ISNULL(@ur_filetype, 'STRLABEL') LIKE 'STRLABEL%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' StrLabel' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Strings
      WHERE
        ISNULL(@ur_filetype, 'STRLABEL') LIKE 'STRLABEL%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' StrLabel' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Strings
      WHERE
        ISNULL(@ur_filetype, 'STRLABEL') LIKE 'STRLABEL%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' StrLabel' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Strings
      WHERE
        ISNULL(@ur_filetype, 'STRLABEL') LIKE 'STRLABEL%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' StrLabel' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Strings
      WHERE
        ISNULL(@ur_filetype, 'STRLABEL') LIKE 'STRLABEL%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' StrLabel' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Strings
      WHERE
        ISNULL(@ur_filetype, 'STRLABEL') LIKE 'STRLABEL%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Valdtr' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Validators
      WHERE
        ISNULL(@ur_filetype, 'VALDTR') LIKE 'VALDTR%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Valdtr' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Validators
      WHERE
        ISNULL(@ur_filetype, 'VALDTR') LIKE 'VALDTR%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Valdtr' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Validators
      WHERE
        ISNULL(@ur_filetype, 'VALDTR') LIKE 'VALDTR%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Valdtr' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Validators
      WHERE
        ISNULL(@ur_filetype, 'VALDTR') LIKE 'VALDTR%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Valdtr' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Validators
      WHERE
        ISNULL(@ur_filetype, 'VALDTR') LIKE 'VALDTR%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'FormDb' + @lit_bslash + name + ' Valdtr' + CASE WHEN @ur_filetype LIKE '%0' THEN '0' ELSE '' END + '.SQL' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Forms..Validators
      WHERE
        ISNULL(@ur_filetype, 'VALDTR') LIKE 'VALDTR%' AND
        ScopeType = CASE WHEN @ur_filetype LIKE '%0' THEN 0 ELSE 1 END AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'ObjDb' + @lit_bslash + CollectionName + ' IDOCol.XML' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Objects..Collections
      WHERE
        ISNULL(@ur_filetype, 'IDOCOL') LIKE 'IDOCOL%' AND
        DevelopmentFlag = 0 AND
        CollectionName LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'ObjDb' + @lit_bslash + CollectionName + ' IDOCol.XML' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Objects..Collections
      WHERE
        ISNULL(@ur_filetype, 'IDOCOL') LIKE 'IDOCOL%' AND
        DevelopmentFlag = 0 AND
        CollectionName LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        CollectionName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'ObjDb' + @lit_bslash + CollectionName + ' IDOCol.XML' AS name,
         1 AS sort_seq
      FROM ISM520_TPRTS_DEV_Objects..Collections
      WHERE
        ISNULL(@ur_filetype, 'IDOCOL') LIKE 'IDOCOL%' AND
        DevelopmentFlag = 0 AND
        CollectionName LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        CollectionName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        CollectionName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'ObjDb' + @lit_bslash + CollectionName + ' IDOCol.XML' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Objects..Collections
      WHERE
        ISNULL(@ur_filetype, 'IDOCOL') LIKE 'IDOCOL%' AND
        DevelopmentFlag = 0 AND
        CollectionName LIKE '%' + @ur_prefix + '%' AND
        CollectionName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        CollectionName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        CollectionName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'ObjDb' + @lit_bslash + CollectionName + ' IDOCol.XML' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Objects..Collections
      WHERE
        ISNULL(@ur_filetype, 'IDOCOL') LIKE 'IDOCOL%' AND
        DevelopmentFlag = 0 AND
        CollectionName LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        CollectionName NOT LIKE '%' + @ur_prefix + '%' AND
        CollectionName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        CollectionName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        CollectionName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'ObjDb' + @lit_bslash + CollectionName + ' IDOCol.XML' AS name,
         2 AS sort_seq
      FROM ISM520_TPRTS_DEV_Objects..Collections
      WHERE
        ISNULL(@ur_filetype, 'IDOCOL') LIKE 'IDOCOL%' AND
        DevelopmentFlag = 0 AND
        CollectionName LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        CollectionName NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        CollectionName NOT LIKE '%' + @ur_prefix + '%' AND
        CollectionName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        CollectionName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        CollectionName NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Fnct.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'FNCT') LIKE 'FNCT%' AND
        routine_type = 'FUNCTION' AND
        routine_name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Fnct.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'FNCT') LIKE 'FNCT%' AND
        routine_type = 'FUNCTION' AND
        routine_name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Fnct.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'FNCT') LIKE 'FNCT%' AND
        routine_type = 'FUNCTION' AND
        routine_name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Fnct.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'FNCT') LIKE 'FNCT%' AND
        routine_type = 'FUNCTION' AND
        routine_name LIKE '%' + @ur_prefix + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Fnct.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'FNCT') LIKE 'FNCT%' AND
        routine_type = 'FUNCTION' AND
        routine_name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE '%' + @ur_prefix + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Fnct.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'FNCT') LIKE 'FNCT%' AND
        routine_type = 'FUNCTION' AND
        routine_name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE '%' + @ur_prefix + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Proc.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'PROC') LIKE 'PROC%' AND
        routine_type = 'PROCEDURE' AND
        routine_name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Proc.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'PROC') LIKE 'PROC%' AND
        routine_type = 'PROCEDURE' AND
        routine_name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Proc.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'PROC') LIKE 'PROC%' AND
        routine_type = 'PROCEDURE' AND
        routine_name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Proc.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'PROC') LIKE 'PROC%' AND
        routine_type = 'PROCEDURE' AND
        routine_name LIKE '%' + @ur_prefix + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Proc.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'PROC') LIKE 'PROC%' AND
        routine_type = 'PROCEDURE' AND
        routine_name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE '%' + @ur_prefix + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + routine_name + ' Proc.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.routines
      WHERE
        ISNULL(@ur_filetype, 'PROC') LIKE 'PROC%' AND
        routine_name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE '%' + @ur_prefix + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        routine_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        routine_name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + TaskName + ' BGTask.SQL' AS name,
         1 AS sort_seq
      FROM BGTaskDefinitions
      WHERE
        ISNULL(@ur_filetype, 'BGTASK') LIKE 'BGTASK%' AND
        TaskName LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + TaskName + ' BGTask.SQL' AS name,
         1 AS sort_seq
      FROM BGTaskDefinitions
      WHERE
        ISNULL(@ur_filetype, 'BGTASK') LIKE 'BGTASK%' AND
        TaskName LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        TaskName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + TaskName + ' BGTask.SQL' AS name,
         1 AS sort_seq
      FROM BGTaskDefinitions
      WHERE
        ISNULL(@ur_filetype, 'BGTASK') LIKE 'BGTASK%' AND
        TaskName LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        TaskName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        TaskName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + TaskName + ' BGTask.SQL' AS name,
         2 AS sort_seq
      FROM BGTaskDefinitions
      WHERE
        ISNULL(@ur_filetype, 'BGTASK') LIKE 'BGTASK%' AND
        TaskName LIKE '%' + @ur_prefix + '%' AND
        TaskName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        TaskName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        TaskName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + TaskName + ' BGTask.SQL' AS name,
         2 AS sort_seq
      FROM BGTaskDefinitions
      WHERE
        ISNULL(@ur_filetype, 'BGTASK') LIKE 'BGTASK%' AND
        TaskName LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        TaskName NOT LIKE '%' + @ur_prefix + '%' AND
        TaskName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        TaskName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        TaskName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + TaskName + ' BGTask.SQL' AS name,
         2 AS sort_seq
      FROM BGTaskDefinitions
      WHERE
        ISNULL(@ur_filetype, 'BGTASK') LIKE 'BGTASK%' AND
        TaskName LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        TaskName NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        TaskName NOT LIKE '%' + @ur_prefix + '%' AND
        TaskName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        TaskName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        TaskName NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + GroupName + ' UserGroup.SQL' AS name,
         1 AS sort_seq
      FROM GroupNames
      WHERE
        ISNULL(@ur_filetype, 'USERGROUP') LIKE 'USERGROUP%' AND
        GroupName LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + GroupName + ' UserGroup.SQL' AS name,
         1 AS sort_seq
      FROM GroupNames
      WHERE
        ISNULL(@ur_filetype, 'USERGROUP') LIKE 'USERGROUP%' AND
        GroupName LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        GroupName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + GroupName + ' UserGroup.SQL' AS name,
         1 AS sort_seq
      FROM GroupNames
      WHERE
        ISNULL(@ur_filetype, 'USERGROUP') LIKE 'USERGROUP%' AND
        GroupName LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        GroupName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        GroupName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + GroupName + ' UserGroup.SQL' AS name,
         2 AS sort_seq
      FROM GroupNames
      WHERE
        ISNULL(@ur_filetype, 'USERGROUP') LIKE 'USERGROUP%' AND
        GroupName LIKE '%' + @ur_prefix + '%' AND
        GroupName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        GroupName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        GroupName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + GroupName + ' UserGroup.SQL' AS name,
         2 AS sort_seq
      FROM GroupNames
      WHERE
        ISNULL(@ur_filetype, 'USERGROUP') LIKE 'USERGROUP%' AND
        GroupName LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        GroupName NOT LIKE '%' + @ur_prefix + '%' AND
        GroupName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        GroupName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        GroupName NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppDb' + @lit_bslash + GroupName + ' UserGroup.SQL' AS name,
         2 AS sort_seq
      FROM GroupNames
      WHERE
        ISNULL(@ur_filetype, 'USERGROUP') LIKE 'USERGROUP%' AND
        GroupName LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        GroupName NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        GroupName NOT LIKE '%' + @ur_prefix + '%' AND
        GroupName NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        GroupName NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        GroupName NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' TableCol.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'TABLECOL') LIKE 'TABLECOL%' AND
        table_type = 'BASE TABLE' AND
        table_name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' TableCol.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'TABLECOL') LIKE 'TABLECOL%' AND
        table_type = 'BASE TABLE' AND
        table_name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' TableCol.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'TABLECOL') LIKE 'TABLECOL%' AND
        table_type = 'BASE TABLE' AND
        table_name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' TableCol.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'TABLECOL') LIKE 'TABLECOL%' AND
        table_type = 'BASE TABLE' AND
        table_name LIKE '%' + @ur_prefix + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' TableCol.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'TABLECOL') LIKE 'TABLECOL%' AND
        table_type = 'BASE TABLE' AND
        table_name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE '%' + @ur_prefix + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' TableCol.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'TABLECOL') LIKE 'TABLECOL%' AND
        table_type = 'BASE TABLE' AND
        table_name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE '%' + @ur_prefix + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' ViewCol.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'VIEWCOL') LIKE 'VIEWCOL%' AND
        table_type = 'VIEW' AND
        table_name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' ViewCol.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'VIEWCOL') LIKE 'VIEWCOL%' AND
        table_type = 'VIEW' AND
        table_name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' ViewCol.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'VIEWCOL') LIKE 'VIEWCOL%' AND
        table_type = 'VIEW' AND
        table_name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' ViewCol.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'VIEWCOL') LIKE 'VIEWCOL%' AND
        table_type = 'VIEW' AND
        table_name LIKE '%' + @ur_prefix + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' ViewCol.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'VIEWCOL') LIKE 'VIEWCOL%' AND
        table_type = 'VIEW' AND
        table_name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE '%' + @ur_prefix + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + table_name + ' ViewCol.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables
      WHERE
        ISNULL(@ur_filetype, 'VIEWCOL') LIKE 'VIEWCOL%' AND
        table_type = 'VIEW' AND
        table_name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE '%' + @ur_prefix + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        table_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        table_name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + sys_indexes.name + ' Index.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables schTABLES INNER JOIN sys.indexes sys_indexes ON OBJECT_NAME(sys_indexes.object_id) = schTABLES.table_name
      WHERE
        ISNULL(@ur_filetype, 'INDEX') LIKE 'INDEX%' AND
        table_type = 'BASE TABLE' AND
        sys_indexes.name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + sys_indexes.name + ' Index.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables schTABLES INNER JOIN sys.indexes sys_indexes ON OBJECT_NAME(sys_indexes.object_id) = schTABLES.table_name
      WHERE
        ISNULL(@ur_filetype, 'INDEX') LIKE 'INDEX%' AND
        table_type = 'BASE TABLE' AND
        sys_indexes.name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        sys_indexes.name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + sys_indexes.name + ' Index.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.tables schTABLES INNER JOIN sys.indexes sys_indexes ON OBJECT_NAME(sys_indexes.object_id) = schTABLES.table_name
      WHERE
        ISNULL(@ur_filetype, 'INDEX') LIKE 'INDEX%' AND
        table_type = 'BASE TABLE' AND
        sys_indexes.name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        sys_indexes.name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        sys_indexes.name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + sys_indexes.name + ' Index.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables schTABLES INNER JOIN sys.indexes sys_indexes ON OBJECT_NAME(sys_indexes.object_id) = schTABLES.table_name
      WHERE
        ISNULL(@ur_filetype, 'INDEX') LIKE 'INDEX%' AND
        table_type = 'BASE TABLE' AND
        sys_indexes.name LIKE '%' + @ur_prefix + '%' AND
        sys_indexes.name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        sys_indexes.name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        sys_indexes.name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + sys_indexes.name + ' Index.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables schTABLES INNER JOIN sys.indexes sys_indexes ON OBJECT_NAME(sys_indexes.object_id) = schTABLES.table_name
      WHERE
        ISNULL(@ur_filetype, 'INDEX') LIKE 'INDEX%' AND
        table_type = 'BASE TABLE' AND
        sys_indexes.name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        sys_indexes.name NOT LIKE '%' + @ur_prefix + '%' AND
        sys_indexes.name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        sys_indexes.name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        sys_indexes.name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + sys_indexes.name + ' Index.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.tables schTABLES INNER JOIN sys.indexes sys_indexes ON OBJECT_NAME(sys_indexes.object_id) = schTABLES.table_name
      WHERE
        ISNULL(@ur_filetype, 'INDEX') LIKE 'INDEX%' AND
        table_type = 'BASE TABLE' AND
        sys_indexes.name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        sys_indexes.name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        sys_indexes.name NOT LIKE '%' + @ur_prefix + '%' AND
        sys_indexes.name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        sys_indexes.name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        sys_indexes.name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + domain_name + ' DBType.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.domains
      WHERE
        ISNULL(@ur_filetype, 'DBTYPE') LIKE 'DBTYPE%' AND
        domain_name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + domain_name + ' DBType.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.domains
      WHERE
        ISNULL(@ur_filetype, 'DBTYPE') LIKE 'DBTYPE%' AND
        domain_name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        domain_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + domain_name + ' DBType.SQL' AS name,
         1 AS sort_seq
      FROM information_schema.domains
      WHERE
        ISNULL(@ur_filetype, 'DBTYPE') LIKE 'DBTYPE%' AND
        domain_name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        domain_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        domain_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + domain_name + ' DBType.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.domains
      WHERE
        ISNULL(@ur_filetype, 'DBTYPE') LIKE 'DBTYPE%' AND
        domain_name LIKE '%' + @ur_prefix + '%' AND
        domain_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        domain_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        domain_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + domain_name + ' DBType.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.domains
      WHERE
        ISNULL(@ur_filetype, 'DBTYPE') LIKE 'DBTYPE%' AND
        domain_name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        domain_name NOT LIKE '%' + @ur_prefix + '%' AND
        domain_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        domain_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        domain_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + domain_name + ' DBType.SQL' AS name,
         2 AS sort_seq
      FROM information_schema.domains
      WHERE
        ISNULL(@ur_filetype, 'DBTYPE') LIKE 'DBTYPE%' AND
        domain_name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        domain_name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        domain_name NOT LIKE '%' + @ur_prefix + '%' AND
        domain_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        domain_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        domain_name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' Trigger.SQL' AS name,
         1 AS sort_seq
      FROM sys.triggers
      WHERE
        ISNULL(@ur_filetype, 'TRIGGER') LIKE 'TRIGGER%' AND
        type = 'TR' AND
        name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' Trigger.SQL' AS name,
         1 AS sort_seq
      FROM sys.triggers
      WHERE
        ISNULL(@ur_filetype, 'TRIGGER') LIKE 'TRIGGER%' AND
        type = 'TR' AND
        name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' Trigger.SQL' AS name,
         1 AS sort_seq
      FROM sys.triggers
      WHERE
        ISNULL(@ur_filetype, 'TRIGGER') LIKE 'TRIGGER%' AND
        type = 'TR' AND
        name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' Trigger.SQL' AS name,
         2 AS sort_seq
      FROM sys.triggers
      WHERE
        ISNULL(@ur_filetype, 'TRIGGER') LIKE 'TRIGGER%' AND
        type = 'TR' AND
        name LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' Trigger.SQL' AS name,
         2 AS sort_seq
      FROM sys.triggers
      WHERE
        ISNULL(@ur_filetype, 'TRIGGER') LIKE 'TRIGGER%' AND
        type = 'TR' AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' Trigger.SQL' AS name,
         2 AS sort_seq
      FROM sys.triggers
      WHERE
        ISNULL(@ur_filetype, 'TRIGGER') LIKE 'TRIGGER%' AND
        type = 'TR' AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + class_name + ' UETCol.SQL' AS name,
         1 AS sort_seq
      FROM user_class
      WHERE
        ISNULL(@ur_filetype, 'UETCOL') LIKE 'UETCOL%' AND
        class_name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + class_name + ' UETCol.SQL' AS name,
         1 AS sort_seq
      FROM user_class
      WHERE
        ISNULL(@ur_filetype, 'UETCOL') LIKE 'UETCOL%' AND
        class_name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        class_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + class_name + ' UETCol.SQL' AS name,
         1 AS sort_seq
      FROM user_class
      WHERE
        ISNULL(@ur_filetype, 'UETCOL') LIKE 'UETCOL%' AND
        class_name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        class_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        class_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + class_name + ' UETCol.SQL' AS name,
         2 AS sort_seq
      FROM user_class
      WHERE
        ISNULL(@ur_filetype, 'UETCOL') LIKE 'UETCOL%' AND
        class_name LIKE '%' + @ur_prefix + '%' AND
        class_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        class_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        class_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + class_name + ' UETCol.SQL' AS name,
         2 AS sort_seq
      FROM user_class
      WHERE
        ISNULL(@ur_filetype, 'UETCOL') LIKE 'UETCOL%' AND
        class_name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        class_name NOT LIKE '%' + @ur_prefix + '%' AND
        class_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        class_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        class_name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + class_name + ' UETCol.SQL' AS name,
         2 AS sort_seq
      FROM user_class
      WHERE
        ISNULL(@ur_filetype, 'UETCOL') LIKE 'UETCOL%' AND
        class_name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        class_name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        class_name NOT LIKE '%' + @ur_prefix + '%' AND
        class_name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        class_name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        class_name NOT LIKE @ur_prefix + '%'



      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' DLL.SQL' AS name,
         1 AS sort_seq
      FROM sys.assemblies
      WHERE
        ISNULL(@ur_filetype, 'DLL') LIKE 'DLL%' AND
        name LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' DLL.SQL' AS name,
         1 AS sort_seq
      FROM sys.assemblies
      WHERE
        ISNULL(@ur_filetype, 'DLL') LIKE 'DLL%' AND
        name LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' DLL.SQL' AS name,
         1 AS sort_seq
      FROM sys.assemblies
      WHERE
        ISNULL(@ur_filetype, 'DLL') LIKE 'DLL%' AND
        name LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' DLL.SQL' AS name,
         2 AS sort_seq
      FROM sys.assemblies
      WHERE
        ISNULL(@ur_filetype, 'DLL') LIKE 'DLL%' AND
        name LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' DLL.SQL' AS name,
         2 AS sort_seq
      FROM sys.assemblies
      WHERE
        ISNULL(@ur_filetype, 'DLL') LIKE 'DLL%' AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + 'AppSch' + @lit_bslash + name + ' DLL.SQL' AS name,
         2 AS sort_seq
      FROM sys.assemblies
      WHERE
        ISNULL(@ur_filetype, 'DLL') LIKE 'DLL%' AND
        name LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE '%' + @ur_prefix + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        name NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        name NOT LIKE @ur_prefix + '%'



      ORDER BY
        sort_seq,
         name

  END --INFORMATION_SCHEMA
  ELSE BEGIN
    SELECT DISTINCT
        @lit_bslash + SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) + '.RDL' AS name,
         1 AS sort_seq
      FROM catalog
      WHERE
        ISNULL(@ur_filetype, 'RDL') LIKE 'RDL%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) + '.RDL' AS name,
         1 AS sort_seq
      FROM catalog
      WHERE
        ISNULL(@ur_filetype, 'RDL') LIKE 'RDL%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) + '.RDL' AS name,
         1 AS sort_seq
      FROM catalog
      WHERE
        ISNULL(@ur_filetype, 'RDL') LIKE 'RDL%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) + '.RDL' AS name,
         2 AS sort_seq
      FROM catalog
      WHERE
        ISNULL(@ur_filetype, 'RDL') LIKE 'RDL%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) LIKE '%' + @ur_prefix + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) + '.RDL' AS name,
         2 AS sort_seq
      FROM catalog
      WHERE
        ISNULL(@ur_filetype, 'RDL') LIKE 'RDL%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE '%' + @ur_prefix + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE @ur_prefix + '%'

      UNION ALL
      SELECT DISTINCT
        @lit_bslash + SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) + '.RDL' AS name,
         2 AS sort_seq
      FROM catalog
      WHERE
        ISNULL(@ur_filetype, 'RDL') LIKE 'RDL%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) LIKE '%' + REPLACE(@ur_prefix, ' ', '%') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE '%' + REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE '%' + @ur_prefix + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE REPLACE(@ur_prefix, ' ', '%') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE REPLACE(@ur_prefix, ' ', '[_]') + '%' AND
        SUBSTRING(catalog.path, LEN(catalog.path) - ISNULL(NULLIF(CHARINDEX('/', REVERSE(catalog.path)), 0) - 2, 1), LEN(catalog.path)) NOT LIKE @ur_prefix + '%'



      ORDER BY
        sort_seq,
         name
  END --INFORMATION_SCHEMA
