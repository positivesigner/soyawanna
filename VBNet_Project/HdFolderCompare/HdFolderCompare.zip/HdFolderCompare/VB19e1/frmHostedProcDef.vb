﻿Imports System.ComponentModel

Public Class frmHostedProcDef
    Const strvLIT_USER_PROFILE_DOWNLOADS = "%USERPROFILE%\downloads"
    Private strvDOWNLOADS_FOLDER As String
    Private objvCOMPARE_LIST As System.Windows.Forms.ListBox
    Private bolvLEAVE_FILE As Boolean
    Private strvCURRENT_FILE As String
    Private strvCURRENT_PATH As String
    Private strvCOMPARE_FILE As String
    Private strvCURRENT_COMPARE_FOLDER As String
    Private strvCURRENT_EXPORT_FOLDER As String
    Private strvBCMP_EXEC_PATH As String
    Private dteTIMER_START As Date
    Private dteRECENT_SHOWING As Date

    Private Sub frmHostedProcDef_Load(sender As Object, e As System.EventArgs) Handles MyBase.Load
        Me.bolvLEAVE_FILE = frmHdFolders.bolvLEAVE_FILE
        Me.strvDOWNLOADS_FOLDER = System.Environment.ExpandEnvironmentVariables(strvLIT_USER_PROFILE_DOWNLOADS)
        Me.objvCOMPARE_LIST = frmHdFolders.objvCOMPARE_LIST
        Me.strvCOMPARE_FILE = frmHdFolders.strvCOMPARE_FILE
        Me.strvCURRENT_EXPORT_FOLDER = frmHdFolders.strvCURRENT_EXPORT_FOLDER
        Me.strvCURRENT_COMPARE_FOLDER = frmHdFolders.strvCURRENT_COMPARE_FOLDER
        Path_Parameters.Beyond_Compare = Path_Parameters.Beyond_Compare
        Call Me.lstFile.Items.Clear()
        If Mx.HasText(Me.strvCOMPARE_FILE) Then
            Me.lstFile.Items.Add(strvCOMPARE_FILE)

        Else
            For Each strITEM As String In objvCOMPARE_LIST.Items
                Me.lstFile.Items.Add(strITEM)
            Next
        End If 'strvCOMPARE_FILE

        Me.chk30SecShowing.Checked = True
        Me.dteRECENT_SHOWING = Now()
        Call Submit_File()
    End Sub 'frmHostedProcDef_Load

    Private Sub Timer1_Tick(sender As Object, e As System.EventArgs) Handles Timer1.Tick
        Call Me.Timer1.Stop()
        Me.lblTimer.Text = "Waiting for Downloads: " & System.Math.Floor(Now().Subtract(Me.dteTIMER_START).TotalSeconds).ToString & " seconds"
        Dim strFOUND_FILE = Mx.mt
        For Each strENTRY In System.IO.Directory.GetFiles(Me.strvDOWNLOADS_FOLDER, Me.strvCURRENT_FILE)
            strFOUND_FILE = strENTRY
        Next

        If Mx.HasText(strFOUND_FILE) = False Then
            If Me.chk30SecShowing.Checked AndAlso
              Now().Subtract(Me.dteRECENT_SHOWING).TotalSeconds > 30 Then
                Me.dteRECENT_SHOWING = Now()
                Call AppActivate(Me.Text)
            End If

            Call Me.Timer1.Start()

        Else
            If Me.bolvLEAVE_FILE Then
                Call Me.Close()

            Else
                Dim strOUTPUT_FILE = System.IO.Path.Combine(Me.strvCURRENT_EXPORT_FOLDER, "." & Me.strvCURRENT_PATH)
                Dim strOUTPUT_FOLDER = System.IO.Path.GetDirectoryName(strOUTPUT_FILE)
                Call System.IO.Directory.CreateDirectory(strOUTPUT_FOLDER)
                For Each strDEL_FILE In System.IO.Directory.GetFiles(strOUTPUT_FOLDER, Me.strvCURRENT_FILE)
                    System.IO.File.Delete(strDEL_FILE)
                Next

                Call System.IO.File.Move(strFOUND_FILE, strOUTPUT_FILE)
                Me.lstFile.Items.Remove(Me.strvCURRENT_PATH)
                If Me.lstFile.Items.Count > 0 Then
                    Call Submit_File()
                Else
                    Call Show_Comparison(Me.strvCURRENT_COMPARE_FOLDER, Me.strvCURRENT_EXPORT_FOLDER)
                    Call Me.Close()
                End If 'lstFile
            End If 'bolvLEAVE_FILE
        End If 'strFOUND_FILE
    End Sub 'Timer1_Tick

    Private Sub btnSkipFile_Click(sender As Object, e As System.EventArgs) Handles btnSkipFile.Click
        Call Me.Timer1.Stop()
        If Me.lstFile.Items.Count > 0 Then
            Me.lstFile.Items.Remove(Me.strvCURRENT_PATH)
            If Me.lstFile.Items.Count > 0 Then
                Call Submit_File()
            Else
                Call Show_Comparison(Me.strvCURRENT_COMPARE_FOLDER, Me.strvCURRENT_EXPORT_FOLDER)
                Call Me.Close()
            End If
        End If
    End Sub

    Private Sub Submit_File()
        If Me.lstFile.Items.Count > 0 Then
            Me.strvCURRENT_PATH = Me.lstFile.Items(0).ToString
            Me.strvCURRENT_FILE = System.IO.Path.GetFileName(Me.strvCURRENT_PATH)
            My.Computer.Clipboard.SetText(strvCURRENT_FILE)
            Microsoft.VisualBasic.Interaction.AppActivate(Path_Parameters.Hosted_Browser_TabName)
            System.Windows.Forms.SendKeys.SendWait("^V{Tab} ")
            Me.dteTIMER_START = Now
            Call Me.Timer1.Start()
        End If
    End Sub 'Submit_File

    Private Sub btnReSubmit_Click(sender As Object, e As System.EventArgs) Handles btnReSubmit.Click
        Call Me.Timer1.Stop()
        Call Submit_File()
    End Sub

    Public Sub Show_Comparison(ur_out_folder As String, ur_cmp_folder As String)
        If System.IO.File.Exists(Path_Parameters.Beyond_Compare) = False Then
            MsgBox("Cannot find path to run program: " & Path_Parameters.Beyond_Compare)
        ElseIf Microsoft.VisualBasic.Right(Path_Parameters.Beyond_Compare, 4).ToLower = ".cmd" Then
            System.Diagnostics.Process.Start(Path_Parameters.Beyond_Compare, " /out_subdir=" & """" & ur_out_folder.Replace("""", """""") & """" & " /in_subdir=" & """" & ur_cmp_folder.Replace("""", """""") & """")
        Else
            System.Diagnostics.Process.Start(Path_Parameters.Beyond_Compare, """" & ur_out_folder.Replace("""", """""") & """" & " " & """" & ur_cmp_folder.Replace("""", """""") & """")
        End If
    End Sub 'Show_Comparison

    Private Sub frmHostedProcDef_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Call Me.Timer1.Stop()
    End Sub
End Class 'frmHostedProcDef