﻿Imports System.Windows.Forms

Public Class Database
    Public Shared Environments As Environments
    Public Shared ExportTypes As ExportTypes
    Public Shared HDFolders As HDFolders
    Public Shared NoteTypes As NoteTypes
    Public Shared FolderCallback As FolderCallback

    Public Shared Sub Assign_FolderCallback(ur_form As frmHdFolders, ur_file_list As System.Windows.Forms.ListBox)
        Database.FolderCallback = New FolderCallback(ur_form, ur_file_list)
    End Sub

    Public Shared Sub Load_Database_Lists(ur_flag_byticket As Boolean)
        Database.Environments = New Environments
        Database.ExportTypes = New ExportTypes
        Database.NoteTypes = New NoteTypes
        Database.HDFolders = New HDFolders(ur_flag_byticket)
    End Sub 'Load_Database_Lists

    Public Shared Function Refresh_HDFolders(ur_flag_byticket As Boolean) As HDFolders
        Database.HDFolders = New HDFolders(ur_flag_byticket)
        Refresh_HDFolders = Database.HDFolders
    End Function
End Class 'Database

Public Class FolderCallback
    Public FoldersForm As frmHdFolders
    Public DownloadsFolder As String
    Public FileList As System.Windows.Forms.ListBox

    Const strvLIT_USER_PROFILE_DOWNLOADS = "%USERPROFILE%\downloads"

    Public Sub New(ur_form As frmHdFolders, ur_file_list As System.Windows.Forms.ListBox)
        Me.FoldersForm = frmHdFolders
        Me.DownloadsFolder = System.Environment.ExpandEnvironmentVariables(strvLIT_USER_PROFILE_DOWNLOADS)
        Me.FileList = ur_file_list
    End Sub 'New

    Public Function Open_DBConnection() As System.Data.SqlClient.SqlConnection
        Dim retCONN = Nothing
        Dim strSIDE = "First"
        If Me.FileList Is Me.FoldersForm.lstC_FILE Then
            strSIDE = "Comparison"
            For Each env_entry In User_Selection.Comparison_Selected
                retCONN = New System.Data.SqlClient.SqlConnection(env_entry.DBConnection_String)
            Next

        Else 'FileList
            For Each env_entry In User_Selection.Environment_Selected
                retCONN = New System.Data.SqlClient.SqlConnection(env_entry.DBConnection_String)
            Next
        End If 'FileList

        Open_DBConnection = retCONN

        If retCONN Is Nothing Then
            Throw New System.Exception("Database parameters must be entered for " & strSIDE & " side")

        Else
            If retCONN.State = System.Data.ConnectionState.Open Then
                retCONN.Close()
            End If 'State

            retCONN.Open()
            Call System.Data.SqlClient.SqlConnection.ClearPool(retCONN)
        End If 'retCONN
    End Function 'Open_DBConnection

    Public Function Environment_Is_AppActivate() As Boolean
        Environment_Is_AppActivate = False
        If Me.FileList Is Me.FoldersForm.lstC_FILE Then
            For Each env_entry In User_Selection.Comparison_Selected
                Environment_Is_AppActivate = Mx.AreEqual(env_entry.BaseConnection_String, "AppActivate")
            Next

        Else 'FileList
            For Each env_entry In User_Selection.Environment_Selected
                Environment_Is_AppActivate = Mx.AreEqual(env_entry.BaseConnection_String, "AppActivate")
            Next
        End If 'FileList
    End Function 'Environment_Is_AppActivate

    Public Sub Side_Export_Click()
        If Me.FileList Is Me.FoldersForm.lstC_FILE Then
            Call Me.FoldersForm.btnC_Export_Click()
        Else
            Call Me.FoldersForm.btnE_Export_Click()
        End If
    End Sub 'Side_Export_Click
End Class 'FolderCallback

Public Class Environments
    Inherits System.Collections.Generic.List(Of OneEnvironment)

    Public Class OneEnvironment
        Public Name As String
        Public Connection_String As String
    End Class

    Public Sub New()
        Dim objAPP_SETTINGS = System.Configuration.ConfigurationManager.AppSettings
        Dim lstNAMES As New System.Collections.Generic.List(Of String)
        For Each entry In From strKEY In objAPP_SETTINGS.Keys Where Mx.StartingWithText(strKEY, "ENV")
            Dim strENTRY = objAPP_SETTINGS.Item(entry)
            For Each strFIELD In strENTRY.Split(","c)
                If (From row In Me Where row.Name = strFIELD).Count > 0 Then
                    Throw New System.Exception("Duplicate Environment listed: " & strFIELD)
                End If

                lstNAMES.Add(strFIELD)
            Next strFIELD
        Next entry

        For Each entry In lstNAMES
            Dim new_environment = New OneEnvironment
            new_environment.Name = entry
            For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
                Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
                If strKEY.ToUpper = entry.ToUpper Then
                    new_environment.Connection_String = objAPP_SETTINGS.Item(KEYCTR)
                    Exit For
                End If
            Next KEYCTR

            If String.IsNullOrWhiteSpace(new_environment.Connection_String) Then
                Throw New System.Exception("Environment connection string not found: " & entry)
            End If

            Me.Add(new_environment)
        Next entry
    End Sub 'New
End Class 'Environments


Public Class ExportTypes
    Inherits System.Collections.Generic.List(Of OneExportType)

    Public Class OneExportType
        Public Name As String
        Public Waiting_Folder As Boolean
    End Class

    Public Sub New()
        Dim objAPP_SETTINGS = System.Configuration.ConfigurationManager.AppSettings
        Dim lstNAME As New System.Collections.Generic.List(Of String)
        For Each entry In From strKEY In objAPP_SETTINGS.Keys Where Mx.StartingWithText(strKEY, "EXPORT")
            Dim strENTRY = objAPP_SETTINGS.Item(entry)
            For Each strFIELD In strENTRY.Split(","c)
                If (From row In Me Where row.Name = strFIELD).Count > 0 Then
                    Throw New System.Exception("Duplicate Export Type listed: " & strFIELD)
                End If

                Call lstNAME.Add(strFIELD)
            Next strFIELD
        Next entry

        For Each entry In lstNAME
            Dim new_exporttype = New OneExportType
            new_exporttype.Name = entry
            new_exporttype.Waiting_Folder = Mx.EndingWithText(entry, " Branch")
            Me.Add(new_exporttype)
        Next
    End Sub 'New
End Class 'ExportTypes


Public Class HDFolders
    Inherits System.Collections.Generic.List(Of OneHDFolder)

    Public Class OneHDFolder
        Public Name As String
        Public Sort_Value As String
        Public Path As String
        Public Environment_Folders As Environment_Folders
        Public Notes_Files As Notes_Files

        Public Function Refresh_Environment_Folders() As Environment_Folders
            Me.Environment_Folders = New Environment_Folders(Me.Path)
            Refresh_Environment_Folders = Me.Environment_Folders
        End Function

        Public Function Refresh_Notes_Files() As Notes_Files
            Me.Notes_Files = New Notes_Files(Me.Path)
            Refresh_Notes_Files = Me.Notes_Files
        End Function
    End Class 'OneHDFolder

    Public Class Environment_Folders
        Inherits System.Collections.Generic.List(Of OneEnvironmentFolder)

        Public Class OneEnvironmentFolder
            Public Name As String
            Public BaseConnection_String As String
            Public IsAppActivate As Boolean
            Public DBConnection_String As String
            Public Environment_Name As String
            Public Path As String
            Public Environment_Files As Environment_Files

            Public Function Refresh_Environment_Files() As Environment_Files
                Me.Environment_Files = New Environment_Files(Me.Path)
                Refresh_Environment_Files = Me.Environment_Files
            End Function
        End Class 'OneEnvironmentFolder

        Public Sub New(ur_hdfolder_path As String)
            Dim strcSERVER = "server="
            Dim strcAPPDB = "appdb="

            For Each strPATH In System.IO.Directory.EnumerateDirectories(ur_hdfolder_path, "*", System.IO.SearchOption.TopDirectoryOnly)
                Dim new_environment_folder = New OneEnvironmentFolder
                new_environment_folder.Name = System.IO.Path.GetFileName(strPATH)
                new_environment_folder.Environment_Name = new_environment_folder.Name.Split(" "c).First
                new_environment_folder.Path = strPATH

                For Each entry In From row In Database.Environments Where row.Name = new_environment_folder.Environment_Name
                    new_environment_folder.Environment_Files = New Environment_Files(new_environment_folder.Path)
                    new_environment_folder.BaseConnection_String = entry.Connection_String
                    new_environment_folder.IsAppActivate = Mx.AreEqual(new_environment_folder.BaseConnection_String, "AppActivate")
                    Dim strSERVER_NAME = ""
                    Dim strAPPDB_NAME = ""
                    For Each strENTRY In entry.Connection_String.Split("/")
                        If Mid(strENTRY.ToLower, 1, Len(strcSERVER)) = strcSERVER Then
                            strSERVER_NAME = Trim(Mid(strENTRY, Len(strcSERVER) + 1))
                        End If

                        If Mid(strENTRY.ToLower, 1, Len(strcAPPDB)) = strcAPPDB Then
                            strAPPDB_NAME = Trim(Mid(strENTRY, Len(strcAPPDB) + 1))
                        End If
                    Next strENTRY

                    new_environment_folder.DBConnection_String = String.Format("Server={0};Database={1};Integrated Security=SSPI", strSERVER_NAME, strAPPDB_NAME)
                    Me.Add(new_environment_folder)
                Next entry
            Next strPATH
        End Sub 'New

        Public Class Environment_Files
            Inherits System.Collections.Generic.List(Of OneEnvironmentFolder)

            Public Class OneEnvironmentFolder
                Public Name As String
                Public Path As String
            End Class

            Public Sub New(ur_envfolder_path As String)
                For Each strPATH In System.IO.Directory.EnumerateFiles(ur_envfolder_path, "*.*", System.IO.SearchOption.AllDirectories)
                    Dim new_environment_folder = New OneEnvironmentFolder
                    new_environment_folder.Name = System.IO.Path.Combine(System.IO.Path.GetFileName(System.IO.Path.GetDirectoryName(strPATH)), System.IO.Path.GetFileName(strPATH))
                    new_environment_folder.Path = strPATH
                    Me.Add(new_environment_folder)
                Next strPATH
            End Sub 'New
        End Class 'Environment_Files
    End Class 'Environment_Folders


    Public Class Notes_Files
        Inherits System.Collections.Generic.List(Of OneNotesFile)

        Public Class OneNotesFile
            Public Name As String
            Public Path As String
        End Class

        Public Sub New(ur_hdfolder_path As String)
            For Each strNOTE_DIR In System.IO.Directory.EnumerateDirectories(ur_hdfolder_path, "Notes")
                For Each strPATH In System.IO.Directory.EnumerateDirectories(strNOTE_DIR, "*", System.IO.SearchOption.TopDirectoryOnly)
                    Dim new_notes_file = New OneNotesFile
                    new_notes_file.Name = System.IO.Path.GetFileName(strPATH)
                    new_notes_file.Path = strPATH
                    Me.Add(new_notes_file)
                Next strPATH
            Next strNOTE_DIR
        End Sub 'New
    End Class 'Notes_Files

    Public Sub New(Optional ur_flag_byticket As Boolean = False)
        Dim lstSORT = New System.Collections.Generic.List(Of String)
        Dim sdaSORT = New System.Collections.Generic.Dictionary(Of String, OneHDFolder)
        For Each strHD_PATH In System.IO.Directory.EnumerateDirectories(Path_Parameters.Repository_Folder, "* hd*", System.IO.SearchOption.TopDirectoryOnly)
            Dim strHD_NAME = System.IO.Path.GetFileName(strHD_PATH)
            Dim intHD_SUFFIX = InStr(strHD_NAME, " hd")
            Dim strSORT = strHD_NAME
            If ur_flag_byticket = True AndAlso
              intHD_SUFFIX > 0 Then
                strSORT = Trim(Mid(strHD_NAME, intHD_SUFFIX))
            End If

            Dim new_hdfolder = New OneHDFolder
            new_hdfolder.Name = strHD_NAME
            new_hdfolder.Sort_Value = strSORT
            new_hdfolder.Path = strHD_PATH

            If lstSORT.Contains(strSORT) Then
                Throw New System.Exception("HD Folder already exists with a different date: " & strSORT)
            End If

            new_hdfolder.Environment_Folders = New Environment_Folders(strHD_PATH)
            lstSORT.Add(strSORT)
            sdaSORT.Add(strSORT, new_hdfolder)
        Next strHD_PATH

        lstSORT.Sort()
        For Each strENTRY In lstSORT
            Me.Add(sdaSORT.Item(strENTRY))
        Next
    End Sub 'New
End Class 'HDFolders


Public Class NoteTypes
    Inherits System.Collections.Generic.List(Of OneNoteType)

    Public Class OneNoteType
        Public Name As String
    End Class

    Public Sub New()
        Dim objAPP_SETTINGS = System.Configuration.ConfigurationManager.AppSettings
        Dim lstNAME As New System.Collections.Generic.List(Of String)
        For Each entry In From strKEY In objAPP_SETTINGS.Keys Where Mx.StartingWithText(strKEY, "NOTE")
            Dim strENTRY = objAPP_SETTINGS.Item(entry)
            If (From row In Me Where row.Name = strENTRY).Count > 0 Then
                Throw New System.Exception("Duplicate Note Type listed: " & strENTRY)
            End If

            Call lstNAME.Add(strENTRY)
        Next entry

        For Each entry In lstNAME
            Dim new_exporttype = New OneNoteType
            new_exporttype.Name = entry
        Next
    End Sub 'New
End Class 'NoteTypes

Public Class Path_Parameters
    Public Shared Application_Folder As String
    Public Shared Beyond_Compare As String
    Public Shared Hosted_Browser_TabName As String
    Public Shared Notepad_PlusPlus As String
    Public Shared Repository_Folder As String
    Public Shared Session_File As String
    Public Shared SQL_Export_Error_Search As String
    Public Shared SQL_Export_Script As String

    Public Shared Sub Load_Path_Parameters()
        Path_Parameters.Application_Folder = My.Application.Info.DirectoryPath
        Path_Parameters.Repository_Folder = System.IO.Path.GetDirectoryName(Path_Parameters.Application_Folder)
        If Mx.AreEqual(System.IO.Path.GetFileName(Path_Parameters.Repository_Folder), "bin") Then
            Path_Parameters.Repository_Folder = "C:\BitBucket\tpr_gotoassisttickets"
            Path_Parameters.Application_Folder = System.IO.Path.Combine(Path_Parameters.Repository_Folder, "SpProcDef")
            System.IO.File.Copy(System.IO.Path.Combine(Path_Parameters.Application_Folder, "HdFolderCompare.exe.config"), System.IO.Path.Combine(My.Application.Info.DirectoryPath, "HdFolderCompare.exe.config"), True)
        End If

        Path_Parameters.Session_File = System.IO.Path.GetFileName(System.Reflection.Assembly.GetExecutingAssembly.Location) & ".session"

        Path_Parameters.Beyond_Compare = Path_Parameters.Application_Folder & "SpProcDef\BCompare_Timer.vbscript.cmd"
        If System.IO.File.Exists(Path_Parameters.Beyond_Compare) = False Then
            Path_Parameters.Beyond_Compare = "C:\Program Files\Beyond Compare 4\BCompare.exe"
        End If

        If System.IO.File.Exists(Path_Parameters.Beyond_Compare) = False Then
            Path_Parameters.Beyond_Compare = Path_Parameters.Application_Folder & "\SpProcDef\BCompare_Timer.vbscript.cmd"
        End If


        Path_Parameters.Notepad_PlusPlus = "C:\Program Files\Notepad++\notepad++.exe"
        If System.IO.File.Exists(Path_Parameters.Notepad_PlusPlus) = False Then
            Path_Parameters.Notepad_PlusPlus = "C:\Program Files (x86)\Notepad++\notepad++.exe"
        End If

        If System.IO.File.Exists(Path_Parameters.Notepad_PlusPlus) = False Then
            Path_Parameters.Notepad_PlusPlus = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location) & "\..\..\NotePadPP\Notepad++Portable.exe"
        End If

        If System.IO.File.Exists(Path_Parameters.Notepad_PlusPlus) = False Then
            Path_Parameters.Notepad_PlusPlus = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location) & "\Notepad++_Timer.vbscript.cmd"
        End If


        Dim objAPP_SETTINGS = System.Configuration.ConfigurationManager.AppSettings
        For Each entry In From strKEY In objAPP_SETTINGS.Keys Where Mx.StartingWithText(strKEY, "SQLPROCDEF")
            Dim strENTRY = objAPP_SETTINGS.Item(entry)
            Path_Parameters.SQL_Export_Script = System.IO.Path.Combine(Path_Parameters.Application_Folder, strENTRY & ".vbscript.cmd")
            Path_Parameters.SQL_Export_Error_Search = strENTRY & "*.err.txt"
        Next entry

        If String.IsNullOrWhiteSpace(Path_Parameters.SQL_Export_Script) Then
            Path_Parameters.SQL_Export_Script = System.IO.Path.Combine(Path_Parameters.Application_Folder, "SqlProcDef_CollectionsNoQTA.vbscript.cmd")
            Path_Parameters.SQL_Export_Error_Search = "SqlProcDef_CollectionsNoQTA*.err.txt"
        End If

        For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
            Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
            Dim strENTRY = objAPP_SETTINGS.Item(KEYCTR)

            If strKEY.ToUpper = "HOSTING_APP" Then
                Path_Parameters.Hosted_Browser_TabName = strENTRY
            End If
        Next KEYCTR

        If String.IsNullOrWhiteSpace(Path_Parameters.Hosted_Browser_TabName) Then
            Path_Parameters.Hosted_Browser_TabName = "CloudSuite Field Service"
        End If
    End Sub 'Load_Path_Parameters
End Class 'Path_Parameters


Public Class User_Selection
    Public Shared HDFolder_Entry As String
    Public Shared Environment_Entry As String
    Public Shared Comparison_Entry As String

    Public Shared Sub Load_UserSelections()
        User_Selection.HDFolder_Entry = ""
        User_Selection.Environment_Entry = ""
        User_Selection.Comparison_Entry = ""
        For Each strFILE_PATH In System.IO.Directory.EnumerateFiles(Path_Parameters.Application_Folder, Path_Parameters.Session_File)
            Dim straLINE = System.IO.File.ReadAllLines(strFILE_PATH)
            For LINCTR = 0 To UBound(straLINE)
                Select Case LINCTR
                    Case 0
                        User_Selection.HDFolder_Entry = straLINE(LINCTR)
                    Case 1
                        User_Selection.Environment_Entry = straLINE(LINCTR)
                    Case 2
                        User_Selection.Comparison_Entry = straLINE(LINCTR)
                    Case Else
                        Exit For
                End Select
            Next LINCTR
        Next strFILE_PATH
    End Sub 'Load_UserSelections

    Public Shared Function HDFolder_Path() As String
        HDFolder_Path = (From row In Database.HDFolders Where row.Name = User_Selection.HDFolder_Entry Select row.Path).DefaultIfEmpty("").First
    End Function

    Public Shared Function HDFolder_Selected() As HDFolders.OneHDFolder()
        HDFolder_Selected = (From row In Database.HDFolders Where row.Name = User_Selection.HDFolder_Entry Select row).ToArray
    End Function

    Public Shared Function Environment_Selected() As HDFolders.Environment_Folders.OneEnvironmentFolder()
        Environment_Selected = {}
        For Each entry In User_Selection.HDFolder_Selected
            Environment_Selected = (From row In entry.Environment_Folders Where row.Name = User_Selection.Environment_Entry).ToArray
        Next
    End Function

    Public Shared Function Comparison_Selected() As HDFolders.Environment_Folders.OneEnvironmentFolder()
        Comparison_Selected = {}
        For Each entry In User_Selection.HDFolder_Selected
            Comparison_Selected = (From row In entry.Environment_Folders Where row.Name = User_Selection.Comparison_Entry).ToArray
        Next
    End Function
End Class 'User_Selection


Namespace Mx
    Public Class ListBoxSearch
        Public Shared Function IndexOf_c(ur_listbox As System.Windows.Forms.ListBox, ur_text As String) As Integer
            IndexOf_c = -1
            For ENTCTR = 0 To ur_listbox.Items.Count - 1
                If String.Equals(ur_listbox.Items.Item(ENTCTR), ur_text, System.StringComparison.CurrentCultureIgnoreCase) Then
                    IndexOf_c = ENTCTR
                    Exit For
                End If
            Next ENTCTR
        End Function 'ListBoxIndexOf_c

        Public Shared Function gCurEntry(ur_cbo_box As System.Windows.Forms.ComboBox) As String
            gCurEntry = mt
            Dim strSRCH_TEXT = ur_cbo_box.Text
            For ENTCTR = 0 To ur_cbo_box.Items.Count - 1
                If String.Equals(ur_cbo_box.Items.Item(ENTCTR), strSRCH_TEXT, System.StringComparison.CurrentCultureIgnoreCase) Then
                    gCurEntry = ur_cbo_box.Items.Item(ENTCTR)
                    Exit For
                End If
            Next ENTCTR
        End Function 'gCurEntry
    End Class

    Public Class WindowSearch
        Public Sub Example_Exec_ListAdd()
            Mx.WindowSearch.EnumWindowsDllImport(New Mx.WindowSearch.EnumWindowsCallback(AddressOf Example_FillActiveWindowsList_InListBox), 0)
        End Sub

        Public Function Example_FillActiveWindowsList_InListBox(ByVal hWnd As Integer, ByVal lParam As Integer) As Boolean
            Example_FillActiveWindowsList_InListBox = True
            Dim stbFOUND_TITLE As New System.Text.StringBuilder(255)
            Mx.WindowSearch.GetWindowText(hWnd, stbFOUND_TITLE, 255)
            Dim bolIS_ACTIVE = Mx.WindowSearch.ProcessIsActiveWindow(hWnd)
            Dim strFOUND_TITLE = stbFOUND_TITLE.ToString
            Dim strFOLDER = strFOUND_TITLE
            Dim intFOLDER = InStr(strFOUND_TITLE.ToUpper, " - XYPLORER")
            If intFOLDER > 0 Then
                strFOLDER = Mid(strFOUND_TITLE, 1, intFOLDER - 1)
            End If

            Dim intHD_FOLDER = InStr(strFOLDER, " hd")
            'Dim bolEXISTS_IN_LIST = Me.lstFolder.Items.Contains(strFOLDER)
            If bolIS_ACTIVE AndAlso
              intFOLDER > 0 AndAlso
              intHD_FOLDER > 0 Then 'AndAlso
                'bolEXISTS_IN_LIST = False Then
                'Me.lstFolder.Items.Insert(0, strFOLDER)
            End If
        End Function 'Example_FillActiveWindowsList_InListBox


        Public Delegate Function EnumWindowsCallback _
          (
            ByVal hWnd As Integer,
            ByVal lParam As Integer
          ) As Boolean

        Public Declare Function EnumWindows Lib "user32.dll" Alias "EnumWindows" _
          (
            ByVal callback As EnumWindowsCallback,
            ByVal lParam As Integer
          ) As Integer

        <System.Runtime.InteropServices.DllImport(
            "user32.dll",
            EntryPoint:="EnumWindows", SetLastError:=True,
            CharSet:=System.Runtime.InteropServices.CharSet.Ansi,
            ExactSpelling:=True,
            CallingConvention:=System.Runtime.InteropServices.CallingConvention.StdCall
          )>
        Public Shared Function EnumWindowsDllImport _
          (
            ByVal callback As EnumWindowsCallback,
            ByVal lParam As Integer
          ) As Integer
        End Function

        Public Declare Sub GetWindowText Lib "user32.dll" Alias "GetWindowTextA" _
          (
            ByVal hWnd As Integer,
            ByVal lpString As System.Text.StringBuilder,
            ByVal nMaxCount As Integer
          )

        Public Declare Function GetWindowLong Lib "user32.dll" Alias "GetWindowLongA" _
          (
            ByVal hwnd As Integer,
            ByVal nIndex As Integer
          ) As Integer

        Public Declare Function GetWindow Lib "user32.dll" Alias "GetWindow" _
          (
            ByVal hwnd As Integer,
            ByVal wCmd As Integer
          ) As Integer

        Public Declare Function IsWindowVisible Lib "user32.dll" Alias "IsWindowVisible" _
          (
            ByVal hwnd As Integer
          ) As Boolean

        Public Declare Function GetParent Lib "user32.dll" Alias "GetParent" _
          (
            ByVal hwnd As Integer
          ) As Integer

        Public Const GWL_EXSTYLE As Integer = (-20)
        Public Const WS_EX_TOOLWINDOW As Integer = &H80
        Public Const WS_EX_APPWINDOW As Integer = &H40000

        Public Shared Function ProcessIsActiveWindow(ByVal ur_window_hdl As Integer) As Boolean
            Dim stbWINDOW_TEXT As New System.Text.StringBuilder(255)
            Call GetWindowText(ur_window_hdl, stbWINDOW_TEXT, 255)
            Dim bolWINDOW_IS_OWNED = GetWindow(ur_window_hdl, 4) <> 0
            Dim intWINDOW_STYLE_CODE = GetWindowLong(ur_window_hdl, GWL_EXSTYLE)

            If Not IsWindowVisible(ur_window_hdl) Then
                Return False
            End If

            If System.String.IsNullOrWhiteSpace(stbWINDOW_TEXT.ToString) Then
                Return False
            End If

            If Mx.WindowSearch.GetParent(ur_window_hdl) <> 0 Then
                Return False
            End If

            If (intWINDOW_STYLE_CODE And WS_EX_TOOLWINDOW) <> 0 And bolWINDOW_IS_OWNED = False Then
                Return False
            End If

            If (intWINDOW_STYLE_CODE And WS_EX_APPWINDOW) = 0 And bolWINDOW_IS_OWNED Then
                Return False
            End If

            Return True
        End Function
    End Class
End Namespace 'Mx