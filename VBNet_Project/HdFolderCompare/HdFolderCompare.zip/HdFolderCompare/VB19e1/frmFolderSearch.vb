﻿Imports System
Imports System.Windows.Forms

Public Class frmFolderSearch
    Dim sdaROOT As New System.Collections.Generic.Dictionary(Of String, String)

    Private Sub btnSearch_Click(sender As Object, e As System.EventArgs) Handles btnSearch.Click
        Call sdaROOT.Clear()
        Call Me.lstResult.Items.Clear()
        For Each strPATH In System.IO.Directory.EnumerateDirectories(System.IO.Path.GetDirectoryName(My.Application.Info.DirectoryPath), "*" & Me.txtSearch.Text & "*")
            Dim strFOLDER = System.IO.Path.GetFileName(strPATH)
            sdaROOT.Add(strFOLDER, strPATH)
            Me.lstResult.Items.Add(strFOLDER)
        Next strPATH

        If Me.lstResult.Items.Count > 0 Then
            Me.lstResult.SelectedIndex = 0
            Call txtResult_Enter()
            Me.ActiveControl = Me.btnShowFolder
        End If
    End Sub 'btnSearch_Click

    Private Sub lstResult_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles lstResult.SelectedIndexChanged
        If Me.lstResult.SelectedIndex >= 0 Then
            Me.txtResult.Text = sdaROOT.Item(Me.lstResult.SelectedItem.ToString)
        End If
    End Sub

    Private Sub txtResult_Enter(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing) Handles txtResult.Enter
        Dim strPATH = Me.txtResult.Text
        If String.IsNullOrWhiteSpace(strPATH) = False Then
            My.Computer.Clipboard.SetText(strPATH)
        End If
    End Sub

    Private Sub frmFolderSearch_Load(sender As Object, e As EventArgs) Handles Me.Load
        For Each curHDFolder In User_Selection.HDFolder_Selected
            Dim strROOT = curHDFolder.Path

            For Each objFORM In My.Application.OpenForms
                Dim frmENTRY = DirectCast(objFORM, Windows.Forms.Form)
                If frmENTRY.Name = "frmHdFolders" Then
                    Dim objFOLDER_FORM = DirectCast(frmENTRY, frmHdFolders)
                    If objFOLDER_FORM.lstFolder.SelectedIndex >= 0 Then
                        Me.txtResult.Text = strROOT
                        Call txtResult_Enter()
                    End If
                End If
            Next objFORM
        Next curHDFolder
    End Sub

    Private Sub lstResult_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstResult.KeyPress
        Dim intSELECTED = Me.lstResult.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim strFOLDER = Me.lstResult.SelectedItem.ToString
            For Each objFORM In My.Application.OpenForms
                Dim frmENTRY = DirectCast(objFORM, Windows.Forms.Form)
                If frmENTRY.Name = "frmHdFolders" Then
                    Dim objFOLDER_FORM = DirectCast(frmENTRY, frmHdFolders)
                    Call objFOLDER_FORM.btnAddTicket_Click(Nothing, Nothing, strFOLDER)
                    Call objFOLDER_FORM.lstFolder_KeyPress()
                End If 'frmENTRY
            Next objFORM
        End If 'e
    End Sub 'lstResult_KeyPress

    Private Sub lstResult_DoubleClick(sender As Object, e As EventArgs) Handles lstResult.DoubleClick
        Call lstResult_KeyPress(Nothing, Nothing)
    End Sub

    Private Sub btnShowFolder_Click(sender As Object, e As EventArgs) Handles btnShowFolder.Click
        Call lstResult_KeyPress(Nothing, Nothing)
        For Each objFORM In My.Application.OpenForms
            Dim frmENTRY = DirectCast(objFORM, Windows.Forms.Form)
            If frmENTRY.Name = "frmHdFolders" Then
                Dim objFOLDER_FORM = DirectCast(frmENTRY, frmHdFolders)
                Dim objFOLDER_LIST = objFOLDER_FORM.lstFolder
                If objFOLDER_LIST.SelectedIndex >= 0 Then
                    Call objFOLDER_FORM.btnShowFolder_Click(Nothing, Nothing)
                    Me.ActiveControl = Me.txtSearch
                    Me.Close()
                End If
            End If
        Next objFORM
    End Sub
End Class 'frmFolderSearch