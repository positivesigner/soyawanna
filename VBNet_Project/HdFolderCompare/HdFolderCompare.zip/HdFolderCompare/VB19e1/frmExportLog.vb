﻿Imports System
Imports System.Windows.Forms

Public Class frmExportLog
    Private Sub frmExportLog_Load(sender As Object, e As System.EventArgs) Handles MyBase.Load
        Dim sdaFOLDER_SORT = New Mx.Sdata
        For Each strFILE_PATH In System.IO.Directory.EnumerateFiles(Path_Parameters.Application_Folder, Path_Parameters.SQL_Export_Error_Search)
            sdaFOLDER_SORT.Add(System.IO.Path.GetFileName(strFILE_PATH))
        Next

        Call sdaFOLDER_SORT.Sort()
        Call sdaFOLDER_SORT.Reverse()

        Call Me.lstLogPath.Items.Clear()
        For Each strFILE_PATH In sdaFOLDER_SORT
            Me.lstLogPath.Items.Add(strFILE_PATH)
        Next
    End Sub

    Private Sub lstLogPath_DoubleClick(sender As Object, e As EventArgs) Handles lstLogPath.DoubleClick
        Call lstLogPath_KeyPress()
    End Sub

    Sub lstLogPath_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstLogPath.KeyPress
        Dim intSELECTED = Me.lstLogPath.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim strSEL_LOG = Me.lstLogPath.SelectedItem.ToString
            If System.IO.File.Exists(Path_Parameters.Notepad_PlusPlus) = False Then
                MsgBox("Cannot find path to run program: " & Path_Parameters.Notepad_PlusPlus)
            Else
                System.Diagnostics.Process.Start(Path_Parameters.Notepad_PlusPlus, """" & strSEL_LOG.Replace("""", """""") & """")
            End If

            System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location)
        End If
    End Sub
End Class