﻿Imports System
Imports System.Windows.Forms

Public Class frmFileSearch
    Private Sub frmFileSearch_Load(sender As Object, e As System.EventArgs) Handles MyBase.Load
        If Me.lstFileType.Items.Count = 0 Then
            Dim objAPP_SETTINGS = System.Configuration.ConfigurationManager.AppSettings
            For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
                Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
                Dim strENTRY = objAPP_SETTINGS.Item(KEYCTR)
                If Mid(strKEY, 1, Len("FILETYPE")).ToUpper = "FILETYPE" Then
                    For Each strFIELD In strENTRY.Split(","c)
                        Me.lstFileType.Items.Add(strFIELD)
                    Next strFIELD
                End If
            Next KEYCTR
        End If

        If Database.FolderCallback.Environment_Is_AppActivate Then
            Me.lstFileType.Visible = False
        End If
    End Sub 'frmFileSearch_Load

    Private Sub btnAddToExport_Click(sender As Object, e As EventArgs) Handles btnAddToExport.Click
        Call lstResult_KeyPress()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnSearch_Click(Optional sender As Object = Nothing, Optional e As System.EventArgs = Nothing) Handles btnSearch.Click
        Dim bolANY_RESULT = False
        Call Me.lstResult.Items.Clear()
        If Database.FolderCallback.Environment_Is_AppActivate Then
            Dim strNAMES_FILE = Me.txtFileName.Text & " Filename.sql"
            frmHdFolders.strvCOMPARE_FILE = strNAMES_FILE
            frmHdFolders.bolvLEAVE_FILE = True
            Call frmHostedProcDef.ShowDialog()
            For Each strFOUND_FILE In System.IO.Directory.GetFiles(Database.FolderCallback.DownloadsFolder, strNAMES_FILE)
                Using stmIN = New System.IO.StreamReader(strFOUND_FILE, Mx.gUTF8_FileEncoding())
                    While stmIN.EndOfStream = False
                        Dim strLINE = stmIN.ReadLine
                        Me.lstResult.Items.Add(strLINE)
                    End While
                End Using 'stmIN

                Call System.IO.File.Delete(strFOUND_FILE)
                bolANY_RESULT = True
            Next strFOUND_FILE

            Call AppActivate(Me.Text)

        Else 'Database.FolderCallback
            Using objCONN = Database.FolderCallback.Open_DBConnection
                Dim objSQL_EXEC = New System.Data.SqlClient.SqlCommand
                objSQL_EXEC.Connection = objCONN
                objSQL_EXEC.CommandText = "SQL_ValFormNameSp"
                objSQL_EXEC.CommandType = System.Data.CommandType.StoredProcedure
                objSQL_EXEC.CommandTimeout = 0
                Call prv.AddParm(objSQL_EXEC.Parameters, "ur_prefix", Me.txtFileName.Text)
                Dim strFILE_TYPE = Mx.ListBoxSearch.gCurEntry(Me.lstFileType)
                If strFILE_TYPE = Mx.mt Then
                    Me.lstFileType.Text = Mx.mt
                End If

                Call prv.AddParm(objSQL_EXEC.Parameters, "ur_filetype", strFILE_TYPE)
                Using objRESULT = objSQL_EXEC.ExecuteReader()
                    While objRESULT.Read
                        Me.lstResult.Items.Add(objRESULT.GetValue(0).ToString)
                        bolANY_RESULT = True
                    End While
                End Using 'objRESULT
            End Using 'objCONN
        End If 'Database.FolderCallback

        If bolANY_RESULT Then
            Call Me.lstResult.Select()
        End If
    End Sub 'btnSearch_Click

    Private Sub lstFileType_KeyPress(sender As Object, e As KeyPressEventArgs) Handles lstFileType.KeyPress
        If e.KeyChar = vbCr Then
            Call txtFileName_KeyPress()
        End If
    End Sub 'lstFileType_KeyPress

    Private Sub lstResult_DoubleClick(sender As Object, e As EventArgs) Handles lstResult.DoubleClick
        Call lstResult_KeyPress()
    End Sub 'lstResult_DoubleClick

    Private Sub lstResult_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstResult.KeyPress
        Dim intSELECTED = Me.lstResult.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim intEXPORT_OPTION = frmHdFolders.enmEXPORT_OPTION.one
            If Me.lstResult.SelectedItems.Count > 1 Then
                intEXPORT_OPTION = frmHdFolders.enmEXPORT_OPTION.none
            End If

            For Each strFILE As String In Me.lstResult.SelectedItems
                Call frmHdFolders.btnAddFile_Return(strFILE, intEXPORT_OPTION)
            Next strFILE

            If Me.lstResult.SelectedItems.Count > 1 Then
                Call frmHdFolders.btnAddFile_Return("", frmHdFolders.enmEXPORT_OPTION.multiple)
            End If

            Me.Close()
        End If 'e
    End Sub 'lstResult_KeyPress

    Private Class prv
        Public Shared Sub AddParm(ur_parm_list As System.Data.SqlClient.SqlParameterCollection, ur_parm_name As String, ur_parm_value As String)
            Dim objPARM = ur_parm_list.Add(ur_parm_name, System.Data.SqlDbType.NVarChar)
            objPARM.Direction = System.Data.ParameterDirection.Input
            objPARM.IsNullable = True
            objPARM.Value = ur_parm_value
        End Sub 'AddParm
    End Class 'prv

    Private Sub txtFileName_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles txtFileName.KeyPress
        Dim intSELECTED = Me.txtFileName.Text.Length
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED > 0 Then
            Call btnSearch_Click()
        End If
    End Sub 'txtFileName_KeyPress
End Class 'frmFileSearch