﻿Namespace Mx
    Public Class UserAction
        Public Shared Function Open_Main_Form_errhnd(ur_form As dbUserInput, ur_appconfig As dbConfigInput, ur_cur_assembly As System.Reflection.Assembly, ur_commandline_text As String, Optional ur_flag_msgbox As Boolean = True) As Strap
            Have.CurAssembly = ur_cur_assembly
            Have.CmdLineText = ur_commandline_text
            Have.objAPP_CONFIG = ur_appconfig

            Dim stpRET = Strapd() : Open_Main_Form_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim windows_envvar_env = Have.WindowsEnvVar
                Dim windowsfs_env = Have.WindowsFS
                Dim appconfig_cart = Have.AppConfigSettings
                Dim akv_settingval_bowlname = enmAKV.setting_value
                Dim devsettings_cart = Have.DevSettings
                Dim cap_settingval_bowlname = enmDNV.setting_value
                Dim userbowl_cart = Have.UserBowl
                Dim appfolder_bowlname = enmUN.app_folder
                Dim appname_bowlname = enmUN.app_name
                Dim helpfile_path_bowlname = enmUN.helpfile_path
                Dim devsettings_path_bowlname = enmUN.devsettings_path
                Dim updated_row_count = Assistant.Store_DevSettings_Path(windows_envvar_env, userbowl_cart, devsettings_path_bowlname)
                updated_row_count = Assistant.Store_HelpFile_Path(userbowl_cart, helpfile_path_bowlname, appfolder_bowlname, appname_bowlname)
                Dim found_row_count = Assistant.Load_DevSettings_Table(devsettings_cart, userbowl_cart, devsettings_path_bowlname)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Open_Main_Form_errhnd

        Public Shared Function Run_BeyondCompare_errhnd(ur_source_folder_path As String, ur_compare_folder_path As String, Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Run_BeyondCompare_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim appexternal_env = Have.AppExternal
                Dim windowsfs_env = Have.WindowsFS
                Dim windowsmsgbox_env = Have.WindowsMsgBox
                Dim devsettings_cart = Have.DevSettings
                Dim userbowl_cart = Have.UserBowl
                Dim bcomp_path_bowlname = enmDS.bcomp_path
                Dim opened_file_count = Assistant.Run_WindowsProgram(devsettings_cart, bcomp_path_bowlname, ur_source_folder_path, ur_compare_folder_path, userbowl_cart, appexternal_env, windowsfs_env, windowsmsgbox_env)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Run_BeyondCompare_errhnd

        Public Shared Function Run_DevSettings_errhnd(Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Run_DevSettings_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim appexternal_env = Have.AppExternal
                Dim windowsfs_env = Have.WindowsFS
                Dim windowsmsgbox_env = Have.WindowsMsgBox
                Dim userbowl_cart = Have.UserBowl
                Dim appfolder_path_bowlname = enmUN.app_folder
                Dim opened_file_count = Assistant.Run_LocalProgram(userbowl_cart, appfolder_path_bowlname, appexternal_env, windowsfs_env, windowsmsgbox_env)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Run_DevSettings_errhnd

        Public Shared Function Run_NotePadPlusPlus_errhnd(ur_file_path As String, Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Run_NotePadPlusPlus_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim appexternal_env = Have.AppExternal
                Dim windowsfs_env = Have.WindowsFS
                Dim windowsmsgbox_env = Have.WindowsMsgBox
                Dim devsettings_cart = Have.DevSettings
                Dim userbowl_cart = Have.UserBowl
                Dim npp_path_bowlname = enmDS.npp_path
                Dim opened_file_count = Assistant.Run_WindowsProgram(devsettings_cart, npp_path_bowlname, ur_file_path, mt, userbowl_cart, appexternal_env, windowsfs_env, windowsmsgbox_env)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Run_NotePadPlusPlus_errhnd


        Private Class prv
            Public Shared Sub Handle_MsgBox(ur_errlst As ErrListBase, ur_strap As Strap, ur_flag_msgbox As Boolean)
                If ur_errlst.Found Then
                    ur_strap.Clear().d(ur_errlst.ToString)
                End If

                If ur_flag_msgbox AndAlso
                  ur_strap.HasText Then
                    Call glbl.gMsgBox.GetResult(ur_strap, MsgBoxStyle.OkOnly, Have.UserBowl.Value(enmUN.app_name))
                End If
            End Sub 'Handle_MsgBox
        End Class 'prv
    End Class 'UserAction


    Public Class Assistant
        Public Shared Function Load_DevSettings_Table(ur_devsettings_cart As Have.sDevSettings, ur_userbowl_cart As Have.sUserBowl, ur_devsettings_path_bowlname As enmUN.zdevsettings_path) As Integer
            Dim strDEVSETTINGS_PATH = ur_userbowl_cart.Value(ur_devsettings_path_bowlname)
            Call ur_devsettings_cart.DelAll()
            Dim found_row_count = ur_devsettings_cart.PersistRead(strDEVSETTINGS_PATH).Count
            Load_DevSettings_Table = found_row_count
        End Function 'Load_DevSettings_Table

        Public Shared Function Store_DevSettings_Path(ur_windows_envvar_env As Have.glblEnvironment, ur_userbowl_cart As Have.sUserBowl, ur_devsettings_path_bowlname As enmUN.zdevsettings_path) As Integer
            Store_DevSettings_Path = 1
            Dim flnPERSIST = FileNamed().d(ur_windows_envvar_env.ExpandEnvironmentVariables("%APPDATA%")).d("DevCustomApp_settings").d("user.config.tsv")
            ur_userbowl_cart.SelKey(ur_devsettings_path_bowlname).Contents = flnPERSIST
        End Function ' Store_DevSettings_Path

        Public Shared Function Store_HelpFile_Path(ur_userbowl_cart As Have.sUserBowl, ur_helpfile_path_bowlname As enmUN.zhelpfile_path, ur_appfolder_bowlname As enmUN.zapp_folder, ur_appname_bowlname As enmUN.zapp_name) As Integer
            Store_HelpFile_Path = 1
            Dim flnAPP_FOLDER_PATH = FileNamed().d(ur_userbowl_cart.Value(ur_appfolder_bowlname))
            Dim flnHELP_FILE_PATH = flnAPP_FOLDER_PATH.gCopy.d(Strapd().d(ur_userbowl_cart.Value(ur_appname_bowlname)).dS("App.html"))
            ur_userbowl_cart.SelKey(ur_helpfile_path_bowlname).Contents = flnHELP_FILE_PATH
        End Function 'Store_HelpFile_Path

        Public Shared Function Run_WindowsProgram(ur_devsettings_cart As Have.sDevSettings, ur_program_exe_path As enmDS, ur_path_e1 As String, ur_path_e2 As String, ur_userbowl_cart As Have.sUserBowl, ur_appexternal_env As Have.glblAppExternal, ur_windowsfs_env As Have.glblWindowsFS, ur_windowsmsgbox_env As Have.glblWindowsMsgBox) As Integer
            Dim strPROGRAM_PATH = ur_devsettings_cart.Value(ur_program_exe_path)
            Dim intFOUND_FILE = 0
            For Each strPATH In ur_windowsfs_env.GetFiles(strPROGRAM_PATH)
                intFOUND_FILE += 1
                Dim stpPARMS = Strapd()
                If HasText(ur_path_e1) Then
                    stpPARMS.d(qs).d(ur_path_e1.Replace(qs, qs & qs)).d(qs)
                    If HasText(ur_path_e2) Then
                        stpPARMS.dS(qs).d(ur_path_e2.Replace(qs, qs & qs)).d(qs)
                    End If
                End If

                ur_appexternal_env.Start_Windows_Program(strPROGRAM_PATH, stpPARMS)
            Next strPATH

            If intFOUND_FILE = 0 Then
                ur_windowsmsgbox_env.GetResult(Strapd().d("Cannot find path to run program from DevSettings").dS(ur_program_exe_path.name).d(":").dS(strPROGRAM_PATH))
            End If

            Run_WindowsProgram = intFOUND_FILE
        End Function 'Run_WindowsProgram

        Public Shared Function Run_LocalProgram(ur_userbowl_cart As Have.sUserBowl, ur_appfolder_bowlname As enmUN.zapp_folder, ur_appexternal_env As Have.glblAppExternal, ur_windowsfs_env As Have.glblWindowsFS, ur_windowsmsgbox_env As Have.glblWindowsMsgBox) As Integer
            Dim flnAPP_FOLDER = FileNamed().d(ur_userbowl_cart.Value(ur_appfolder_bowlname))
            Dim flnDEVSETTINGS_EXE = flnAPP_FOLDER.gCopy.d("DevSettings.exe")
            Dim intFOUND_FILE = 0
            For Each strPATH In ur_windowsfs_env.GetFiles(flnDEVSETTINGS_EXE)
                intFOUND_FILE += 1
                ur_appexternal_env.Start_Windows_Program(strPATH, mt)
            Next strPATH

            If intFOUND_FILE = 0 Then
                ur_windowsmsgbox_env.GetResult("Cannot find path to run program: " & flnDEVSETTINGS_EXE.ToString)
            End If

            Run_LocalProgram = intFOUND_FILE
        End Function 'Run_LocalProgram
    End Class


    Partial Public Class Have
        Private Shared prv_envAppExternal As glblAppExternal
        Private Shared prv_envWindowsCboard As glblWindowsCboard
        Private Shared prv_envWindowsEnvVar As glblEnvironment
        Private Shared prv_envWindowsFS As glblWindowsFS
        Private Shared prv_envWindowsMsgBox As glblWindowsMsgBox
        Private Shared prv_tblAppConfigSettings As sAppConfigSettings
        Private Shared prv_tblDevSettings As sDevSettings
        Private Shared prv_tblUserBowl As sUserBowl

        <System.Diagnostics.DebuggerHidden()>
        Private Shared Sub Connect()
            If Have.prv_tblUserBowl Is Nothing Then
                Have.prv_tblAppConfigSettings = New sAppConfigSettings
                Have.prv_envAppExternal = New glblAppExternal
                Have.prv_envWindowsCboard = New glblWindowsCboard
                Have.prv_envWindowsEnvVar = New glblEnvironment
                Have.prv_envWindowsFS = New glblWindowsFS
                Have.prv_envWindowsMsgBox = New glblWindowsMsgBox
                Have.prv_tblDevSettings = New sDevSettings
                Have.prv_tblUserBowl = New sUserBowl
            End If
        End Sub 'Connect
    End Class 'Have

    Public Class enmAKV
        Inherits bitBASE
        Public Shared setting_name As zsetting_name = Mx.TRow(Of enmAKV).glbl.Trbase(Of zsetting_name).NewBitBase() : Public Class zsetting_name : Inherits enmAKV : End Class
        Public Shared setting_value As zsetting_value = Mx.TRow(Of enmAKV).glbl.Trbase(Of zsetting_value).NewBitBase() : Public Class zsetting_value : Inherits enmAKV : End Class
    End Class

    Public Class gConfigSettings
        Public Shared Function AppSettings() As dbConfigInput
            AppSettings = Have.objAPP_CONFIG
        End Function
    End Class 'gConfigSettings

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function AppConfigSettings() As sAppConfigSettings
            Call Have.Connect()
            AppConfigSettings = Have.prv_tblAppConfigSettings
        End Function

        Public Class rAppConfigSettings
            Inherits TRow(Of enmAKV)
            Public PK As enmAKV

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Me.PK = enmAKV.setting_name
            End Sub
        End Class

        Public Class sAppConfigSettings
            Inherits TablePKStr(Of enmAKV, rAppConfigSettings)

            Public Sub New()
                Call MyBase.New(1)
                Dim objAPP_SETTINGS = Have.objAPP_CONFIG
                For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
                    Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
                    Dim trwNEW_SETTING = Me.InsKey(strKEY)
                    trwNEW_SETTING.v(enmAKV.setting_value) = objAPP_SETTINGS.Item(strKEY)
                Next KEYCTR
            End Sub 'New
        End Class 'glblAppConfigSettings
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function AppExternal() As glblAppExternal
            Call Have.Connect()
            AppExternal = Have.prv_envAppExternal
        End Function

        Public Class glblAppExternal
            Public Sub Start_Windows_Program(ur_exec_path As String, ur_exec_param As String)
                Call Mx.glbl.gDiagnostics.Start_Windows_Program(ur_exec_path, ur_exec_param)
            End Sub
        End Class 'glblAppExternal
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsEnvVar() As glblEnvironment
            Call Have.Connect()
            WindowsEnvVar = Have.prv_envWindowsEnvVar
        End Function

        Public Class glblEnvironment
            Public Function ExpandEnvironmentVariables(ur_path As String) As String
                ExpandEnvironmentVariables = Mx.glbl.gEnvironment.ExpandEnvironmentVariables(ur_path)
            End Function
        End Class 'glblEnvironment
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsCboardEnv() As glblWindowsCboard
            Call Have.Connect()
            WindowsCboardEnv = Have.prv_envWindowsCboard
        End Function

        Public Class glblWindowsCboard
            <System.Diagnostics.DebuggerHidden()>
            Public Function SetText(ur_text As String) As Integer
                SetText = Mx.glbl.gCboard.SetText(ur_text)
            End Function
        End Class 'glblWindowsCboard
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsFS() As glblWindowsFS
            Call Have.Connect()
            WindowsFS = Have.prv_envWindowsFS
        End Function

        Public Class glblWindowsFS
            <System.Diagnostics.DebuggerHidden()>
            Public Function GetFiles(ur_search_filespec As MxText.FileName, Optional ur_recurse_option As System.IO.SearchOption = System.IO.SearchOption.TopDirectoryOnly) As String()
                Try
                    GetFiles = Mx.glbl.gWindowsFS.GetFiles(ur_search_filespec.gParentDir, ur_search_filespec.Name, ur_recurse_option)
                Catch ex As System.Exception
                    GetFiles = {}
                End Try
            End Function
        End Class 'glblWindowsFS
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsMsgBox() As glblWindowsMsgBox
            Call Have.Connect()
            WindowsMsgBox = Have.prv_envWindowsMsgBox
        End Function

        Public Class glblWindowsMsgBox
            <System.Diagnostics.DebuggerHidden()>
            Public Function GetResult(ur_message As String, Optional ur_style As MsgBoxStyle = MsgBoxStyle.OkOnly) As MsgBoxResult
                Dim strAPP_NAME = Have.UserBowl.Value(enmUN.app_name)
                GetResult = Mx.glbl.gMsgBox.GetResult(ur_message, ur_style, strAPP_NAME)
            End Function
        End Class 'glblWindowsMsgBox
    End Class 'Have

    Public Class enmDNV
        Inherits bitBASE
        Public Shared setting_name As zsetting_name = Mx.TRow(Of enmDNV).glbl.Trbase(Of zsetting_name).NewBitBase() : Public Class zsetting_name : Inherits enmDNV : End Class
        Public Shared setting_value As zsetting_value = Mx.TRow(Of enmDNV).glbl.Trbase(Of zsetting_value).NewBitBase() : Public Class zsetting_value : Inherits enmDNV : End Class
    End Class

    Public Class enmDS
        Inherits bitBASE
        Public Shared npp_path As znpp_path = Mx.TRow(Of enmDS).glbl.Trbase(Of znpp_path).NewBitBase() : Public Class znpp_path : Inherits enmDS : End Class
        Public Shared bcomp_path As zbcomp_path = Mx.TRow(Of enmDS).glbl.Trbase(Of zbcomp_path).NewBitBase() : Public Class zbcomp_path : Inherits enmDS : End Class
    End Class

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function DevSettings() As sDevSettings
            Call Have.Connect()
            DevSettings = Have.prv_tblDevSettings
        End Function 'DevSettings

        Public Class rDevSettings
            Inherits TRow(Of enmDNV)
            Public PK As enmDNV

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Me.PK = enmDNV.setting_name
            End Sub
        End Class 'rDevSettings

        Public Class sDevSettings
            Inherits TablePKStr(Of enmDNV, rDevSettings)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Call MyBase.New(1)
            End Sub

            <System.Diagnostics.DebuggerHidden()>
            Public Function Value(ur_ds As enmDS) As String
                Value = mt
                For Each curROW In Me.SelOnKey(ur_ds.name).SelAll
                    Value = curROW.v(enmDNV.setting_value)
                    Exit For
                Next curROW
            End Function 'Value
        End Class 'sDevSettings
    End Class 'enmDS

    Public Class enmUB
        Inherits bitBASE
        Public Shared bowl_name As enmUB = TRow(Of enmUB).glbl.NewBitBase()
        Public Shared contents As enmUB = TRow(Of enmUB).glbl.NewBitBase()
    End Class

    Public Class enmUN
        Inherits bitBASE
        Public Shared app_folder As zapp_folder = Mx.TRow(Of enmUN).glbl.Trbase(Of zapp_folder).NewBitBase() : Public Class zapp_folder : Inherits enmUN : End Class
        Public Shared app_name As zapp_name = Mx.TRow(Of enmUN).glbl.Trbase(Of zapp_name).NewBitBase() : Public Class zapp_name : Inherits enmUN : End Class
        Public Shared app_path As zapp_path = Mx.TRow(Of enmUN).glbl.Trbase(Of zapp_path).NewBitBase() : Public Class zapp_path : Inherits enmUN : End Class
        Public Shared audit_parms_to_cboard As zaudit_parms_to_cboard = Mx.TRow(Of enmUN).glbl.Trbase(Of zaudit_parms_to_cboard).NewBitBase() : Public Class zaudit_parms_to_cboard : Inherits enmUN : End Class
        Public Shared cmdline_curexe As zcmdline_curexe = Mx.TRow(Of enmUN).glbl.Trbase(Of zcmdline_curexe).NewBitBase() : Public Class zcmdline_curexe : Inherits enmUN : End Class
        Public Shared cmdline_orig As zcmdline_orig = Mx.TRow(Of enmUN).glbl.Trbase(Of zcmdline_orig).NewBitBase() : Public Class zcmdline_orig : Inherits enmUN : End Class
        Public Shared cmdline_table As zcmdline_table = Mx.TRow(Of enmUN).glbl.Trbase(Of zcmdline_table).NewBitBase() : Public Class zcmdline_table : Inherits enmUN : End Class
        Public Shared compiler_exe As zcompiler_exe = Mx.TRow(Of enmUN).glbl.Trbase(Of zcompiler_exe).NewBitBase() : Public Class zcompiler_exe : Inherits enmUN : End Class
        Public Shared devsettings_path As zdevsettings_path = TRow(Of enmUN).glbl.Trbase(Of zdevsettings_path).NewBitBase() : Public Class zdevsettings_path : Inherits enmUN : End Class
        Public Shared path_unassigned As zpath_unassigned = Mx.TRow(Of enmUN).glbl.Trbase(Of zpath_unassigned).NewBitBase() : Public Class zpath_unassigned : Inherits enmUN : End Class
        Public Shared helpfile_path As zhelpfile_path = TRow(Of enmUN).glbl.Trbase(Of zhelpfile_path).NewBitBase() : Public Class zhelpfile_path : Inherits enmUN : End Class
    End Class 'enmUN

    Partial Public Class Have
        Public Shared objAPP_CONFIG As dbConfigInput
        Public Shared FirstConnect As Object
        Public Shared CmdLineText As String
        Public Shared CurAssembly As System.Reflection.Assembly
        Public Shared CurExe As String

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function UserBowl() As sUserBowl
            Dim bolFIRST_INIT = (Have.FirstConnect Is Nothing)
            Call Have.Connect()
            UserBowl = Have.prv_tblUserBowl
            If bolFIRST_INIT Then
                Have.FirstConnect = "Done"
                Dim apppath_bowlname = enmUN.app_path
                Dim appname_bowlname = enmUN.app_name
                Dim appfolder_bowlname = enmUN.app_folder
                Dim curexe_bowlname = enmUN.cmdline_curexe
                Dim cmdline_orig_bowlname = enmUN.cmdline_orig
                Dim cmdline_table_bowlname = enmUN.cmdline_table
                Dim cmdexport_audit_bowlname = enmUN.audit_parms_to_cboard
                Dim compiler_exe_bowlname = enmUN.compiler_exe
                Dim path_unassigned_bowlname = enmUN.path_unassigned

                Call Have.prv_tblUserBowl.UpdFrom_Application(Have.CurAssembly, Have.CurExe, apppath_bowlname, appname_bowlname, appfolder_bowlname, curexe_bowlname)
                Call Have.prv_tblUserBowl.UpdFrom_CommandLine(Have.CmdLineText, compiler_exe_bowlname, path_unassigned_bowlname, cmdline_orig_bowlname, cmdline_table_bowlname)
                'Have.prv_tblUserBowl.SelKey(cmdexport_audit_bowlname).Contents = "1"
                Call Have.prv_tblUserBowl.UpdCboard_FromAudit(cmdexport_audit_bowlname)
            End If
        End Function 'UserBowl

        Public Class rUserBowl
            Inherits TRow(Of enmUB)
            Public PK As enmUB

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Me.PK = enmUB.bowl_name
            End Sub

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmUB, ur_val As String) As rUserBowl
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Property Contents() As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Contents = Me.v(enmUB.contents)
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(ur_val As String)
                    Me.v(enmUB.contents) = ur_val
                End Set
            End Property
        End Class 'rUserBowl

        Public Class sUserBowl
            Inherits TablePKEnum(Of enmUB, enmUN, rUserBowl)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub UpdCboard_FromAudit(cmdexport_audit_bowlname As enmUN.zaudit_parms_to_cboard)
                If Mx.HasText(Me.SelKey(cmdexport_audit_bowlname).v(enmUB.contents)) Then
                    Dim strAUDIT = Me.ToString(True)
                    Dim ins_msg = Have.WindowsMsgBox.GetResult(
                        ur_message:=Me.SelKey(enmUN.app_name).v(enmUB.contents),
                        ur_style:=MsgBoxStyle.OkCancel
                        )
                    If ins_msg = MsgBoxResult.Ok Then
                        Have.WindowsCboardEnv.SetText(
                            strAUDIT
                            )
                    End If
                End If
            End Sub 'UpdCboard_FromAudit

            <System.Diagnostics.DebuggerHidden()>
            Public Function UpdFrom_Application(ur_cur_assembly As System.Reflection.Assembly, ur_curdir As String, ur_apppath_bowlname As enmUN.zapp_path, ur_appname_bowlname As enmUN.zapp_name, ur_appfolder_bowlname As enmUN.zapp_folder, ur_curexe_bowlname As enmUN.zcmdline_curexe) As sUserBowl
                UpdFrom_Application = Me
                Dim strCUR_EXE_PATH = ur_cur_assembly.Location
                If Mx.HasText(strCUR_EXE_PATH) = False Then
                    strCUR_EXE_PATH = ur_curdir
                End If

                Dim flnAPP_PATH = Mx.FileNamed().d(strCUR_EXE_PATH.Replace("\bin\Debug", Mx.mt))
                Me.SelKey(ur_apppath_bowlname).Contents = flnAPP_PATH
                Me.SelKey(ur_appname_bowlname).Contents = flnAPP_PATH.FileGroup
                Me.SelKey(ur_appfolder_bowlname).Contents = flnAPP_PATH.ParentDir
                Me.SelKey(ur_curexe_bowlname).Contents = strCUR_EXE_PATH
            End Function 'UpdFrom_Application

            <System.Diagnostics.DebuggerHidden()>
            Public Function UpdFrom_CommandLine(ur_cmdline_text As String, ur_compiler_exe_bowlname As enmUN.zcompiler_exe, ur_path_unassigned_bowlname As enmUN.zpath_unassigned, ur_cmdline_orig_bowlname As enmUN.zcmdline_orig, ur_cmdline_table_bowlname As enmUN.zcmdline_table) As sUserBowl
                UpdFrom_CommandLine = Me
                Dim arlCMD_RET = Mx.MxText.Cmdline_UB(Of enmUN, enmUB).CommandLine_UBParm(enmUB.bowl_name, enmUB.contents, ur_cmdline_text, ur_compiler_exe_bowlname, ur_path_unassigned_bowlname)
                Me.SelKey(ur_cmdline_orig_bowlname).Contents = Mx.qs & ur_cmdline_text.Replace(Mx.qs, Mx.qs & Mx.qs) & Mx.qs
                Me.SelKey(ur_cmdline_table_bowlname).Contents = Mx.qs & arlCMD_RET.ttbCMD_PARM.ToString(True).Replace(Mx.qs, Mx.qs & Mx.qs) & Mx.qs
                For Each trwPARM In arlCMD_RET.ttbUB_PARM
                    For Each trwBOWL In Me.Sel(enmUB.bowl_name, trwPARM.v(enmUB.bowl_name)).SelAll
                        If Mx.HasText(trwBOWL.Contents) = False Then
                            trwBOWL.Contents = trwPARM.v(enmUB.contents)
                        End If
                    Next trwBOWL
                Next trwPARM
            End Function 'UpdFrom_CommandLine

            <System.Diagnostics.DebuggerHidden()>
            Public Function Value(ur_ds As enmUN) As String
                Value = mt
                For Each curROW In Me.Sel(Me.PK, ur_ds.name).SelAll
                    Value = curROW.v(enmUB.contents)
                    Exit For
                Next curROW
            End Function 'Value

            <System.Diagnostics.DebuggerHidden()>
            Public Function ToCboard(ur_hdr As Boolean) As Integer
                ToCboard = Mx.glbl.gCboard.SetText(Me.ToString(ur_hdr))
            End Function
        End Class 'sUserBowl
    End Class 'UB, UN







    Public Class ListBoxSearch
        Public Shared Function IndexOf_c(ur_listbox As System.Windows.Forms.ListBox, ur_text As String) As Integer
            IndexOf_c = -1
            For ENTCTR = 0 To ur_listbox.Items.Count - 1
                If String.Equals(ur_listbox.Items.Item(ENTCTR), ur_text, System.StringComparison.CurrentCultureIgnoreCase) Then
                    IndexOf_c = ENTCTR
                    Exit For
                End If
            Next ENTCTR
        End Function 'ListBoxIndexOf_c

        Public Shared Function gCurEntry(ur_cbo_box As System.Windows.Forms.ComboBox) As String
            gCurEntry = mt
            Dim strSRCH_TEXT = ur_cbo_box.Text
            For ENTCTR = 0 To ur_cbo_box.Items.Count - 1
                If String.Equals(ur_cbo_box.Items.Item(ENTCTR), strSRCH_TEXT, System.StringComparison.CurrentCultureIgnoreCase) Then
                    gCurEntry = ur_cbo_box.Items.Item(ENTCTR)
                    Exit For
                End If
            Next ENTCTR
        End Function 'gCurEntry
    End Class

    Public Class WindowSearch
        Public Sub Example_Exec_ListAdd()
            Mx.WindowSearch.EnumWindowsDllImport(New Mx.WindowSearch.EnumWindowsCallback(AddressOf Example_FillActiveWindowsList_InListBox), 0)
        End Sub

        Public Function Example_FillActiveWindowsList_InListBox(ByVal hWnd As Integer, ByVal lParam As Integer) As Boolean
            Example_FillActiveWindowsList_InListBox = True
            Dim stbFOUND_TITLE As New System.Text.StringBuilder(255)
            Mx.WindowSearch.GetWindowText(hWnd, stbFOUND_TITLE, 255)
            Dim bolIS_ACTIVE = Mx.WindowSearch.ProcessIsActiveWindow(hWnd)
            Dim strFOUND_TITLE = stbFOUND_TITLE.ToString
            Dim strFOLDER = strFOUND_TITLE
            Dim intFOLDER = InStr(strFOUND_TITLE.ToUpper, " - XYPLORER")
            If intFOLDER > 0 Then
                strFOLDER = Mid(strFOUND_TITLE, 1, intFOLDER - 1)
            End If

            Dim intHD_FOLDER = InStr(strFOLDER, " hd")
            'Dim bolEXISTS_IN_LIST = Me.lstFolder.Items.Contains(strFOLDER)
            If bolIS_ACTIVE AndAlso
              intFOLDER > 0 AndAlso
              intHD_FOLDER > 0 Then 'AndAlso
                'bolEXISTS_IN_LIST = False Then
                'Me.lstFolder.Items.Insert(0, strFOLDER)
            End If
        End Function 'Example_FillActiveWindowsList_InListBox


        Public Delegate Function EnumWindowsCallback _
          (
            ByVal hWnd As Integer,
            ByVal lParam As Integer
          ) As Boolean

        Public Declare Function EnumWindows Lib "user32.dll" Alias "EnumWindows" _
          (
            ByVal callback As EnumWindowsCallback,
            ByVal lParam As Integer
          ) As Integer

        <System.Runtime.InteropServices.DllImport(
            "user32.dll",
            EntryPoint:="EnumWindows", SetLastError:=True,
            CharSet:=System.Runtime.InteropServices.CharSet.Ansi,
            ExactSpelling:=True,
            CallingConvention:=System.Runtime.InteropServices.CallingConvention.StdCall
          )>
        Public Shared Function EnumWindowsDllImport _
          (
            ByVal callback As EnumWindowsCallback,
            ByVal lParam As Integer
          ) As Integer
        End Function

        Public Declare Sub GetWindowText Lib "user32.dll" Alias "GetWindowTextA" _
          (
            ByVal hWnd As Integer,
            ByVal lpString As System.Text.StringBuilder,
            ByVal nMaxCount As Integer
          )

        Public Declare Function GetWindowLong Lib "user32.dll" Alias "GetWindowLongA" _
          (
            ByVal hwnd As Integer,
            ByVal nIndex As Integer
          ) As Integer

        Public Declare Function GetWindow Lib "user32.dll" Alias "GetWindow" _
          (
            ByVal hwnd As Integer,
            ByVal wCmd As Integer
          ) As Integer

        Public Declare Function IsWindowVisible Lib "user32.dll" Alias "IsWindowVisible" _
          (
            ByVal hwnd As Integer
          ) As Boolean

        Public Declare Function GetParent Lib "user32.dll" Alias "GetParent" _
          (
            ByVal hwnd As Integer
          ) As Integer

        Public Const GWL_EXSTYLE As Integer = (-20)
        Public Const WS_EX_TOOLWINDOW As Integer = &H80
        Public Const WS_EX_APPWINDOW As Integer = &H40000

        Public Shared Function ProcessIsActiveWindow(ByVal ur_window_hdl As Integer) As Boolean
            Dim stbWINDOW_TEXT As New System.Text.StringBuilder(255)
            Call GetWindowText(ur_window_hdl, stbWINDOW_TEXT, 255)
            Dim bolWINDOW_IS_OWNED = GetWindow(ur_window_hdl, 4) <> 0
            Dim intWINDOW_STYLE_CODE = GetWindowLong(ur_window_hdl, GWL_EXSTYLE)

            If Not IsWindowVisible(ur_window_hdl) Then
                Return False
            End If

            If System.String.IsNullOrWhiteSpace(stbWINDOW_TEXT.ToString) Then
                Return False
            End If

            If Mx.WindowSearch.GetParent(ur_window_hdl) <> 0 Then
                Return False
            End If

            If (intWINDOW_STYLE_CODE And WS_EX_TOOLWINDOW) <> 0 And bolWINDOW_IS_OWNED = False Then
                Return False
            End If

            If (intWINDOW_STYLE_CODE And WS_EX_APPWINDOW) = 0 And bolWINDOW_IS_OWNED Then
                Return False
            End If

            Return True
        End Function
    End Class
End Namespace 'Mx