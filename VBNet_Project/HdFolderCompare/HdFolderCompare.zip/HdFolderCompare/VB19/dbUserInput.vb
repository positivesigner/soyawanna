﻿Namespace Mx
    Public Class dbConfigInput
        Private objAPPCONFIG As System.Collections.Specialized.NameValueCollection

        <System.Diagnostics.DebuggerHidden()>
        Public Sub New(ur_appconfig As System.Collections.Specialized.NameValueCollection)
            Me.objAPPCONFIG = ur_appconfig
        End Sub 'New

        Public ReadOnly Property Keys As componentKeysCollection
            <System.Diagnostics.DebuggerHidden()>
            Get
                Keys = Nothing
                If Me.objAPPCONFIG IsNot Nothing Then
                    Keys = New componentKeysCollection(Me.objAPPCONFIG.Keys)
                End If
            End Get
        End Property 'Keys

        Public ReadOnly Property Item(name As String) As String
            <System.Diagnostics.DebuggerHidden()>
            Get
                Item = Nothing
                If Me.objAPPCONFIG IsNot Nothing Then
                    Item = Me.objAPPCONFIG.Item(name)
                End If
            End Get
        End Property 'Item

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Widening Operator CType(b As System.Collections.Specialized.NameValueCollection) As Mx.dbConfigInput
            Return New Mx.dbConfigInput(b)
        End Operator

        Public Class componentKeysCollection
            Private objKEYS As System.Collections.Specialized.NameObjectCollectionBase.KeysCollection

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New(ur_component As System.Collections.Specialized.NameObjectCollectionBase.KeysCollection)
                Me.objKEYS = ur_component
            End Sub

            Public ReadOnly Property Count As Integer
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Count = Nothing
                    If Me.objKEYS IsNot Nothing Then
                        Count = Me.objKEYS.Count
                    End If
                End Get
            End Property 'Keys

            Public ReadOnly Property Item(index As Integer) As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Item = Nothing
                    If Me.objKEYS IsNot Nothing Then
                        Item = Me.objKEYS.Item(index)
                    End If
                End Get
            End Property 'Item
        End Class 'componentKeysCollection
    End Class 'dbConfigInput

    Public Class dbUserInput
        'Public Class ztxtNewVal
        '    Inherits componentTextBox
        '    <System.Diagnostics.DebuggerHidden()>
        '    Public Sub New(ur_component As System.Windows.Forms.TextBox)
        '        Call MyBase.New(ur_component)
        '    End Sub
        'End Class 'ztxtNewVal

        Private objINPUT_FORM As System.Windows.Forms.Form
        'Public btnSaveAllChanges As componentButton

        <System.Diagnostics.DebuggerHidden()>
        Public Sub New(ur_input_form As System.Windows.Forms.Form)
            Me.objINPUT_FORM = ur_input_form
            'Me.txtNewVal = New ztxtNewVal(ur_new_val)
        End Sub 'New

        Public Class componentButton
            Private objBUTTON As System.Windows.Forms.Button

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New(ur_component As System.Windows.Forms.Button)
                Me.objBUTTON = ur_component
            End Sub

            Public Property Enabled As Boolean
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Enabled = False
                    If Me.objBUTTON IsNot Nothing Then
                        Enabled = Me.objBUTTON.Enabled
                    End If
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(value As Boolean)
                    If Me.objBUTTON IsNot Nothing Then
                        Me.objBUTTON.Enabled = value
                    End If
                End Set
            End Property 'Enabled
        End Class 'componentButton

        Public Class componentTextBox
            Private objTEXT_BOX As System.Windows.Forms.TextBox

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New(ur_component As System.Windows.Forms.TextBox)
                Me.objTEXT_BOX = ur_component
            End Sub

            Public Property Enabled As Boolean
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Enabled = False
                    If Me.objTEXT_BOX IsNot Nothing Then
                        Enabled = Me.objTEXT_BOX.Enabled
                    End If
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(value As Boolean)
                    If Me.objTEXT_BOX IsNot Nothing Then
                        Me.objTEXT_BOX.Enabled = value
                    End If
                End Set
            End Property 'Enabled

            Public Property Text As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Text = mt
                    If Me.objTEXT_BOX IsNot Nothing Then
                        Text = Me.objTEXT_BOX.Text
                    End If
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(value As String)
                    If Me.objTEXT_BOX IsNot Nothing Then
                        Me.objTEXT_BOX.Text = value
                    End If
                End Set
            End Property 'Text
        End Class 'componentTextBox
    End Class 'dbUserInput
End Namespace 'Mx