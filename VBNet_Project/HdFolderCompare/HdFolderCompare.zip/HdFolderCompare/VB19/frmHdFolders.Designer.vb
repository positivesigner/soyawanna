﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHdFolders
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabFolder = New System.Windows.Forms.TabPage()
        Me.lstFolder = New System.Windows.Forms.ListBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnRenameWaiting = New System.Windows.Forms.Button()
        Me.chkSortByTicket = New System.Windows.Forms.CheckBox()
        Me.lblVerNum = New System.Windows.Forms.Label()
        Me.btnAddTicket = New System.Windows.Forms.Button()
        Me.btnRefresh_Folders = New System.Windows.Forms.Button()
        Me.btnFolderSearch = New System.Windows.Forms.Button()
        Me.tabEnv = New System.Windows.Forms.TabPage()
        Me.lstEnv = New System.Windows.Forms.ListBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnDup_File_Check_Env = New System.Windows.Forms.Button()
        Me.btnShowFolder2 = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.cboNewExport_Type = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboNew_Env = New System.Windows.Forms.ComboBox()
        Me.btnAddEnv = New System.Windows.Forms.Button()
        Me.tabCompare = New System.Windows.Forms.TabPage()
        Me.lstCompare = New System.Windows.Forms.ListBox()
        Me.tabFile = New System.Windows.Forms.TabPage()
        Me.pnlC_File = New System.Windows.Forms.Panel()
        Me.lstC_FILE = New System.Windows.Forms.ListBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnC_Export = New System.Windows.Forms.Button()
        Me.btnC_Folder = New System.Windows.Forms.Button()
        Me.btnCopyFileCompare = New System.Windows.Forms.Button()
        Me.btnAddFileCompare = New System.Windows.Forms.Button()
        Me.pnlE_File = New System.Windows.Forms.Panel()
        Me.lstE_FILE = New System.Windows.Forms.ListBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnE_Export = New System.Windows.Forms.Button()
        Me.btnE_Folder = New System.Windows.Forms.Button()
        Me.btnCopyFileFirst = New System.Windows.Forms.Button()
        Me.btnAddFileFirst = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnExportLogs = New System.Windows.Forms.Button()
        Me.btnTicket_Folder = New System.Windows.Forms.Button()
        Me.btnShowFolder = New System.Windows.Forms.Button()
        Me.btnRefresh_Files = New System.Windows.Forms.Button()
        Me.btnDupFile_Check = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCompare = New System.Windows.Forms.Button()
        Me.tabNotes = New System.Windows.Forms.TabPage()
        Me.lstNoteFile = New System.Windows.Forms.ListBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btnAddNote = New System.Windows.Forms.Button()
        Me.lstNoteType = New System.Windows.Forms.ComboBox()
        Me.lblNoteType = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btnDevSettings = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.tabFolder.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.tabEnv.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.tabCompare.SuspendLayout()
        Me.tabFile.SuspendLayout()
        Me.pnlC_File.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.pnlE_File.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.tabNotes.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabFolder)
        Me.TabControl1.Controls.Add(Me.tabEnv)
        Me.TabControl1.Controls.Add(Me.tabCompare)
        Me.TabControl1.Controls.Add(Me.tabFile)
        Me.TabControl1.Controls.Add(Me.tabNotes)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(771, 373)
        Me.TabControl1.TabIndex = 0
        '
        'tabFolder
        '
        Me.tabFolder.Controls.Add(Me.lstFolder)
        Me.tabFolder.Controls.Add(Me.Panel2)
        Me.tabFolder.Location = New System.Drawing.Point(4, 22)
        Me.tabFolder.Name = "tabFolder"
        Me.tabFolder.Padding = New System.Windows.Forms.Padding(3)
        Me.tabFolder.Size = New System.Drawing.Size(763, 347)
        Me.tabFolder.TabIndex = 0
        Me.tabFolder.Text = "HdFolders"
        Me.tabFolder.UseVisualStyleBackColor = True
        '
        'lstFolder
        '
        Me.lstFolder.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstFolder.FormattingEnabled = True
        Me.lstFolder.Location = New System.Drawing.Point(3, 63)
        Me.lstFolder.Name = "lstFolder"
        Me.lstFolder.Size = New System.Drawing.Size(757, 281)
        Me.lstFolder.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnDevSettings)
        Me.Panel2.Controls.Add(Me.btnRenameWaiting)
        Me.Panel2.Controls.Add(Me.chkSortByTicket)
        Me.Panel2.Controls.Add(Me.lblVerNum)
        Me.Panel2.Controls.Add(Me.btnAddTicket)
        Me.Panel2.Controls.Add(Me.btnRefresh_Folders)
        Me.Panel2.Controls.Add(Me.btnFolderSearch)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(757, 60)
        Me.Panel2.TabIndex = 1
        '
        'btnRenameWaiting
        '
        Me.btnRenameWaiting.Location = New System.Drawing.Point(307, 3)
        Me.btnRenameWaiting.Name = "btnRenameWaiting"
        Me.btnRenameWaiting.Size = New System.Drawing.Size(158, 23)
        Me.btnRenameWaiting.TabIndex = 8
        Me.btnRenameWaiting.Text = "Rename Waiting Folder"
        Me.btnRenameWaiting.UseVisualStyleBackColor = True
        '
        'chkSortByTicket
        '
        Me.chkSortByTicket.AutoSize = True
        Me.chkSortByTicket.Location = New System.Drawing.Point(493, 7)
        Me.chkSortByTicket.Name = "chkSortByTicket"
        Me.chkSortByTicket.Size = New System.Drawing.Size(92, 17)
        Me.chkSortByTicket.TabIndex = 7
        Me.chkSortByTicket.Text = "Sort by Ticket"
        Me.chkSortByTicket.UseVisualStyleBackColor = True
        '
        'lblVerNum
        '
        Me.lblVerNum.AutoSize = True
        Me.lblVerNum.Location = New System.Drawing.Point(611, 8)
        Me.lblVerNum.Name = "lblVerNum"
        Me.lblVerNum.Size = New System.Drawing.Size(39, 13)
        Me.lblVerNum.TabIndex = 6
        Me.lblVerNum.Text = "Label3"
        '
        'btnAddTicket
        '
        Me.btnAddTicket.Location = New System.Drawing.Point(114, 4)
        Me.btnAddTicket.Name = "btnAddTicket"
        Me.btnAddTicket.Size = New System.Drawing.Size(75, 23)
        Me.btnAddTicket.TabIndex = 3
        Me.btnAddTicket.Text = "&Add"
        Me.btnAddTicket.UseVisualStyleBackColor = True
        '
        'btnRefresh_Folders
        '
        Me.btnRefresh_Folders.Location = New System.Drawing.Point(23, 4)
        Me.btnRefresh_Folders.Name = "btnRefresh_Folders"
        Me.btnRefresh_Folders.Size = New System.Drawing.Size(75, 23)
        Me.btnRefresh_Folders.TabIndex = 2
        Me.btnRefresh_Folders.Text = "&Refresh"
        Me.btnRefresh_Folders.UseVisualStyleBackColor = True
        '
        'btnFolderSearch
        '
        Me.btnFolderSearch.Location = New System.Drawing.Point(213, 3)
        Me.btnFolderSearch.Name = "btnFolderSearch"
        Me.btnFolderSearch.Size = New System.Drawing.Size(75, 23)
        Me.btnFolderSearch.TabIndex = 4
        Me.btnFolderSearch.Text = "Search"
        Me.btnFolderSearch.UseVisualStyleBackColor = True
        Me.btnFolderSearch.Visible = False
        '
        'tabEnv
        '
        Me.tabEnv.Controls.Add(Me.lstEnv)
        Me.tabEnv.Controls.Add(Me.Panel3)
        Me.tabEnv.Location = New System.Drawing.Point(4, 22)
        Me.tabEnv.Name = "tabEnv"
        Me.tabEnv.Padding = New System.Windows.Forms.Padding(3)
        Me.tabEnv.Size = New System.Drawing.Size(763, 347)
        Me.tabEnv.TabIndex = 1
        Me.tabEnv.Text = "Environments"
        Me.tabEnv.UseVisualStyleBackColor = True
        '
        'lstEnv
        '
        Me.lstEnv.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstEnv.FormattingEnabled = True
        Me.lstEnv.Location = New System.Drawing.Point(3, 59)
        Me.lstEnv.Name = "lstEnv"
        Me.lstEnv.Size = New System.Drawing.Size(757, 285)
        Me.lstEnv.Sorted = True
        Me.lstEnv.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnDup_File_Check_Env)
        Me.Panel3.Controls.Add(Me.btnShowFolder2)
        Me.Panel3.Controls.Add(Me.btnRefresh)
        Me.Panel3.Controls.Add(Me.cboNewExport_Type)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.cboNew_Env)
        Me.Panel3.Controls.Add(Me.btnAddEnv)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(3, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(757, 56)
        Me.Panel3.TabIndex = 1
        '
        'btnDup_File_Check_Env
        '
        Me.btnDup_File_Check_Env.Location = New System.Drawing.Point(309, 3)
        Me.btnDup_File_Check_Env.Name = "btnDup_File_Check_Env"
        Me.btnDup_File_Check_Env.Size = New System.Drawing.Size(135, 23)
        Me.btnDup_File_Check_Env.TabIndex = 7
        Me.btnDup_File_Check_Env.Text = "&Duplicate File Check"
        Me.btnDup_File_Check_Env.UseVisualStyleBackColor = True
        '
        'btnShowFolder2
        '
        Me.btnShowFolder2.Location = New System.Drawing.Point(309, 29)
        Me.btnShowFolder2.Name = "btnShowFolder2"
        Me.btnShowFolder2.Size = New System.Drawing.Size(135, 23)
        Me.btnShowFolder2.TabIndex = 4
        Me.btnShowFolder2.Text = "&Show Ticket Folder"
        Me.btnShowFolder2.UseVisualStyleBackColor = True
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(175, 3)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(113, 23)
        Me.btnRefresh.TabIndex = 0
        Me.btnRefresh.Text = "&Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'cboNewExport_Type
        '
        Me.cboNewExport_Type.FormattingEnabled = True
        Me.cboNewExport_Type.Location = New System.Drawing.Point(76, 31)
        Me.cboNewExport_Type.Name = "cboNewExport_Type"
        Me.cboNewExport_Type.Size = New System.Drawing.Size(91, 21)
        Me.cboNewExport_Type.Sorted = True
        Me.cboNewExport_Type.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(5, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Export Type:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(1, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Environment:"
        '
        'cboNew_Env
        '
        Me.cboNew_Env.FormattingEnabled = True
        Me.cboNew_Env.Location = New System.Drawing.Point(76, 5)
        Me.cboNew_Env.Name = "cboNew_Env"
        Me.cboNew_Env.Size = New System.Drawing.Size(91, 21)
        Me.cboNew_Env.Sorted = True
        Me.cboNew_Env.TabIndex = 1
        '
        'btnAddEnv
        '
        Me.btnAddEnv.Location = New System.Drawing.Point(175, 29)
        Me.btnAddEnv.Name = "btnAddEnv"
        Me.btnAddEnv.Size = New System.Drawing.Size(115, 23)
        Me.btnAddEnv.TabIndex = 3
        Me.btnAddEnv.Text = "&Add Environment"
        Me.btnAddEnv.UseVisualStyleBackColor = True
        '
        'tabCompare
        '
        Me.tabCompare.Controls.Add(Me.lstCompare)
        Me.tabCompare.Location = New System.Drawing.Point(4, 22)
        Me.tabCompare.Name = "tabCompare"
        Me.tabCompare.Size = New System.Drawing.Size(763, 347)
        Me.tabCompare.TabIndex = 3
        Me.tabCompare.Text = "Compare"
        Me.tabCompare.UseVisualStyleBackColor = True
        '
        'lstCompare
        '
        Me.lstCompare.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstCompare.FormattingEnabled = True
        Me.lstCompare.Location = New System.Drawing.Point(0, 0)
        Me.lstCompare.Name = "lstCompare"
        Me.lstCompare.Size = New System.Drawing.Size(763, 347)
        Me.lstCompare.Sorted = True
        Me.lstCompare.TabIndex = 0
        '
        'tabFile
        '
        Me.tabFile.Controls.Add(Me.pnlC_File)
        Me.tabFile.Controls.Add(Me.pnlE_File)
        Me.tabFile.Controls.Add(Me.Panel1)
        Me.tabFile.Location = New System.Drawing.Point(4, 22)
        Me.tabFile.Name = "tabFile"
        Me.tabFile.Size = New System.Drawing.Size(763, 347)
        Me.tabFile.TabIndex = 2
        Me.tabFile.Text = "Files"
        Me.tabFile.UseVisualStyleBackColor = True
        '
        'pnlC_File
        '
        Me.pnlC_File.Controls.Add(Me.lstC_FILE)
        Me.pnlC_File.Controls.Add(Me.Panel5)
        Me.pnlC_File.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlC_File.Location = New System.Drawing.Point(377, 61)
        Me.pnlC_File.Name = "pnlC_File"
        Me.pnlC_File.Size = New System.Drawing.Size(386, 286)
        Me.pnlC_File.TabIndex = 4
        '
        'lstC_FILE
        '
        Me.lstC_FILE.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstC_FILE.FormattingEnabled = True
        Me.lstC_FILE.Location = New System.Drawing.Point(0, 60)
        Me.lstC_FILE.Name = "lstC_FILE"
        Me.lstC_FILE.Size = New System.Drawing.Size(386, 226)
        Me.lstC_FILE.Sorted = True
        Me.lstC_FILE.TabIndex = 2
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btnC_Export)
        Me.Panel5.Controls.Add(Me.btnC_Folder)
        Me.Panel5.Controls.Add(Me.btnCopyFileCompare)
        Me.Panel5.Controls.Add(Me.btnAddFileCompare)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(386, 60)
        Me.Panel5.TabIndex = 14
        '
        'btnC_Export
        '
        Me.btnC_Export.Location = New System.Drawing.Point(6, 3)
        Me.btnC_Export.Name = "btnC_Export"
        Me.btnC_Export.Size = New System.Drawing.Size(138, 23)
        Me.btnC_Export.TabIndex = 2
        Me.btnC_Export.Text = "Export &Compare"
        Me.btnC_Export.UseVisualStyleBackColor = True
        '
        'btnC_Folder
        '
        Me.btnC_Folder.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnC_Folder.Location = New System.Drawing.Point(150, 3)
        Me.btnC_Folder.Name = "btnC_Folder"
        Me.btnC_Folder.Size = New System.Drawing.Size(182, 23)
        Me.btnC_Folder.TabIndex = 13
        Me.btnC_Folder.Text = "Compare Folder"
        Me.btnC_Folder.UseVisualStyleBackColor = False
        '
        'btnCopyFileCompare
        '
        Me.btnCopyFileCompare.Location = New System.Drawing.Point(150, 28)
        Me.btnCopyFileCompare.Name = "btnCopyFileCompare"
        Me.btnCopyFileCompare.Size = New System.Drawing.Size(182, 23)
        Me.btnCopyFileCompare.TabIndex = 12
        Me.btnCopyFileCompare.Text = "Copy File to First"
        Me.btnCopyFileCompare.UseVisualStyleBackColor = True
        '
        'btnAddFileCompare
        '
        Me.btnAddFileCompare.Location = New System.Drawing.Point(6, 28)
        Me.btnAddFileCompare.Name = "btnAddFileCompare"
        Me.btnAddFileCompare.Size = New System.Drawing.Size(138, 23)
        Me.btnAddFileCompare.TabIndex = 11
        Me.btnAddFileCompare.Text = "Add &File to Compare"
        Me.btnAddFileCompare.UseVisualStyleBackColor = True
        '
        'pnlE_File
        '
        Me.pnlE_File.Controls.Add(Me.lstE_FILE)
        Me.pnlE_File.Controls.Add(Me.Panel6)
        Me.pnlE_File.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlE_File.Location = New System.Drawing.Point(0, 61)
        Me.pnlE_File.Name = "pnlE_File"
        Me.pnlE_File.Size = New System.Drawing.Size(377, 286)
        Me.pnlE_File.TabIndex = 3
        '
        'lstE_FILE
        '
        Me.lstE_FILE.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstE_FILE.FormattingEnabled = True
        Me.lstE_FILE.Location = New System.Drawing.Point(0, 60)
        Me.lstE_FILE.Name = "lstE_FILE"
        Me.lstE_FILE.Size = New System.Drawing.Size(377, 226)
        Me.lstE_FILE.Sorted = True
        Me.lstE_FILE.TabIndex = 0
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.btnE_Export)
        Me.Panel6.Controls.Add(Me.btnE_Folder)
        Me.Panel6.Controls.Add(Me.btnCopyFileFirst)
        Me.Panel6.Controls.Add(Me.btnAddFileFirst)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(377, 60)
        Me.Panel6.TabIndex = 12
        '
        'btnE_Export
        '
        Me.btnE_Export.Location = New System.Drawing.Point(4, 3)
        Me.btnE_Export.Name = "btnE_Export"
        Me.btnE_Export.Size = New System.Drawing.Size(138, 23)
        Me.btnE_Export.TabIndex = 1
        Me.btnE_Export.Text = "&Export First"
        Me.btnE_Export.UseVisualStyleBackColor = True
        '
        'btnE_Folder
        '
        Me.btnE_Folder.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnE_Folder.Location = New System.Drawing.Point(148, 3)
        Me.btnE_Folder.Name = "btnE_Folder"
        Me.btnE_Folder.Size = New System.Drawing.Size(182, 23)
        Me.btnE_Folder.TabIndex = 11
        Me.btnE_Folder.Text = "Environment Folder"
        Me.btnE_Folder.UseVisualStyleBackColor = False
        '
        'btnCopyFileFirst
        '
        Me.btnCopyFileFirst.Location = New System.Drawing.Point(148, 27)
        Me.btnCopyFileFirst.Name = "btnCopyFileFirst"
        Me.btnCopyFileFirst.Size = New System.Drawing.Size(182, 23)
        Me.btnCopyFileFirst.TabIndex = 10
        Me.btnCopyFileFirst.Text = "Copy File to Compare"
        Me.btnCopyFileFirst.UseVisualStyleBackColor = True
        '
        'btnAddFileFirst
        '
        Me.btnAddFileFirst.Location = New System.Drawing.Point(4, 27)
        Me.btnAddFileFirst.Name = "btnAddFileFirst"
        Me.btnAddFileFirst.Size = New System.Drawing.Size(138, 23)
        Me.btnAddFileFirst.TabIndex = 9
        Me.btnAddFileFirst.Text = "&Add File to First"
        Me.btnAddFileFirst.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnExportLogs)
        Me.Panel1.Controls.Add(Me.btnTicket_Folder)
        Me.Panel1.Controls.Add(Me.btnShowFolder)
        Me.Panel1.Controls.Add(Me.btnRefresh_Files)
        Me.Panel1.Controls.Add(Me.btnDupFile_Check)
        Me.Panel1.Controls.Add(Me.btnClear)
        Me.Panel1.Controls.Add(Me.btnCompare)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(763, 61)
        Me.Panel1.TabIndex = 1
        '
        'btnExportLogs
        '
        Me.btnExportLogs.Location = New System.Drawing.Point(419, 29)
        Me.btnExportLogs.Name = "btnExportLogs"
        Me.btnExportLogs.Size = New System.Drawing.Size(102, 23)
        Me.btnExportLogs.TabIndex = 15
        Me.btnExportLogs.Text = "Export Lo&gs"
        Me.btnExportLogs.UseVisualStyleBackColor = True
        '
        'btnTicket_Folder
        '
        Me.btnTicket_Folder.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnTicket_Folder.Location = New System.Drawing.Point(253, 3)
        Me.btnTicket_Folder.Name = "btnTicket_Folder"
        Me.btnTicket_Folder.Size = New System.Drawing.Size(325, 23)
        Me.btnTicket_Folder.TabIndex = 14
        Me.btnTicket_Folder.Text = "Ticket Folder"
        Me.btnTicket_Folder.UseVisualStyleBackColor = False
        '
        'btnShowFolder
        '
        Me.btnShowFolder.Location = New System.Drawing.Point(100, 3)
        Me.btnShowFolder.Name = "btnShowFolder"
        Me.btnShowFolder.Size = New System.Drawing.Size(114, 23)
        Me.btnShowFolder.TabIndex = 13
        Me.btnShowFolder.Text = "&Show Ticket Folder"
        Me.btnShowFolder.UseVisualStyleBackColor = True
        '
        'btnRefresh_Files
        '
        Me.btnRefresh_Files.Location = New System.Drawing.Point(253, 29)
        Me.btnRefresh_Files.Name = "btnRefresh_Files"
        Me.btnRefresh_Files.Size = New System.Drawing.Size(114, 23)
        Me.btnRefresh_Files.TabIndex = 8
        Me.btnRefresh_Files.TabStop = False
        Me.btnRefresh_Files.Text = "&Refresh File Lists"
        Me.btnRefresh_Files.UseVisualStyleBackColor = True
        '
        'btnDupFile_Check
        '
        Me.btnDupFile_Check.Location = New System.Drawing.Point(100, 29)
        Me.btnDupFile_Check.Name = "btnDupFile_Check"
        Me.btnDupFile_Check.Size = New System.Drawing.Size(114, 23)
        Me.btnDupFile_Check.TabIndex = 6
        Me.btnDupFile_Check.Text = "&Duplicate File Check"
        Me.btnDupFile_Check.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(3, 29)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "C&lear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCompare
        '
        Me.btnCompare.Location = New System.Drawing.Point(3, 3)
        Me.btnCompare.Name = "btnCompare"
        Me.btnCompare.Size = New System.Drawing.Size(75, 23)
        Me.btnCompare.TabIndex = 0
        Me.btnCompare.Text = "Co&mpare"
        Me.btnCompare.UseVisualStyleBackColor = True
        '
        'tabNotes
        '
        Me.tabNotes.Controls.Add(Me.lstNoteFile)
        Me.tabNotes.Controls.Add(Me.Panel4)
        Me.tabNotes.Location = New System.Drawing.Point(4, 22)
        Me.tabNotes.Name = "tabNotes"
        Me.tabNotes.Padding = New System.Windows.Forms.Padding(3)
        Me.tabNotes.Size = New System.Drawing.Size(763, 347)
        Me.tabNotes.TabIndex = 4
        Me.tabNotes.Text = "Notes"
        Me.tabNotes.UseVisualStyleBackColor = True
        '
        'lstNoteFile
        '
        Me.lstNoteFile.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstNoteFile.FormattingEnabled = True
        Me.lstNoteFile.Location = New System.Drawing.Point(3, 103)
        Me.lstNoteFile.Name = "lstNoteFile"
        Me.lstNoteFile.Size = New System.Drawing.Size(757, 241)
        Me.lstNoteFile.TabIndex = 1
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.btnAddNote)
        Me.Panel4.Controls.Add(Me.lstNoteType)
        Me.Panel4.Controls.Add(Me.lblNoteType)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(3, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(757, 100)
        Me.Panel4.TabIndex = 0
        '
        'btnAddNote
        '
        Me.btnAddNote.Location = New System.Drawing.Point(225, 6)
        Me.btnAddNote.Name = "btnAddNote"
        Me.btnAddNote.Size = New System.Drawing.Size(75, 23)
        Me.btnAddNote.TabIndex = 2
        Me.btnAddNote.Text = "Add Note"
        Me.btnAddNote.UseVisualStyleBackColor = True
        '
        'lstNoteType
        '
        Me.lstNoteType.FormattingEnabled = True
        Me.lstNoteType.Location = New System.Drawing.Point(68, 6)
        Me.lstNoteType.Name = "lstNoteType"
        Me.lstNoteType.Size = New System.Drawing.Size(121, 21)
        Me.lstNoteType.TabIndex = 1
        '
        'lblNoteType
        '
        Me.lblNoteType.AutoSize = True
        Me.lblNoteType.Location = New System.Drawing.Point(5, 9)
        Me.lblNoteType.Name = "lblNoteType"
        Me.lblNoteType.Size = New System.Drawing.Size(57, 13)
        Me.lblNoteType.TabIndex = 0
        Me.lblNoteType.Text = "Note Type"
        '
        'Timer1
        '
        '
        'btnDevSettings
        '
        Me.btnDevSettings.Location = New System.Drawing.Point(487, 30)
        Me.btnDevSettings.Name = "btnDevSettings"
        Me.btnDevSettings.Size = New System.Drawing.Size(116, 23)
        Me.btnDevSettings.TabIndex = 9
        Me.btnDevSettings.Text = "Dev Settings"
        Me.btnDevSettings.UseVisualStyleBackColor = True
        '
        'frmHdFolders
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(771, 373)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frmHdFolders"
        Me.Text = "HdFolderCompare"
        Me.TabControl1.ResumeLayout(False)
        Me.tabFolder.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.tabEnv.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.tabCompare.ResumeLayout(False)
        Me.tabFile.ResumeLayout(False)
        Me.pnlC_File.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.pnlE_File.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.tabNotes.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabFolder As System.Windows.Forms.TabPage
    Friend WithEvents tabEnv As System.Windows.Forms.TabPage
    Friend WithEvents tabFile As System.Windows.Forms.TabPage
    Friend WithEvents lstFolder As System.Windows.Forms.ListBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents lstEnv As System.Windows.Forms.ListBox
    Friend WithEvents lstE_FILE As System.Windows.Forms.ListBox
    Friend WithEvents tabCompare As System.Windows.Forms.TabPage
    Friend WithEvents lstCompare As System.Windows.Forms.ListBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnC_Export As System.Windows.Forms.Button
    Friend WithEvents btnE_Export As System.Windows.Forms.Button
    Friend WithEvents btnCompare As System.Windows.Forms.Button
    Friend WithEvents lstC_FILE As System.Windows.Forms.ListBox
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnDupFile_Check As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnFolderSearch As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents cboNewExport_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboNew_Env As System.Windows.Forms.ComboBox
    Friend WithEvents btnAddEnv As System.Windows.Forms.Button
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnRefresh_Files As System.Windows.Forms.Button
    Friend WithEvents btnRefresh_Folders As System.Windows.Forms.Button
    Friend WithEvents btnAddFileFirst As System.Windows.Forms.Button
    Friend WithEvents btnCopyFileFirst As System.Windows.Forms.Button
    Friend WithEvents btnCopyFileCompare As System.Windows.Forms.Button
    Friend WithEvents btnAddFileCompare As System.Windows.Forms.Button
    Friend WithEvents btnAddTicket As System.Windows.Forms.Button
    Friend WithEvents btnShowFolder As System.Windows.Forms.Button
    Friend WithEvents tabNotes As System.Windows.Forms.TabPage
    Friend WithEvents lstNoteFile As System.Windows.Forms.ListBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents lstNoteType As System.Windows.Forms.ComboBox
    Friend WithEvents lblNoteType As System.Windows.Forms.Label
    Friend WithEvents btnAddNote As System.Windows.Forms.Button
    Friend WithEvents lblVerNum As System.Windows.Forms.Label
    Friend WithEvents chkSortByTicket As System.Windows.Forms.CheckBox
    Friend WithEvents btnRenameWaiting As System.Windows.Forms.Button
    Friend WithEvents pnlC_File As System.Windows.Forms.Panel
    Friend WithEvents pnlE_File As System.Windows.Forms.Panel
    Friend WithEvents btnE_Folder As System.Windows.Forms.Button
    Friend WithEvents btnC_Folder As System.Windows.Forms.Button
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents btnTicket_Folder As System.Windows.Forms.Button
    Friend WithEvents btnExportLogs As System.Windows.Forms.Button
    Friend WithEvents btnShowFolder2 As System.Windows.Forms.Button
    Friend WithEvents btnDup_File_Check_Env As System.Windows.Forms.Button
    Friend WithEvents btnDevSettings As System.Windows.Forms.Button
End Class
