﻿Imports System
Imports System.ComponentModel
Imports System.Windows.Forms

Public Class frmHdFolders
    Public psdaROOT As New System.Collections.Generic.Dictionary(Of String, String)
    Dim sdavDB_PARM As System.Collections.Generic.Dictionary(Of String, String)
    Dim sdavEXPORT_FOLDER As System.Collections.Generic.List(Of String)
    Dim sdavEXPORT_TYPE As System.Collections.Generic.List(Of String)
    Dim strvAPP_ROOT As String
    Dim strvFILE_SIDE As String
    Public objvCOMPARE_LIST As System.Windows.Forms.ListBox
    Public bolvLEAVE_FILE As Boolean
    Public strvSQL_PROC_DEF As String = "SqlProcDef_CollectionsNoQTA"
    Public strvHOSTING_APP As String = "CloudSuite Field Service"
    Public strvDB_PARM As String
    Public strvCOMPARE_FILE As String
    Public strvCURRENT_EXPORT_FOLDER As String
    Public strvCURRENT_COMPARE_FOLDER As String

    Private Sub frmHdFolders_Load(sender As Object, e As System.EventArgs) Handles MyBase.Load
        Call Mx.UserAction.Open_Main_Form_errhnd(Me, System.Configuration.ConfigurationManager.AppSettings, System.Reflection.Assembly.GetExecutingAssembly, System.Environment.CommandLine)
        Me.sdavEXPORT_FOLDER = New System.Collections.Generic.List(Of String)
        Me.sdavEXPORT_TYPE = New System.Collections.Generic.List(Of String)
        Me.sdavDB_PARM = New System.Collections.Generic.Dictionary(Of String, String)
        Me.strvAPP_ROOT = System.IO.Path.GetDirectoryName(My.Application.Info.DirectoryPath)
        If Mx.AreEqual(System.IO.Path.GetFileName(Me.strvAPP_ROOT), "bin") Then
            Me.strvAPP_ROOT = "C:\BitBucket\rnt_gotoassisttickets"
            System.IO.File.Copy(System.IO.Path.Combine(Me.strvAPP_ROOT, "SpProcDef\HdFolderCompare.exe.config"), System.IO.Path.Combine(My.Application.Info.DirectoryPath, "HdFolderCompare.exe.config"), True)
        End If

        Me.strvFILE_SIDE = "E"
        Me.lblVerNum.Text = "Version: " & My.Application.Info.Version.ToString

        Dim objAPP_SETTINGS = System.Configuration.ConfigurationManager.AppSettings
        For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
            Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
            Dim strENTRY = objAPP_SETTINGS.Item(KEYCTR)
            If Mid(strKEY, 1, Len("ENV")).ToUpper = "ENV" Then
                For Each strFIELD In strENTRY.Split(","c)
                    If Me.sdavEXPORT_FOLDER.Contains(strFIELD) = False Then
                        Me.sdavEXPORT_FOLDER.Add(strFIELD)
                        Me.cboNew_Env.Items.Add(strFIELD)
                    End If
                Next strFIELD
            End If 'strKEY

            If Mid(strKEY, 1, Len("SQLPROCDEF")).ToUpper = "SQLPROCDEF" Then
                Me.strvSQL_PROC_DEF = strENTRY
            End If

            If strKEY.ToUpper = "HOSTING_APP" Then
                Me.strvHOSTING_APP = strENTRY
            End If
        Next KEYCTR

        Call sdavEXPORT_TYPE.Clear()
        For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
            Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
            Dim strENTRY = objAPP_SETTINGS.Item(KEYCTR)
            If Mid(strKEY, 1, Len("EXPORT")).ToUpper = "EXPORT" AndAlso
              sdavEXPORT_TYPE.Contains(strENTRY) = False Then
                Call sdavEXPORT_TYPE.Add(strENTRY)
                Call Me.cboNewExport_Type.Items.Add(strENTRY)
            End If
        Next KEYCTR

        For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
            Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
            Dim strENTRY = objAPP_SETTINGS.Item(KEYCTR)
            If Mid(strKEY, 1, Len("NOTE")).ToUpper = "NOTE" Then
                For Each strFIELD In strENTRY.Split(","c)
                    If sdavEXPORT_TYPE.Contains(strFIELD) = False Then
                        sdavEXPORT_TYPE.Add(strFIELD)
                        Me.lstNoteType.Items.Add(strFIELD)
                    End If
                Next strFIELD
            End If 'strKEY
        Next KEYCTR

        For Each strFOLDER In Me.sdavEXPORT_FOLDER
            For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
                Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
                If strKEY.ToUpper = strFOLDER.ToUpper AndAlso
                  sdavDB_PARM.ContainsKey(strFOLDER) = False Then
                    Dim strENTRY = objAPP_SETTINGS.Item(KEYCTR)
                    sdavDB_PARM.Add(strFOLDER, strENTRY)
                End If
            Next KEYCTR
        Next strFOLDER

        Me.Exec_ListAdd()
        Me.lstFolder.Select()
        Me.Timer1.Interval = 2000
        Me.Timer1.Start()
        Me.chkSortByTicket.Checked = True

        For Each strFILE_PATH In System.IO.Directory.EnumerateFiles(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location), System.IO.Path.GetFileName(System.Reflection.Assembly.GetExecutingAssembly.Location) & ".session")
            Dim straLINE = System.IO.File.ReadAllLines(strFILE_PATH)
            Dim strPREV_FOLDER = ""
            Dim strPREV_ENV_1 = ""
            Dim strPREV_ENV_2 = ""
            For LINCTR = 0 To UBound(straLINE)
                Select Case LINCTR
                    Case 0
                        strPREV_FOLDER = straLINE(LINCTR)
                    Case 1
                        strPREV_ENV_1 = straLINE(LINCTR)
                    Case 2
                        strPREV_ENV_2 = straLINE(LINCTR)
                    Case Else
                        Exit For
                End Select
            Next LINCTR

            Dim intFOUND_INDEX = -1
            If strPREV_FOLDER <> "" Then
                intFOUND_INDEX = Mx.ListBoxSearch.IndexOf_c(Me.lstFolder, strPREV_FOLDER)
                If intFOUND_INDEX < 0 Then
                    strPREV_FOLDER = ""

                Else
                    Me.lstFolder.SelectedIndex = intFOUND_INDEX
                    Call lstFolder_KeyPress()
                End If
            End If

            If strPREV_FOLDER <> "" Then
                intFOUND_INDEX = Mx.ListBoxSearch.IndexOf_c(Me.lstEnv, strPREV_ENV_1)
                If intFOUND_INDEX < 0 Then
                    strPREV_FOLDER = ""

                Else
                    Me.lstEnv.SelectedIndex = intFOUND_INDEX
                    Call lstEnv_KeyPress()
                End If
            End If

            If strPREV_FOLDER <> "" Then
                intFOUND_INDEX = Mx.ListBoxSearch.IndexOf_c(Me.lstCompare, strPREV_ENV_2)
                If intFOUND_INDEX < 0 Then
                    strPREV_FOLDER = ""

                Else
                    Me.lstCompare.SelectedIndex = intFOUND_INDEX
                    Call lstCompare_KeyPress()
                End If
            End If
        Next strFILE_PATH
    End Sub 'frmHdFolders_Load

    Private Sub frmHdFolders_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim stpOUTPUT = Mx.Strapd()
        Dim intFOUND_INDEX = Me.lstFolder.SelectedIndex
        If intFOUND_INDEX >= 0 Then
            stpOUTPUT.d(Me.lstFolder.SelectedItem.ToString)
        End If

        If intFOUND_INDEX >= 0 Then
            intFOUND_INDEX = Me.lstEnv.SelectedIndex
        End If

        If intFOUND_INDEX >= 0 Then
            stpOUTPUT.dLine(Me.lstEnv.SelectedItem.ToString)
        End If

        If intFOUND_INDEX >= 0 Then
            intFOUND_INDEX = Me.lstCompare.SelectedIndex
        End If

        If intFOUND_INDEX >= 0 Then
            stpOUTPUT.dLine(Me.lstCompare.SelectedItem.ToString)
        End If

        If stpOUTPUT.HasText Then
            Dim strSESSION_PATH = System.Reflection.Assembly.GetExecutingAssembly.Location & ".session"
            System.IO.File.WriteAllText(strSESSION_PATH, stpOUTPUT, Mx.gUTF8_FileEncoding)
        End If
    End Sub 'frmHdFolders_Closing

    Private Sub btnAddEnv_Click(sender As Object, e As EventArgs) Handles btnAddEnv.Click
        Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
        Dim strNEW_ENV = Me.cboNew_Env.Text
        Dim strNEWEXPORT_TYPE = Me.cboNewExport_Type.Text
        Dim strNEW_PATH = System.IO.Path.Combine(strROOT, strNEW_ENV & " " & strNEWEXPORT_TYPE)
        Call System.IO.Directory.CreateDirectory(strNEW_PATH)
        Call lstFolder_KeyPress()
    End Sub 'btnAddEnv_Click

    Private Sub btnAddFileCompare_Click(sender As Object, e As EventArgs) Handles btnAddFileCompare.Click
        Me.strvFILE_SIDE = "C"
        Dim strBASE_FOLDER = Split(Me.lstCompare.SelectedItem.ToString, " ")(0)
        Me.strvDB_PARM = ""
        If Me.sdavDB_PARM.ContainsKey(strBASE_FOLDER) Then
            Me.strvDB_PARM = sdavDB_PARM.Item(strBASE_FOLDER)
        End If

        Call frmFileSearch.ShowDialog()
    End Sub

    Private Sub btnAddFileFirst_Click(sender As Object, e As EventArgs) Handles btnAddFileFirst.Click
        Me.strvFILE_SIDE = "E"
        Dim strBASE_FOLDER = Split(Me.lstEnv.SelectedItem.ToString, " ")(0)
        Me.strvDB_PARM = ""
        If Me.sdavDB_PARM.ContainsKey(strBASE_FOLDER) Then
            Me.strvDB_PARM = sdavDB_PARM.Item(strBASE_FOLDER)
        End If

        Call frmFileSearch.ShowDialog()
    End Sub

    Public Enum enmEXPORT_OPTION
        none
        one
        multiple
    End Enum

    Public Sub btnAddFile_Return(ur_file As String, Optional ur_export_option As enmEXPORT_OPTION = enmEXPORT_OPTION.one)
        If ur_export_option = enmEXPORT_OPTION.multiple Then
            If Me.strvFILE_SIDE = "C" Then
                Call btnC_Export_Click()
            Else
                Call btnE_Export_Click()
            End If

        Else 'ur_export_option
            Dim lstCOMP = Me.lstE_FILE
            Dim strCOMP_FOLDER = Me.lstEnv.SelectedItem.ToString
            If Me.strvFILE_SIDE = "C" Then
                lstCOMP = Me.lstC_FILE
                strCOMP_FOLDER = Me.lstCompare.SelectedItem.ToString
            End If

            Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
            Dim intCOMP_FOUND = Mx.ListBoxSearch.IndexOf_c(lstCOMP, ur_file)
            If ur_file <> "" AndAlso
              intCOMP_FOUND < 0 Then
                intCOMP_FOUND = lstCOMP.Items.Add(ur_file)
                Dim strFILE_PATH = System.IO.Path.Combine(strROOT, strCOMP_FOLDER & ur_file)
                Dim strPARENT_PATH = System.IO.Path.GetDirectoryName(strFILE_PATH)
                If System.IO.Directory.Exists(strPARENT_PATH) = False Then
                    Call System.IO.Directory.CreateDirectory(strPARENT_PATH)
                End If

                If System.IO.File.Exists(strFILE_PATH) = False Then
                    Call System.IO.File.WriteAllText(strFILE_PATH, "")
                End If
            End If 'ur_file

            If ur_file <> "" Then
                lstCOMP.SelectedIndex = intCOMP_FOUND
                If ur_export_option = enmEXPORT_OPTION.one Then
                    If Me.strvFILE_SIDE = "C" Then
                        Call lstC_FILE_KeyPress()
                    Else
                        Call lstE_FILE_KeyPress()
                    End If
                End If
            End If
        End If 'ur_export_option
    End Sub 'btnAddFile_Return

    Private Sub btnAddNote_Click(sender As Object, e As EventArgs) Handles btnAddNote.Click
        Dim strNEW_NOTE = Me.lstNoteType.Text
        If strNEW_NOTE <> "" Then
            strNEW_NOTE = "\NOTES\" & strNEW_NOTE & ".TXT"
            Dim intNOTE_FOUND = Mx.ListBoxSearch.IndexOf_c(Me.lstNoteFile, strNEW_NOTE)
            If intNOTE_FOUND < 0 Then
                Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
                Dim strNOTE_DIR = System.IO.Path.Combine(strROOT, "Notes")
                If System.IO.Directory.Exists(strNOTE_DIR) = False Then
                    Call System.IO.Directory.CreateDirectory(strNOTE_DIR)
                End If

                Dim strNOTE_PATH = strROOT & strNEW_NOTE
                If System.IO.File.Exists(strNOTE_PATH) = False Then
                    System.IO.File.WriteAllText(strNOTE_PATH, "")
                End If

                Me.lstNoteFile.Items.Add(strNEW_NOTE)
                intNOTE_FOUND = Mx.ListBoxSearch.IndexOf_c(Me.lstNoteFile, strNEW_NOTE)
            End If 'Me.lstNoteFile

            lstNoteFile.SelectedIndex = intNOTE_FOUND
            lstNoteFile_KeyPress()
        End If 'strNEW_NOTE
    End Sub 'btnAddNote_Click

    Public Sub btnAddTicket_Click(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing, Optional ur_ticket_folder As String = "") Handles btnAddTicket.Click
        Dim strTICKET = ""
        Dim intFOUND_INDEX = InStr(ur_ticket_folder, " hd")
        If intFOUND_INDEX > 0 Then
            strTICKET = Mid(ur_ticket_folder, intFOUND_INDEX + Len(" hd"))
        End If

        If strTICKET = "" Then
            strTICKET = InputBox("Please enter ticket number", "New Ticket Folder")
        End If

        If strTICKET <> "" Then
            Dim strNEW_FOLDER = ur_ticket_folder
            Dim bolENTRY_FOUND = False
            If ur_ticket_folder = "" Then
                strNEW_FOLDER = Today.ToString("yyyy") & "m" & Today.ToString("MM") & "d" & Today.ToString("dd") & " hd" & strTICKET
                For ENTCTR = 0 To Me.lstFolder.Items.Count - 1
                    Dim strCUR_ENTRY = Me.lstFolder.Items(ENTCTR).ToString().ToUpper
                    Dim intFOUND_SPRTR = InStrRev(strCUR_ENTRY, " hd")
                    If intFOUND_SPRTR >= 0 Then
                        strCUR_ENTRY = Mid(strCUR_ENTRY, intFOUND_SPRTR + Len(" hd"))
                    End If

                    If strCUR_ENTRY = strTICKET.ToUpper Then
                        Me.lstFolder.SelectedIndex = ENTCTR
                        bolENTRY_FOUND = True
                        Exit For
                    End If
                Next ENTCTR
            End If 'ur_ticket_folder

            If bolENTRY_FOUND = False Then
                Dim strNEW_PATH = System.IO.Path.Combine(strvAPP_ROOT, strNEW_FOLDER)
                If System.IO.Directory.Exists(strNEW_PATH) = False Then
                    Call System.IO.Directory.CreateDirectory(strNEW_PATH)
                End If

                Me.lstFolder.Items.Insert(0, strNEW_FOLDER)
                Me.lstFolder.SelectedIndex = 0
                Me.psdaROOT.Add(strNEW_FOLDER, strNEW_PATH)
            End If

            Me.ActiveControl = Me.lstFolder
            Call btnRefresh_Folders_Click()
        End If 'strTICKET
    End Sub 'btnAddTicket_Click

    Private Sub btnC_Export_Click(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing) Handles btnC_Export.Click
        Call FolderExport(Me.lstCompare.SelectedItem.ToString)
        Call Reable_All_Buttons(False)
    End Sub

    Private Sub btnC_Folder_Click(sender As Object, e As EventArgs) Handles btnC_Folder.Click
        Me.TabControl1.SelectedTab = Me.tabCompare
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
        For Each strFILE_PATH In System.IO.Directory.EnumerateFiles(strROOT & "\..\SpProcDef", "SqlProcDef*.vbscript.cmd*.err.txt")
            System.IO.File.Delete(strFILE_PATH)
        Next

        For Each strFOLDER_PATH In System.IO.Directory.EnumerateDirectories(strROOT)
            For Each strCOMPARE_NAME In Me.sdavEXPORT_FOLDER
                If System.IO.Path.GetFileName(strFOLDER_PATH).ToUpper = strCOMPARE_NAME.ToUpper Then
                    System.IO.Directory.Delete(strFOLDER_PATH, True)
                    Exit For
                End If
            Next strCOMPARE_NAME
        Next strFOLDER_PATH

        Call Reable_All_Buttons(False)
    End Sub 'btnClear_Click

    Private Sub btnCompare_Click(sender As Object, e As EventArgs) Handles btnCompare.Click
        Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
        Dim strE_PATH = ""
        If Me.lstEnv.SelectedIndex >= 0 Then
            strE_PATH = System.IO.Path.Combine(strROOT, Me.lstEnv.SelectedItem.ToString)
        End If

        Dim strC_PATH = ""
        If Me.lstCompare.SelectedIndex >= 0 Then
            strC_PATH = System.IO.Path.Combine(strROOT, Me.lstCompare.SelectedItem.ToString)
        End If

        Call Mx.UserAction.Run_BeyondCompare_errhnd(strE_PATH, strC_PATH)
        Call Reable_All_Buttons(False)
    End Sub 'btnCompare_Click

    Private Sub btnCopyFileCompare_Click(sender As Object, e As EventArgs) Handles btnCopyFileCompare.Click
        Call btnCopyFile_Return("C")
    End Sub

    Private Sub btnCopyFileFirst_Click(sender As Object, e As EventArgs) Handles btnCopyFileFirst.Click
        Call btnCopyFile_Return("E")
    End Sub

    Public Sub btnCopyFile_Return(ur_file_side As String)
        Dim lstSRC = Me.lstE_FILE
        Dim lstCOMP = Me.lstC_FILE
        Dim strCOMP_FOLDER = Me.lstCompare.SelectedItem.ToString
        If ur_file_side = "C" Then
            lstSRC = Me.lstC_FILE
            lstCOMP = Me.lstE_FILE
            strCOMP_FOLDER = Me.lstEnv.SelectedItem.ToString
        End If

        Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
        Dim strFILE = ""
        Dim intSELECTED = lstSRC.SelectedIndex
        If intSELECTED >= 0 Then
            strFILE = lstSRC.SelectedItem.ToString
        End If
        Dim intCOMP_FOUND = Mx.ListBoxSearch.IndexOf_c(lstCOMP, strFILE)
        If strFILE <> "" AndAlso
          intCOMP_FOUND < 0 Then
            intCOMP_FOUND = lstCOMP.Items.Add(strFILE)
            Dim strFILE_PATH = System.IO.Path.Combine(strROOT, strCOMP_FOLDER & strFILE)
            Dim strPARENT_PATH = System.IO.Path.GetDirectoryName(strFILE_PATH)
            If System.IO.Directory.Exists(strPARENT_PATH) = False Then
                Call System.IO.Directory.CreateDirectory(strPARENT_PATH)
            End If

            If System.IO.File.Exists(strFILE_PATH) = False Then
                Call System.IO.File.WriteAllText(strFILE_PATH, "")
            End If
        End If 'strFILE

        If strFILE <> "" Then
            lstCOMP.SelectedIndex = intCOMP_FOUND
            If ur_file_side = "C" Then
                Call lstE_FILE_KeyPress()
            Else
                Call lstC_FILE_KeyPress()
            End If
        End If
    End Sub 'btnCopyFile_Return

    Private Sub btnDevSettings_Click(sender As Object, e As EventArgs) Handles btnDevSettings.Click
        Call Mx.UserAction.Run_DevSettings_errhnd()
    End Sub

    Private Sub btnDupFile_Check_Click(sender As Object, e As EventArgs) Handles btnDupFile_Check.Click, btnDup_File_Check_Env.Click
        Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
        Dim strEXEC_PATH = strROOT & "\..\SpProcDef\DEV_UniqueFileCheck.cmd"
        If System.IO.File.Exists(strEXEC_PATH) = False Then
            MsgBox("Cannot find path to run program: " & strEXEC_PATH)
        Else
            System.Diagnostics.Process.Start(strEXEC_PATH)
        End If

        Call Reable_All_Buttons(False)
    End Sub 'btnDupFile_Check_Click

    Private Sub btnE_Export_Click(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing) Handles btnE_Export.Click
        Call FolderExport(Me.lstEnv.SelectedItem.ToString)
        Call Reable_All_Buttons(False)
    End Sub 'btnE_Export_Click

    Private Sub btnE_Folder_Click(sender As Object, e As EventArgs) Handles btnE_Folder.Click
        Me.TabControl1.SelectedTab = Me.tabEnv
    End Sub

    Private Sub btnExportLogs_Click(sender As Object, e As EventArgs) Handles btnExportLogs.Click
        Call frmExportLog.ShowDialog()
    End Sub

    Private Sub btnFolderSearch_Click(sender As Object, e As EventArgs) Handles btnFolderSearch.Click
        Call frmFolderSearch.ShowDialog()
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Call lstFolder_KeyPress()
    End Sub

    Private Sub btnRefresh_Files_Click(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing) Handles btnRefresh_Files.Click
        Call Reable_All_Buttons(False)
    End Sub

    Private Sub btnRefresh_Folders_Click(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing) Handles btnRefresh_Folders.Click
        Dim strcLIT_sp_hd = " hd"
        Dim strcLIT_star_dot_star = "*.*"
        Call Me.lstFolder.Items.Clear()
        Call Me.psdaROOT.Clear()
        Dim strROOT = Me.strvAPP_ROOT
        Dim sdaFOLDER_NAMES = New Mx.Sdata
        Dim sdaFOLDER_PATHS = New Mx.Sdata
        Dim sdaFOLDER_SORT = New Mx.Sdata
        For Each strPATH In System.IO.Directory.EnumerateDirectories(strROOT, strcLIT_star_dot_star, IO.SearchOption.TopDirectoryOnly)
            Dim intHD_FOLDER = InStr(strPATH, strcLIT_sp_hd)
            Dim strFOLDER = strPATH
            Dim strSORT = strFOLDER
            If intHD_FOLDER > 0 Then
                strFOLDER = System.IO.Path.GetFileName(strPATH)
                intHD_FOLDER = InStr(strFOLDER, strcLIT_sp_hd)
                strSORT = Mid(strFOLDER, intHD_FOLDER + strcLIT_sp_hd.Length)
            End If

            Dim intFOLDER_FOUND = Mx.ListBoxSearch.IndexOf_c(Me.lstFolder, strFOLDER)
            If intHD_FOLDER > 0 AndAlso
                  intFOLDER_FOUND < 0 Then
                sdaFOLDER_NAMES.d(strFOLDER)
                sdaFOLDER_PATHS.d(strPATH)
                If Me.chkSortByTicket.Checked = False Then
                    strSORT = strFOLDER
                End If

                sdaFOLDER_SORT.d(strSORT)
            End If 'intHD_FOLDER
        Next strPATH

        Call sdaFOLDER_SORT.Sort()
        For Each strSORT In sdaFOLDER_SORT
            For Each kvpNAME In sdaFOLDER_NAMES.kvp
                If Mx.EndingWithText(kvpNAME.v, strSORT) Then
                    If Me.lstFolder.Items.Contains(kvpNAME.v) Then
                        MsgBox(kvpNAME.v)
                    End If
                    Me.lstFolder.Items.Insert(0, kvpNAME.v)
                    Me.lstFolder.SelectedIndex = 0
                    Me.psdaROOT.Add(kvpNAME.v, sdaFOLDER_PATHS.v_b1(kvpNAME.Indexb1))
                End If
            Next kvpNAME
        Next strSORT
    End Sub 'btnRefresh_Folders_Click

    Public Sub btnShowFolder_Click(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing) Handles btnShowFolder.Click, btnShowFolder2.Click
        Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
        Dim strEXEC_PATH = System.Environment.ExpandEnvironmentVariables("%WINDIR%\explorer.exe")
        'If Me.chkUsedFolders.Checked Then
        '    strEXEC_PATH = strROOT & "\..\..\XYplorer\XYplorer.exe"
        'End If

        If System.IO.File.Exists(strEXEC_PATH) = False Then
            MsgBox("Cannot find path to run program: " & strEXEC_PATH)
        Else
            System.Diagnostics.Process.Start(strEXEC_PATH, """" & strROOT.Replace("""", """""") & """")
        End If
    End Sub

    Private Sub chkSortByTicket_CheckedChanged(sender As Object, e As EventArgs) Handles chkSortByTicket.CheckedChanged
        Call btnRefresh_Folders_Click()
    End Sub

    Private Sub chkUsedFolders_CheckedChanged(sender As Object, e As EventArgs)
        Call btnRefresh_Folders_Click()
    End Sub 'chkUsedFolders_CheckedChanged

    Public Sub Exec_ListAdd()
        Mx.WindowSearch.EnumWindowsDllImport(New Mx.WindowSearch.EnumWindowsCallback(AddressOf FillActiveWindowsList_InListBox), 0)
    End Sub

    Public Function FillActiveWindowsList_InListBox(ByVal hWnd As Integer, ByVal lParam As Integer) As Boolean
        FillActiveWindowsList_InListBox = True
        Try
            Dim stbFOUND_TITLE As New System.Text.StringBuilder(255)
            Mx.WindowSearch.GetWindowText(hWnd, stbFOUND_TITLE, 255)
            Dim bolIS_ACTIVE = Mx.WindowSearch.ProcessIsActiveWindow(hWnd)
            Dim strFOUND_TITLE = stbFOUND_TITLE.ToString
            Dim strPATH = strFOUND_TITLE
            Dim intFOLDER = InStr(strFOUND_TITLE.ToUpper, " - XYPLORER")
            If intFOLDER > 0 Then
                strPATH = Mid(strFOUND_TITLE, 1, intFOLDER - 1)
            End If

            Dim intHD_FOLDER = InStr(strPATH, " hd")
            Dim strFOLDER = strPATH
            If intHD_FOLDER > 0 Then
                strFOLDER = System.IO.Path.GetFileName(strPATH)
                intHD_FOLDER = InStr(strFOLDER, " hd")
            End If

            Dim intFOLDER_FOUND = Mx.ListBoxSearch.IndexOf_c(Me.lstFolder, strFOLDER)
            If bolIS_ACTIVE AndAlso
              intFOLDER > 0 AndAlso
              intHD_FOLDER > 0 AndAlso
              intFOLDER_FOUND < 0 Then
                Me.lstFolder.Items.Insert(0, strFOLDER)
                Me.psdaROOT.Add(strFOLDER, strPATH)
            End If
        Catch ex As System.Exception
        End Try
    End Function 'FillActiveWindowsList_InListBox

    Private Sub FolderExport(ur_folder As String, Optional ur_file As String = "")
        Dim strSRC_FOLDER = Me.lstEnv.SelectedItem.ToString
        If ur_file <> "" Then
            strSRC_FOLDER = ur_folder
        End If

        Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
        Dim strEXEC_PATH = strROOT & "\..\SpProcDef\" & strvSQL_PROC_DEF & ".vbscript.cmd"
        Dim strEXEC_PARAM = ""
        Dim strBASE_FOLDER = Split(ur_folder, " ")(0)
        Me.strvDB_PARM = ""
        If Me.sdavDB_PARM.ContainsKey(strBASE_FOLDER) Then
            Me.strvDB_PARM = sdavDB_PARM.Item(strBASE_FOLDER)

            If Mx.AreEqual(Me.strvDB_PARM, "AppActivate") = False Then
                strEXEC_PARAM = Me.strvDB_PARM & Mx.s & "/nointerface /root_dir=" & strROOT & " /in_subdir=" & strSRC_FOLDER & " /out_subdir=" & strBASE_FOLDER & " /cmp_subdir=" & ur_folder
            End If

        Else
            MsgBox("Database parameters must be entered for " & ur_folder,, My.Application.Info.Title)
        End If

        If Mx.AreEqual(Me.strvDB_PARM, "AppActivate") Then
            Call Reable_All_Buttons(False)
            Me.strvCURRENT_EXPORT_FOLDER = System.IO.Path.Combine(Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString), strBASE_FOLDER)
            Me.strvCURRENT_COMPARE_FOLDER = System.IO.Path.Combine(Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString), ur_folder)
            Me.objvCOMPARE_LIST = Me.lstE_FILE
            Me.strvCOMPARE_FILE = ur_file
            Me.bolvLEAVE_FILE = False
            Call frmHostedProcDef.ShowDialog()

        ElseIf System.IO.File.Exists(strEXEC_PATH) = False Then
            MsgBox("Cannot find path to run program: " & strEXEC_PATH)
        ElseIf strEXEC_PARAM <> "" Then
            If ur_file <> "" Then
                strEXEC_PARAM &= " /file=" & System.IO.Path.GetFileName(ur_file)
            End If

            Dim objSTART_INFO = New System.Diagnostics.ProcessStartInfo()
            objSTART_INFO.FileName = strEXEC_PATH
            objSTART_INFO.Arguments = strEXEC_PARAM
            'objSTART_INFO.RedirectStandardOutput = True
            'objSTART_INFO.RedirectStandardError = True
            objSTART_INFO.UseShellExecute = False
            objSTART_INFO.CreateNoWindow = True

            Dim objPROCESS = New System.Diagnostics.Process()
            objPROCESS.StartInfo = objSTART_INFO
            objPROCESS.Start()
        End If 'strEXEC_PARAM
    End Sub 'FolderExport

    Public Function gCurrent_Connection() As String
        gCurrent_Connection = ""
        Dim strFOLDER = Me.lstEnv.SelectedItem.ToString
        If Me.strvFILE_SIDE = "C" Then
            strFOLDER = Me.lstCompare.SelectedItem.ToString
        End If

        Dim strBASE_FOLDER = Split(strFOLDER, " ")(0)
        If sdavDB_PARM.ContainsKey(strBASE_FOLDER) Then
            Dim strcSERVER = "server="
            Dim strcAPPDB = "appdb="
            Dim strSERVER_NAME = ""
            Dim strAPPDB_NAME = ""
            For Each strENTRY In sdavDB_PARM.Item(strBASE_FOLDER).Split("/")
                If Mid(strENTRY.ToLower, 1, Len(strcSERVER)) = strcSERVER Then
                    strSERVER_NAME = Trim(Mid(strENTRY, Len(strcSERVER) + 1))
                End If

                If Mid(strENTRY.ToLower, 1, Len(strcAPPDB)) = strcAPPDB Then
                    strAPPDB_NAME = Trim(Mid(strENTRY, Len(strcAPPDB) + 1))
                End If
            Next strENTRY

            gCurrent_Connection = String.Format("Server={0};Database={1};Integrated Security=SSPI", strSERVER_NAME, strAPPDB_NAME)

        Else 'sdavDB_PARM
            MsgBox("Database parameters must be entered for " & strFOLDER,, My.Application.Info.Title)
        End If
    End Function 'gCurrent_Connection

    Private Sub HdFolders_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim intFORM_WIDTH = Me.Width
        If intFORM_WIDTH > 100 Then
            Me.pnlE_File.Width = (intFORM_WIDTH - 20) / 2
        End If
    End Sub 'HdFolders_Resize

    Public Sub lstC_FILE_DoubleClick(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing) Handles lstC_FILE.DoubleClick
        Call lstC_FILE_KeyPress()
    End Sub 'lstC_FILE_DoubleClick

    Private Sub lstC_FILE_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstC_FILE.KeyPress
        Dim intSELECTED = Me.lstC_FILE.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim strFILE = lstC_FILE.SelectedItem.ToString
            Call FolderExport(Me.lstCompare.SelectedItem.ToString, strFILE)
        End If
    End Sub 'lstC_FILE_KeyPress

    Private Sub lstC_FILE_KeyDown(sender As Object, e As KeyEventArgs) Handles lstC_FILE.KeyDown
        If e.KeyCode = Keys.F2 Then
            e.Handled = True
            InputBox("", "Filename", System.IO.Path.GetFileName(Me.lstC_FILE.SelectedItem.ToString))
        End If
    End Sub 'lstC_FILE_KeyDown

    Private Sub lstCompare_DoubleClick(sender As Object, e As EventArgs) Handles lstCompare.DoubleClick
        Call lstCompare_KeyPress()
    End Sub

    Private Sub lstCompare_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstCompare.KeyPress
        Dim intSELECTED = Me.lstEnv.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim strSEL_FOLDER = Me.lstEnv.SelectedItem.ToString
            Me.btnE_Folder.Text = strSEL_FOLDER
            Dim strROOT = System.IO.Path.Combine(Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString), strSEL_FOLDER)
            Call Me.lstE_FILE.Items.Clear()
            For Each strPATH In System.IO.Directory.EnumerateFiles(strROOT, "*.*", IO.SearchOption.AllDirectories)
                Dim strSUB_FILE_PATH = strPATH.Replace(strROOT, "")
                Me.lstE_FILE.Items.Add(strSUB_FILE_PATH)
            Next strPATH

            strSEL_FOLDER = Me.lstCompare.SelectedItem.ToString
            Me.btnC_Folder.Text = strSEL_FOLDER
            strROOT = System.IO.Path.Combine(Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString), strSEL_FOLDER)
            Call Me.lstC_FILE.Items.Clear()
            For Each strPATH In System.IO.Directory.EnumerateFiles(strROOT, "*.*", IO.SearchOption.AllDirectories)
                Dim strSUB_FILE_PATH = strPATH.Replace(strROOT, "")
                Me.lstC_FILE.Items.Add(strSUB_FILE_PATH)
            Next strPATH

            Me.TabControl1.SelectedTab = Me.tabFile
            Me.btnCompare.Select()
        End If 'intSELECTED
    End Sub 'lstCompare_KeyPress

    Public Sub lstE_FILE_DoubleClick(Optional sender As Object = Nothing, Optional e As EventArgs = Nothing) Handles lstE_FILE.DoubleClick
        Call lstE_FILE_KeyPress()
    End Sub

    Private Sub lstE_FILE_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstE_FILE.KeyPress
        Dim intSELECTED = lstE_FILE.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim strFILE = lstE_FILE.SelectedItem.ToString
            Call FolderExport(Me.lstEnv.SelectedItem.ToString, strFILE)
        End If
    End Sub 'lstE_FILE_KeyPress

    Private Sub lstE_FILE_KeyDown(sender As Object, e As KeyEventArgs) Handles lstE_FILE.KeyDown
        If e.KeyCode = Keys.F2 Then
            e.Handled = True
            InputBox("", "Filename", System.IO.Path.GetFileName(Me.lstE_FILE.SelectedItem.ToString))
        End If
    End Sub 'lstE_FILE_KeyDown

    Private Sub lstEnv_DoubleClick(sender As Object, e As EventArgs) Handles lstEnv.DoubleClick
        Call lstEnv_KeyPress()
    End Sub

    Private Sub lstEnv_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstEnv.KeyPress
        Dim intSELECTED = Me.lstEnv.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Call Me.lstCompare.Items.Clear()
            Dim strE_FOLDER = Me.lstEnv.SelectedItem.ToString
            For Each objENTRY In Me.lstEnv.Items
                Dim strENTRY = objENTRY.ToString
                If strENTRY <> strE_FOLDER Then
                    Me.lstCompare.Items.Add(strENTRY)
                End If
            Next

            Me.TabControl1.SelectedTab = Me.tabCompare
            Me.lstCompare.Select()
        End If 'intSELECTED
    End Sub 'lstEnv_KeyPress

    Private Sub lstFolder_DoubleClick(sender As Object, e As EventArgs) Handles lstFolder.DoubleClick
        Call lstFolder_KeyPress()
    End Sub

    Public Sub lstFolder_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstFolder.KeyPress
        Dim intSELECTED = Me.lstFolder.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
            Dim strTICKET = strROOT
            Dim intTICKET_SPRTR = InStrRev(strROOT, " ")
            If intTICKET_SPRTR > 0 Then
                strTICKET = Mid(strROOT, intTICKET_SPRTR + 1)
            End If

            Call Me.lstEnv.Items.Clear()
            Call Me.lstCompare.Items.Clear()
            Call Me.cboNewExport_Type.Items.Clear()
            Call sdavEXPORT_TYPE.Clear()
            Dim bolWAITING_TICKET = Mx.StartingWithText(System.IO.Path.GetFileName(strROOT), "Waiting ")
            Dim objAPP_SETTINGS = System.Configuration.ConfigurationManager.AppSettings
            For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
                Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
                Dim strENTRY = objAPP_SETTINGS.Item(KEYCTR)
                If Mid(strKEY, 1, Len("EXPORT")).ToUpper = "EXPORT" Then
                    For Each strFIELD In strENTRY.Split(","c)
                        If sdavEXPORT_TYPE.Contains(strFIELD) = False AndAlso
                          bolWAITING_TICKET = Mx.StartingWithText(strFIELD, "Branch") Then
                            Call sdavEXPORT_TYPE.Add(strFIELD)
                            Call Me.cboNewExport_Type.Items.Add(strFIELD)
                        End If
                    Next strFIELD
                End If 'strKEY
            Next KEYCTR

            For Each strPATH In System.IO.Directory.EnumerateDirectories(strROOT)
                Dim strFOLDER_NAME = System.IO.Path.GetFileName(strPATH)
                Dim bolFOUND_EXPORT_TYPE = False
                For Each strTYPE In sdavEXPORT_TYPE
                    If Mx.EndingWithText(strFOLDER_NAME, Mx.s & strTYPE) Then
                        bolFOUND_EXPORT_TYPE = True
                        Exit For
                    End If
                Next strTYPE

                If bolFOUND_EXPORT_TYPE AndAlso
                  (
                    Mx.ListBoxSearch.IndexOf_c(Me.lstEnv, strFOLDER_NAME) < 0
                  ) Then
                    Me.lstEnv.Items.Add(strFOLDER_NAME)
                End If
            Next strPATH

            Call sdavEXPORT_TYPE.Clear()
            Call Me.lstNoteType.Items.Clear()
            For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
                Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
                Dim strENTRY = objAPP_SETTINGS.Item(KEYCTR)
                If Mid(strKEY, 1, Len("NOTE")).ToUpper = "NOTE" Then
                    For Each strFIELD In strENTRY.Split(","c)
                        Dim strNOTE_TYPE_AND_TICKET = strFIELD & " " & strTICKET
                        If sdavEXPORT_TYPE.Contains(strNOTE_TYPE_AND_TICKET) = False Then
                            sdavEXPORT_TYPE.Add(strNOTE_TYPE_AND_TICKET)
                            Me.lstNoteType.Items.Add(strNOTE_TYPE_AND_TICKET)
                        End If
                    Next strFIELD
                End If 'strKEY
            Next KEYCTR

            Call Me.lstNoteFile.Items.Clear()
            For Each strPATH In System.IO.Directory.EnumerateDirectories(strROOT, "NOTES", IO.SearchOption.TopDirectoryOnly)
                For Each strFILE In System.IO.Directory.EnumerateFiles(strPATH, "*.TXT")
                    Dim strFILE_NAME = strFILE.Replace(strROOT, "")
                    Call Me.lstNoteFile.Items.Add(strFILE_NAME)
                Next strFILE
            Next strPATH

            Me.btnTicket_Folder.Text = Me.lstFolder.SelectedItem.ToString
            Me.TabControl1.SelectedTab = Me.tabEnv
            Me.lstEnv.Select()
        End If 'intSELECTED
    End Sub 'lstFolder_KeyPress

    Private Sub lstNoteFile_DoubleClick(sender As Object, e As EventArgs) Handles lstNoteFile.DoubleClick
        Call lstNoteFile_KeyPress()
    End Sub

    Private Sub lstNoteFile_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstNoteFile.KeyPress
        Dim intSELECTED = Me.lstNoteFile.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim strROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
            Dim strNOTE_PATH = strROOT & Me.lstNoteFile.SelectedItem.ToString
            Call Mx.UserAction.Run_NotePadPlusPlus_errhnd(strNOTE_PATH)
        End If
    End Sub 'lstNoteFile_KeyPress

    Private Sub Reable_All_Buttons(ur_reable As Boolean)
        If ur_reable = False Then
            Call lstCompare_KeyPress()
        End If

        Dim bolNEEDED_RESET = False
        If Me.btnC_Export.Enabled = False OrElse
          Me.btnE_Export.Enabled = False OrElse
          Me.btnCompare.Enabled = False OrElse
          Me.btnClear.Enabled = False OrElse
          Me.btnDupFile_Check.Enabled = False Then
            bolNEEDED_RESET = True
        End If

        Me.btnC_Export.Enabled = ur_reable
        Me.btnE_Export.Enabled = ur_reable
        Me.btnCompare.Enabled = ur_reable
        Me.btnClear.Enabled = ur_reable
        Me.btnDupFile_Check.Enabled = ur_reable
        If ur_reable = True AndAlso
          bolNEEDED_RESET = True AndAlso
            Me.TabControl1.SelectedTab Is Me.tabFile Then
            Me.btnCompare.Select()
        End If
    End Sub 'Reable_All_Buttons

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Timer1.Stop()
        Call Reable_All_Buttons(True)
        Me.Timer1.Start()
    End Sub 'Timer1_Tick

    Private Sub btnRenameWaiting_Click(sender As Object, e As EventArgs) Handles btnRenameWaiting.Click
        Const lit_WAITING_sp = "Waiting "
        Dim strSRC_ROOT = Me.psdaROOT.Item(Me.lstFolder.SelectedItem.ToString)
        Dim strROOT_PARENT = System.IO.Path.GetDirectoryName(strSRC_ROOT)
        Dim strDEST_ROOT = System.IO.Path.GetFileName(strSRC_ROOT)
        Dim strSRC_SUFFIX = ""
        Dim strDEST_SUFFIX = ""
        If Mx.StartingWithText(System.IO.Path.GetFileName(strSRC_ROOT), lit_WAITING_sp) Then
            strDEST_ROOT = System.IO.Path.Combine(strROOT_PARENT, Mid(strDEST_ROOT, lit_WAITING_sp.Length + 1))
            strSRC_SUFFIX = "Branch"
        Else
            strDEST_ROOT = System.IO.Path.Combine(strROOT_PARENT, lit_WAITING_sp & strDEST_ROOT)
            strDEST_SUFFIX = "Branch"
        End If

        For Each strSRC_PATH In System.IO.Directory.GetDirectories(strSRC_ROOT, "*", System.IO.SearchOption.TopDirectoryOnly)
            Dim strSRC_FOLDER = System.IO.Path.GetFileName(strSRC_PATH)
            Dim sdaFOLDER_SUFFIX = strSRC_FOLDER.Split(" ")
            Call Array.Reverse(sdaFOLDER_SUFFIX)
            Dim strFOUND_SUFFIX = sdaFOLDER_SUFFIX(0)
            Dim strFOUND_PREFIX = Mid(strSRC_FOLDER, 1, strSRC_FOLDER.Length - strFOUND_SUFFIX.Length)

            For Each strSUFFIX_ENTRY In sdavEXPORT_TYPE
                If Mx.AreEqual(strFOUND_SUFFIX, strSRC_SUFFIX & strSUFFIX_ENTRY) AndAlso
                  Mx.AreEqual(strFOUND_SUFFIX, strDEST_SUFFIX & strSUFFIX_ENTRY) = False Then
                    Dim strDEST_FOLDER = strFOUND_PREFIX & strDEST_SUFFIX & strSUFFIX_ENTRY
                    Dim strDEST_PATH = System.IO.Path.Combine(strSRC_ROOT, strDEST_FOLDER)
                    Call System.IO.Directory.Move(strSRC_PATH, strDEST_PATH)
                End If
            Next strSUFFIX_ENTRY
        Next strSRC_PATH

        Call System.IO.Directory.Move(strSRC_ROOT, strDEST_ROOT)
        Call btnRefresh_Folders_Click()
    End Sub

    Private Sub btnTicket_Folder_Click(sender As Object, e As EventArgs) Handles btnTicket_Folder.Click
        Me.TabControl1.SelectedTab = Me.tabFolder
    End Sub

    Private Sub lstFolder_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstFolder.SelectedIndexChanged

    End Sub

    <System.Diagnostics.DebuggerHidden()>
    Public Shared Widening Operator CType(b As frmHdFolders) As Mx.dbUserInput
        Return New Mx.dbUserInput(b)
    End Operator
End Class 'frmHdFolders
