﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHostedProcDef
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lblTimer = New System.Windows.Forms.Label()
        Me.lstFile = New System.Windows.Forms.ListBox()
        Me.btnReSubmit = New System.Windows.Forms.Button()
        Me.chk30SecShowing = New System.Windows.Forms.CheckBox()
        Me.btnSkipFile = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 5000
        '
        'lblTimer
        '
        Me.lblTimer.AutoSize = True
        Me.lblTimer.Location = New System.Drawing.Point(15, 23)
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(169, 13)
        Me.lblTimer.TabIndex = 0
        Me.lblTimer.Text = "Waiting for Downloads: 0 seconds"
        '
        'lstFile
        '
        Me.lstFile.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstFile.FormattingEnabled = True
        Me.lstFile.Location = New System.Drawing.Point(12, 78)
        Me.lstFile.Name = "lstFile"
        Me.lstFile.Size = New System.Drawing.Size(263, 316)
        Me.lstFile.TabIndex = 1
        '
        'btnReSubmit
        '
        Me.btnReSubmit.Location = New System.Drawing.Point(39, 53)
        Me.btnReSubmit.Name = "btnReSubmit"
        Me.btnReSubmit.Size = New System.Drawing.Size(78, 19)
        Me.btnReSubmit.TabIndex = 2
        Me.btnReSubmit.Text = "Re-submit"
        Me.btnReSubmit.UseVisualStyleBackColor = True
        '
        'chk30SecShowing
        '
        Me.chk30SecShowing.AutoSize = True
        Me.chk30SecShowing.Location = New System.Drawing.Point(190, 22)
        Me.chk30SecShowing.Name = "chk30SecShowing"
        Me.chk30SecShowing.Size = New System.Drawing.Size(102, 17)
        Me.chk30SecShowing.TabIndex = 3
        Me.chk30SecShowing.Text = "30-sec Showing"
        Me.chk30SecShowing.UseVisualStyleBackColor = True
        '
        'btnSkipFile
        '
        Me.btnSkipFile.Location = New System.Drawing.Point(143, 53)
        Me.btnSkipFile.Name = "btnSkipFile"
        Me.btnSkipFile.Size = New System.Drawing.Size(109, 19)
        Me.btnSkipFile.TabIndex = 4
        Me.btnSkipFile.Text = "Skip File"
        Me.btnSkipFile.UseVisualStyleBackColor = True
        '
        'frmHostedProcDef
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(288, 415)
        Me.Controls.Add(Me.btnSkipFile)
        Me.Controls.Add(Me.chk30SecShowing)
        Me.Controls.Add(Me.btnReSubmit)
        Me.Controls.Add(Me.lstFile)
        Me.Controls.Add(Me.lblTimer)
        Me.Name = "frmHostedProcDef"
        Me.Text = "Hosted Proc Def"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents lblTimer As System.Windows.Forms.Label
    Friend WithEvents lstFile As System.Windows.Forms.ListBox
    Friend WithEvents btnReSubmit As System.Windows.Forms.Button
    Friend WithEvents chk30SecShowing As System.Windows.Forms.CheckBox
    Friend WithEvents btnSkipFile As System.Windows.Forms.Button
End Class
