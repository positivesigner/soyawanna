﻿Imports System
Imports System.Windows.Forms

Public Class frmExportLog
    Private Sub frmExportLog_Load(sender As Object, e As System.EventArgs) Handles MyBase.Load
        Dim sdaFOLDER_SORT = New Mx.Sdata
        For Each strFILE_PATH In System.IO.Directory.EnumerateFiles(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location), frmHdFolders.strvSQL_PROC_DEF & "*.err.txt")
            sdaFOLDER_SORT.Add(System.IO.Path.GetFileName(strFILE_PATH))
        Next

        Call sdaFOLDER_SORT.Sort()
        Call sdaFOLDER_SORT.Reverse()

        Call Me.lstLogPath.Items.Clear()
        For Each strFILE_PATH In sdaFOLDER_SORT
            Me.lstLogPath.Items.Add(strFILE_PATH)
        Next
    End Sub

    Private Sub lstLogPath_DoubleClick(sender As Object, e As EventArgs) Handles lstLogPath.DoubleClick
        Call lstLogPath_KeyPress()
    End Sub

    Sub lstLogPath_KeyPress(Optional sender As Object = Nothing, Optional e As KeyPressEventArgs = Nothing) Handles lstLogPath.KeyPress
        Dim intSELECTED = Me.lstLogPath.SelectedIndex
        If (e Is Nothing OrElse e.KeyChar = vbCr) AndAlso
          intSELECTED >= 0 Then
            Dim strSEL_LOG = Me.lstLogPath.SelectedItem.ToString
            Call Mx.UserAction.Run_NotePadPlusPlus_errhnd(strSEL_LOG)
            System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location)
        End If
    End Sub
End Class