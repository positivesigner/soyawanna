Imports System

Module Program
    Sub Main(args As String())
        Dim strPATH = "C:\Users\Dad\Downloads\dotnet-sdk-3.1.301-win-x64.exe"
        Using objSHA = New System.Security.Cryptography.SHA512Managed
            Using stmFILE = System.IO.File.OpenRead(strPATH)
                Console.WriteLine("[" & System.BitConverter.ToString(objSHA.ComputeHash(stmFILE)).Replace("-", "").ToLower & "]")
                'Convert.ToBase64String(
            End Using
        End Using
    End Sub 'Main
End Module 'Program
