Module AppStartup
    Sub Main(args As String())
        Call Mx.Want.Console_WriteAssemblyDir_errhnd()
    End Sub 'Main
End Module 'AppStartup

Namespace Mx
    Public Class Want
        Public Shared Sub Console_WriteAssemblyDir(ur_ret_text As Strap)
            ur_ret_text.dSprtr("[", FileNamed().wAssemblyDir).d("]")
        End Sub 'Console_WriteAssemblyDir
        
        Public Shared Sub Console_WriteAssemblyDir_errhnd()
            Dim stpRET = Strapd()
            Dim objERR_LIST = New ErrListBase : Try
                Call Console_WriteAssemblyDir(stpRET)

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                stpRET.Clear().d(objERR_LIST.ToString)
            End If
            
            If stpRET.HasText Then
                Console.WriteLine(stpRET)
            End If
        End Sub 'Console_WriteAssemblyDir_errhnd
    End Class 'Want
End Namespace 'Mx