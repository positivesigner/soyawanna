﻿Option Strict On

Namespace Mx
    Public Class UserAction
        Public Shared Function Add_New_Row_errhnd(ur_form As dbUserInput, Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Add_New_Row_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim main_grid = ur_form.grdSetting
                Dim newval_tbox = ur_form.txtNewVal
                Dim savechanges_btn = ur_form.btnSaveAllChanges
                Dim windows_inputbox_env = Have.WindowsInputBox
                Dim windows_msgbox_env = Have.WindowsMsgBox
                Dim customapp_parm_cart = Have.CustomAppParm
                Dim new_parm_name = Assistant.Ask_User_for_NewParmName(windows_inputbox_env)
                new_parm_name = Assistant.Error_User_for_ParmName_Validation(customapp_parm_cart, new_parm_name, windows_msgbox_env)
                Dim new_parm_row = Assistant.Add_Parm_to_Cart(customapp_parm_cart, new_parm_name)
                Dim update_button_count = Assistant.Update_SaveAllBtn_enabled(savechanges_btn, new_parm_row)
                Dim update_tbox_count = Assistant.Update_Tbox_disabled(newval_tbox)
                Dim new_row_num = Assistant.Add_Row_to_Grid(main_grid, new_parm_row)
                Dim navigated_row_count = Assistant.Navigate_Grid_current_row(main_grid, new_row_num)
                Dim overwrite_row_count = Assistant.Overwrite_text_RowValue(newval_tbox, new_parm_row)
                update_tbox_count = Assistant.Update_Tbox_enabled(newval_tbox)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Add_New_Row_errhnd

        Public Shared Function Delete_Existing_Row_errhnd(ur_form As dbUserInput, Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Delete_Existing_Row_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim main_grid = ur_form.grdSetting
                Dim savechanges_btn = ur_form.btnSaveAllChanges
                Dim newval_tbox = ur_form.txtNewVal
                Dim windows_msgbox_env = Have.WindowsMsgBox
                Dim customapp_parm_cart = Have.CustomAppParm
                Dim found_parm_row = Assistant.Get_Grid_Row_Parm(main_grid, customapp_parm_cart)
                found_parm_row = Assistant.Ask_User_for_DeleteVerify(found_parm_row, windows_msgbox_env)
                Dim update_button_count = Assistant.Update_SaveAllBtn_enabled(savechanges_btn, found_parm_row)
                Dim remove_row_count = Assistant.Remove_Parm_from_Cart(customapp_parm_cart, found_parm_row)
                If remove_row_count = 1 Then
                    Dim reset_row_count = Assistant.Reset_Rows_in_Grid(main_grid, newval_tbox, customapp_parm_cart)
                End If

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Delete_Existing_Row_errhnd

        Public Shared Function Change_current_Row_Value_errhnd(ur_form As dbUserInput, Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Change_current_Row_Value_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim main_grid = ur_form.grdSetting
                Dim savechanges_btn = ur_form.btnSaveAllChanges
                Dim newval_tbox = ur_form.txtNewVal
                Dim customapp_parm_cart = Have.CustomAppParm
                Dim found_parm_row = Assistant.Get_Grid_Row_Parm(main_grid, customapp_parm_cart)
                found_parm_row = Assistant.Ask_NewValTbox_enabled(newval_tbox, found_parm_row)
                Dim update_button_count = Assistant.Update_SaveAllBtn_enabled(savechanges_btn, found_parm_row)
                Dim update_row_count = Assistant.Update_Parm_Value(found_parm_row, newval_tbox)
                update_row_count = Assistant.Update_GridRow_Value(main_grid, found_parm_row)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Change_current_Row_Value_errhnd

        Public Shared Function Open_HelpFile_errhnd(Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Open_HelpFile_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim windowsfs_env = Have.WindowsFS
                Dim appexternal_cart = Have.AppExternal
                Dim userbowl_cart = Have.UserBowl
                Dim helpfile_path_bowlname = enmUN.helpfile_path
                Dim app_opened_count = Assistant.Open_External_App(appexternal_cart, userbowl_cart, helpfile_path_bowlname, windowsfs_env)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Open_HelpFile

        Public Shared Function Open_Main_Form_errhnd(ur_form As dbUserInput, ur_appconfig As dbConfigInput, Optional ur_flag_msgbox As Boolean = True) As Strap
            Have.objAPP_CONFIG = ur_appconfig

            Dim stpRET = Strapd() : Open_Main_Form_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim main_grid = ur_form.grdSetting
                Dim saveall_btn = ur_form.btnSaveAllChanges
                Dim newval_tbox = ur_form.txtNewVal
                Dim file_path_ref_tbox = ur_form.txtUserFile
                Dim windows_envvar_env = Have.WindowsEnvVar
                Dim windowsfs_env = Have.WindowsFS
                Dim appconfig_cart = Have.AppConfigSettings
                Dim customapp_parm_cart = Have.CustomAppParm
                Dim userbowl_cart = Have.UserBowl
                Dim appfolder_bowlname = enmUN.app_folder
                Dim helpfile_path_bowlname = enmUN.helpfile_path
                Dim persist_path_bowlname = enmUN.persist_path
                Dim updated_row_count = Assistant.Store_DeveloperSettings_Path(windows_envvar_env, userbowl_cart, persist_path_bowlname)
                updated_row_count = Assistant.Store_HelpFile_Path(userbowl_cart, helpfile_path_bowlname)
                Dim updated_tbox_count = Assistant.Show_DeveloperSettings_Path(file_path_ref_tbox, userbowl_cart, persist_path_bowlname)
                Dim reset_row_count = prv.Refresh_Grid(main_grid, saveall_btn, newval_tbox, windowsfs_env, appconfig_cart, customapp_parm_cart, userbowl_cart, persist_path_bowlname, appfolder_bowlname)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Open_Main_Form_errhnd

        Public Shared Function Overwrite_displayed_Row_Value_errhnd(ur_form As dbUserInput, Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Overwrite_displayed_Row_Value_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim main_grid = ur_form.grdSetting
                Dim newval_tbox = ur_form.txtNewVal
                Dim customapp_parm_cart = Have.CustomAppParm
                Dim found_parm_row = Assistant.Get_Grid_Row_Parm(main_grid, customapp_parm_cart)
                found_parm_row = Assistant.Ask_NewValTbox_enabled(newval_tbox, found_parm_row)
                If found_parm_row IsNot Nothing Then
                    Dim update_tbox_count = Assistant.Update_Tbox_disabled(newval_tbox)
                    Dim overwrite_row_count = Assistant.Overwrite_text_RowValue(newval_tbox, found_parm_row)
                    update_tbox_count = Assistant.Update_Tbox_enabled(newval_tbox)
                End If

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Overwrite_displayed_Row_Value_errhnd

        Public Shared Function Refresh_Grid_errhnd(ur_form As dbUserInput, Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Refresh_Grid_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim main_grid = ur_form.grdSetting
                Dim saveall_btn = ur_form.btnSaveAllChanges
                Dim newval_tbox = ur_form.txtNewVal
                Dim windowsfs_env = Have.WindowsFS
                Dim appconfig_cart = Have.AppConfigSettings
                Dim customapp_parm_cart = Have.CustomAppParm
                Dim userbowl_cart = Have.UserBowl
                Dim appfolder_bowlname = enmUN.app_folder
                Dim persist_path_bowlname = enmUN.persist_path
                Dim reset_row_count = prv.Refresh_Grid(main_grid, saveall_btn, newval_tbox, windowsfs_env, appconfig_cart, customapp_parm_cart, userbowl_cart, persist_path_bowlname, appfolder_bowlname)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'Refresh_Grid_errhnd

        Public Shared Function Save_To_File_errhnd(ur_form As dbUserInput, Optional ur_flag_msgbox As Boolean = True) As Strap
            Dim stpRET = Strapd() : Save_To_File_errhnd = stpRET : Dim objERR_LIST = New ErrListBase : Try

                Dim saveall_btn = ur_form.btnSaveAllChanges
                Dim customapp_parm_cart = Have.CustomAppParm
                Dim userbowl_cart = Have.UserBowl
                Dim persist_path_bowlname = enmUN.persist_path
                Dim written_file_count = Assistant.Update_CustomAppParm_File(customapp_parm_cart, userbowl_cart, persist_path_bowlname)
                Dim update_btn_count = Assistant.Update_Button_disabled(saveall_btn)

            Catch ex As System.Exception : Call objERR_LIST.dError_Stack(ex) : End Try : prv.Handle_MsgBox(objERR_LIST, stpRET, ur_flag_msgbox)
        End Function 'SaveToFile_errhnd

        Private Class prv
            Public Shared Sub Handle_MsgBox(ur_errlst As ErrListBase, ur_strap As Strap, ur_flag_msgbox As Boolean)
                If ur_errlst.Found Then
                    ur_strap.Clear().d(ur_errlst.ToString)
                End If

                If ur_flag_msgbox AndAlso
                  ur_strap.HasText Then
                    Call glbl.gMsgBox.GetResult(ur_strap, MsgBoxStyle.OkOnly, Have.UserBowl.SelKey(enmUN.app_name).Contents)
                End If
            End Sub 'Handle_MsgBox

            Public Shared Function Refresh_Grid(ur_grid As dbUserInput.componentDataGridView, ur_saveall_btn As dbUserInput.componentButton, ur_newval_tbox As dbUserInput.componentTextBox, ur_windowsfs_env As Have.glblWindowsFS, ur_appconfig_cart As Have.sAppConfigSettings, ur_customapp_parm_cart As Have.sCustomAppParm, ur_userbowl_cart As Have.sUserBowl, ur_persist_path_bowlname As enmUN.zpersist_path, ur_appfolder_bowlname As enmUN.zapp_folder, Optional ur_flag_msgbox As Boolean = True) As Integer
                Dim update_btn_count = Assistant.Update_Button_disabled(ur_saveall_btn)
                Dim found_row_count = Assistant.Load_DeveloperSettings_Table(ur_customapp_parm_cart, ur_userbowl_cart, ur_persist_path_bowlname)
                Dim sdaMISSING_PARM = Assistant.Find_extra_AppConfig_Parms(ur_appconfig_cart, ur_customapp_parm_cart)
                Dim refresh_row_count = Assistant.Add_Defaults_for_missing_DeveloperSettings(sdaMISSING_PARM, ur_customapp_parm_cart, ur_appconfig_cart, ur_userbowl_cart, ur_appfolder_bowlname, ur_windowsfs_env)
                Dim reset_row_count = Assistant.Reset_Rows_in_Grid(ur_grid, ur_newval_tbox, ur_customapp_parm_cart)
                Refresh_Grid = reset_row_count
            End Function 'Refresh_Grid_errhnd
        End Class 'prv
    End Class 'User

    Public Class Assistant
        Public Shared Function Add_Parm_to_Cart(ur_customapp_parm_cart As Have.sCustomAppParm, ur_new_parm As String) As Have.rCustomAppParm
            Add_Parm_to_Cart = Nothing
            If HasText(ur_new_parm) Then
                Dim trwNEW_PARM = ur_customapp_parm_cart.InsKey(ur_new_parm)
                Add_Parm_to_Cart = trwNEW_PARM
            End If 'ur_new_parm
        End Function 'Add_Parm_to_Cart

        Public Shared Function Add_Row_to_Grid(ur_grid As dbUserInput.componentDataGridView, ur_parm_row As Have.rCustomAppParm) As Integer
            Add_Row_to_Grid = 0
            If ur_parm_row IsNot Nothing Then
                Dim intNEW_ROW = ur_grid.Rows.Add
                Add_Row_to_Grid = b1(intNEW_ROW)
                Dim new_row = ur_grid.Rows(intNEW_ROW).Cells
                new_row.Item(b0(1)).Value = ur_parm_row.v(enmSNV.setting_name)
                new_row.Item(b0(2)).Value = ur_parm_row.v(enmSNV.setting_value)
            End If 'ur_parm_row
        End Function 'Add_Row_to_Grid

        Public Shared Function Ask_NewValTbox_enabled(ur_newval_tbox As dbUserInput.componentTextBox, ur_parm_row As Have.rCustomAppParm) As Have.rCustomAppParm
            Ask_NewValTbox_enabled = Nothing
            If ur_newval_tbox IsNot Nothing Then
                If ur_newval_tbox.Enabled Then
                    Ask_NewValTbox_enabled = ur_parm_row
                End If
            End If 'ur_newval_tbox
        End Function 'Ask_NewValTbox_enabled

        Public Shared Function Ask_User_for_DeleteVerify(ur_parm_row As Have.rCustomAppParm, ur_windows_msgbox_env As Have.glblWindowsMsgBox) As Have.rCustomAppParm
            Ask_User_for_DeleteVerify = Nothing
            If ur_parm_row IsNot Nothing Then
                Dim enrUSER_INPUT = ur_windows_msgbox_env.GetResult("Do you want to delete the ", MsgBoxStyle.YesNoCancel)
                If enrUSER_INPUT = MsgBoxResult.Yes Then
                    Ask_User_for_DeleteVerify = ur_parm_row
                End If
            End If 'ur_parm_row
        End Function 'Ask_User_for_DeleteVerify

        Public Shared Function Ask_User_for_NewParmName(ur_windows_inputbox_env As Have.glblWindowsInputBox) As String
            Dim strNEW_ENTRY = ur_windows_inputbox_env.GetResult("New Entry Name", mt)
            Ask_User_for_NewParmName = strNEW_ENTRY
        End Function 'Ask_User_for_NewParmName

        Public Shared Function Error_User_for_ParmName_Validation(ur_customapp_parm_cart As Have.sCustomAppParm, ur_new_parmname As String, ur_windows_msgbox_env As Have.glblWindowsMsgBox) As String
            Error_User_for_ParmName_Validation = ur_new_parmname
            'A blank new parameter name just means they canceled out of creating a new parameter name
            If HasText(ur_new_parmname) AndAlso
              ur_customapp_parm_cart.Sel(enmSNV.setting_name, ur_new_parmname).SelAll.Count > 0 Then
                Dim enrUSER_INPUT = ur_windows_msgbox_env.GetResult("That entry already exists", MsgBoxStyle.Exclamation)
                Error_User_for_ParmName_Validation = mt
            End If
        End Function 'Error_User_for_ParmName_Validation

        Public Shared Function Find_extra_AppConfig_Parms(ur_appconfig_cart As Have.sAppConfigSettings, ur_customapp_parm_cart As Have.sCustomAppParm) As Sdata
            Dim sdaMISSING_PARM = New Sdata
            Find_extra_AppConfig_Parms = sdaMISSING_PARM
            For Each trwKEY_LIST In ur_appconfig_cart.Sel(enmAKV.setting_name, "key_search").SelAll
                Dim sdaKEY_SEARCH = New Sdata().dList(trwKEY_LIST.v(enmAKV.setting_value).Split(","c))
                For Each strPARM_NAME In sdaKEY_SEARCH
                    If ur_customapp_parm_cart.Sel(enmSNV.setting_name, strPARM_NAME).SelAll.Count = 0 Then
                        sdaMISSING_PARM.Add(strPARM_NAME)
                    End If
                Next strPARM_NAME
            Next trwKEY_LIST
        End Function 'Find_extra_AppConfig_Parms

        Public Shared Function Get_Grid_Row_Parm(ur_grid As dbUserInput.componentDataGridView, ur_customapp_parm_cart As Have.sCustomAppParm) As Have.rCustomAppParm
            Get_Grid_Row_Parm = Nothing
            If ur_grid.CurrentRow IsNot Nothing Then
                Dim rowPARM = ur_grid.CurrentRow.Cells
                If rowPARM IsNot Nothing Then
                    Dim curCELL = rowPARM.Item(b0(1))
                    If curCELL.Value IsNot Nothing Then
                        Dim strCUR_PK = CType(rowPARM.Item(b0(1)).Value, String)
                        Get_Grid_Row_Parm = ur_customapp_parm_cart.SelKey(strCUR_PK)
                    End If
                End If 'rowPARM
            End If 'ur_new_parm
        End Function 'Get_current_Row_Parm

        Public Shared Function Open_External_App(ur_appexternal_cart As Have.glblAppExternal, ur_userbowl_cart As Have.sUserBowl, ur_helpfile_path_bowlname As enmUN.zhelpfile_path, ur_windowsfs_env As Have.glblWindowsFS) As Integer
            Open_External_App = 0
            Dim flnHELP_FILE_PATH = FileNamed().d(ur_userbowl_cart.SelKey(ur_helpfile_path_bowlname).Contents)
            For Each strPATH In ur_windowsfs_env.GetFiles(flnHELP_FILE_PATH)
                Open_External_App = 1
                ur_appexternal_cart.Start_Windows_Program(strPATH, mt)
                Exit For
            Next strPATH
        End Function 'Open_External_App

        Public Shared Function Load_DeveloperSettings_Table(ur_customapp_parm_cart As Have.sCustomAppParm, ur_userbowl_cart As Have.sUserBowl, ur_persist_path_bowlname As enmUN.zpersist_path) As Integer
            Dim strPERSIST_PATH = ur_userbowl_cart.SelKey(ur_persist_path_bowlname).Contents
            Call ur_customapp_parm_cart.DelAll()
            Dim found_row_count = ur_customapp_parm_cart.PersistRead(strPERSIST_PATH).Count
            Load_DeveloperSettings_Table = found_row_count
        End Function 'Load_DeveloperSettings_Table

        Public Shared Function Navigate_Grid_current_row(ur_grid As dbUserInput.componentDataGridView, ur_row_num_b1 As Integer) As Integer
            Navigate_Grid_current_row = 0
            If ur_row_num_b1 >= 1 AndAlso
              ur_grid.Rows.Count >= ur_row_num_b1 Then
                Navigate_Grid_current_row = 1
                ur_grid.CurrentCell = ur_grid.Rows(b0(ur_row_num_b1)).Cells.Item(b0(1))
            End If
        End Function 'Navigate_Grid_current_row

        Public Shared Function Overwrite_text_RowValue(ur_newval_tbox As dbUserInput.componentTextBox, ur_parm_row As Have.rCustomAppParm) As Integer
            Overwrite_text_RowValue = 0
            If ur_parm_row IsNot Nothing Then
                Overwrite_text_RowValue = 1
                ur_newval_tbox.Text = ur_parm_row.v(enmSNV.setting_value)
            End If 'ur_new_parm
        End Function 'Overwrite_text_RowValue

        Public Shared Function Add_Defaults_for_missing_DeveloperSettings(ur_missing_parm_list As Sdata, ur_customapp_parm_cart As Have.sCustomAppParm, ur_appconfig_cart As Have.sAppConfigSettings, ur_userbowl_cart As Have.sUserBowl, ur_appfolder_bowlname As enmUN.zapp_folder, ur_windowsfs_env As Have.glblWindowsFS) As Integer
            Dim found_row_count = 0
            For Each strPARM_NAME In ur_missing_parm_list
                Dim strPARM_PATH = Assistant.Search_for_AppConfig_Path(ur_appconfig_cart, strPARM_NAME, ur_userbowl_cart, ur_appfolder_bowlname, ur_windowsfs_env)
                If HasText(strPARM_PATH) Then
                    found_row_count += 1
                    Dim new_parm_row = Assistant.Add_Parm_to_Cart(ur_customapp_parm_cart, strPARM_NAME)
                    Dim update_row_count = Assistant.Update_Parm_Value(new_parm_row, strPARM_PATH)
                End If
            Next strPARM_NAME

            Add_Defaults_for_missing_DeveloperSettings = found_row_count
        End Function 'Add_Defaults_for_missing_DeveloperSettings

        Public Shared Function Reset_Rows_in_Grid(ur_grid As dbUserInput.componentDataGridView, ur_newval_tbox As dbUserInput.componentTextBox, ur_customapp_parm_cart As Have.sCustomAppParm) As Integer
            Dim retROW_COUNT = 0
            Dim update_tbox_count = Assistant.Update_Tbox_disabled(ur_newval_tbox)
            Call ur_grid.Rows.Clear()
            ur_newval_tbox.Text = mt
            For Each kvpENTRY In ur_customapp_parm_cart.SelAll.kvp
                retROW_COUNT += 1
                Dim new_row_num = Assistant.Add_Row_to_Grid(ur_grid, kvpENTRY.row)
                If (kvpENTRY.Indexb1 = 1) Then
                    Dim navigated_row_count = Assistant.Navigate_Grid_current_row(ur_grid, 1)
                    Dim overwrite_row_count = Assistant.Overwrite_text_RowValue(ur_newval_tbox, kvpENTRY.row)
                End If
            Next kvpENTRY

            Call ur_grid.Select()
            update_tbox_count = Assistant.Update_Tbox_enabled(ur_newval_tbox)
            Reset_Rows_in_Grid = retROW_COUNT
        End Function 'Reset_Rows_in_Grid

        Public Shared Function Search_for_AppConfig_Path(ur_appconfig_cart As Have.sAppConfigSettings, ur_parm_name As String, ur_userbowl_cart As Have.sUserBowl, ur_appfolder_bolwname As enmUN.zapp_folder, ur_windowsfs_env As Have.glblWindowsFS) As String
            Search_for_AppConfig_Path = mt
            For Each trwKEY_LIST In ur_appconfig_cart.Sel(enmAKV.setting_name, ur_parm_name).SelAll
                Dim flnPARM_PATH = FileNamed().d(ur_userbowl_cart.SelKey(ur_appfolder_bolwname).Contents)
                flnPARM_PATH.d(trwKEY_LIST.v(enmAKV.setting_value))
                For Each strFILE_PATH In ur_windowsfs_env.GetFiles(flnPARM_PATH)
                    Search_for_AppConfig_Path = strFILE_PATH
                Next
            Next trwKEY_LIST
        End Function 'Search_for_AppConfig_Path

        Public Shared Function Show_DeveloperSettings_Path(ur_file_path_tbox As dbUserInput.componentTextBox, ur_userbowl_cart As Have.sUserBowl, ur_persist_path_bowlname As enmUN.zpersist_path) As Integer
            Show_DeveloperSettings_Path = 0
            If ur_file_path_tbox IsNot Nothing Then
                Show_DeveloperSettings_Path = 1
                ur_file_path_tbox.Text = ur_userbowl_cart.SelKey(ur_persist_path_bowlname).Contents
            End If
        End Function 'Show_DeveloperSettings_Path

        Public Shared Function Store_DeveloperSettings_Path(ur_windows_envvar_env As Have.glblEnvironment, ur_userbowl_cart As Have.sUserBowl, ur_persist_path_bowlname As enmUN.zpersist_path) As Integer
            Store_DeveloperSettings_Path = 1
            Dim flnPERSIST = FileNamed().d(ur_windows_envvar_env.ExpandEnvironmentVariables("%APPDATA%")).d("DeveloperCustomApp_settings").d("user.config.tsv")
            ur_userbowl_cart.SelKey(ur_persist_path_bowlname).Contents = flnPERSIST
        End Function ' Store_DeveloperSettings_Path

        Public Shared Function Store_HelpFile_Path(ur_userbowl_cart As Have.sUserBowl, ur_helpfile_path_bowlname As enmUN.zhelpfile_path) As Integer
            Store_HelpFile_Path = 1
            Dim strHELP_FILE_PATH = "Developer Settings App.html"
            ur_userbowl_cart.SelKey(ur_helpfile_path_bowlname).Contents = strHELP_FILE_PATH
        End Function 'Store_HelpFile_Path

        Public Shared Function Remove_Parm_from_Cart(ur_customapp_parm_cart As Have.sCustomAppParm, ur_parm_row As Have.rCustomAppParm) As Integer
            Remove_Parm_from_Cart = 0
            If ur_parm_row IsNot Nothing Then
                Remove_Parm_from_Cart = 1
                ur_customapp_parm_cart.Del(ur_parm_row)
            End If 'ur_parm_row
        End Function 'Remove_Parm_from_Cart

        Public Shared Function Update_CustomAppParm_File(ur_customapp_parm_cart As Have.sCustomAppParm, ur_userbowl_cart As Have.sUserBowl, ur_persist_path As enmUN.zpersist_path) As Integer
            Update_CustomAppParm_File = 1
            Dim strPERSIST_PATH = Have.UserBowl.SelKey(ur_persist_path).Contents
            Dim tblSORTED_CUSTOMAPP = New Have.sCustomAppParm
            Dim sdaKEY_LIST = ur_customapp_parm_cart.SelDistinct(enmSNV.setting_name)
            sdaKEY_LIST.Sort()
            For Each strKEY In sdaKEY_LIST
                tblSORTED_CUSTOMAPP.Ins(ur_customapp_parm_cart.SelKey(strKEY))
            Next

            Call tblSORTED_CUSTOMAPP.PersistWrite(strPERSIST_PATH)
        End Function

        Public Shared Function Update_GridRow_Value(ur_grid As dbUserInput.componentDataGridView, ur_parm_row As Have.rCustomAppParm) As Integer
            Update_GridRow_Value = 0
            If ur_parm_row IsNot Nothing Then
                For ROWCTR = b0(1) To b0(ur_grid.Rows.Count)
                    Dim rowENTRY = ur_grid.Rows(ROWCTR).Cells
                    If AreEqual(CType(rowENTRY.Item(b0(1)).Value, String), ur_parm_row.v(enmSNV.setting_name)) Then
                        Update_GridRow_Value = 1
                        rowENTRY.Item(b0(2)).Value = ur_parm_row.v(enmSNV.setting_value)
                        Exit For
                    End If
                Next ROWCTR
            End If 'ur_new_parm
        End Function 'Update_GridRow_Value

        Public Shared Function Update_SaveAllBtn_enabled(ur_saveall_btn As dbUserInput.componentButton, ur_parm_row As Have.rCustomAppParm) As Integer
            Update_SaveAllBtn_enabled = 0
            If ur_parm_row IsNot Nothing Then
                Update_SaveAllBtn_enabled = 1
                ur_saveall_btn.Enabled = True
            End If
        End Function 'Update_SaveAllBtn_enabled

        Public Shared Function Update_Button_enabled(ur_btn As dbUserInput.componentButton) As Integer
            Update_Button_enabled = 0
            If ur_btn.Enabled = False Then
                Update_Button_enabled = 1
                ur_btn.Enabled = True
            End If
        End Function 'Update_Button_enabled

        Public Shared Function Update_Tbox_enabled(ur_tbox As dbUserInput.componentTextBox) As Integer
            Update_Tbox_enabled = 0
            If ur_tbox.Enabled = False Then
                Update_Tbox_enabled = 1
                ur_tbox.Enabled = True
            End If
        End Function 'Update_Tbox_enabled

        Public Shared Function Update_Button_disabled(ur_btn As dbUserInput.componentButton) As Integer
            Update_Button_disabled = 0
            If ur_btn.Enabled = True Then
                Update_Button_disabled = 1
                ur_btn.Enabled = False
            End If
        End Function 'Update_Button_disabled

        Public Shared Function Update_Tbox_disabled(ur_tbox As dbUserInput.componentTextBox) As Integer
            Update_Tbox_disabled = 0
            If ur_tbox.Enabled = True Then
                Update_Tbox_disabled = 1
                ur_tbox.Enabled = False
            End If
        End Function 'Update_Tbox_disabled

        Public Shared Function Update_Parm_Value(ur_parm_row As Have.rCustomAppParm, ur_new_value As String) As Integer
            Update_Parm_Value = 0
            If ur_parm_row IsNot Nothing Then
                Update_Parm_Value = 0
                ur_parm_row.v(enmSNV.setting_value) = ur_new_value
            End If 'ur_new_parm
        End Function 'Update_Parm_Value

        Public Shared Function Update_Parm_Value(ur_parm_row As Have.rCustomAppParm, ur_newval_tbox As dbUserInput.componentTextBox) As Integer
            Update_Parm_Value = 0
            If ur_parm_row IsNot Nothing Then
                Update_Parm_Value = 1
                ur_parm_row.v(enmSNV.setting_value) = ur_newval_tbox.Text
            End If 'ur_new_parm
        End Function 'Update_Parm_Value
    End Class 'Assistant

    Partial Public Class Have
        Private Shared tblAppConfigSettings As sAppConfigSettings
        Private Shared envAppExternal As glblAppExternal
        Private Shared envWindowsEnvVar As glblEnvironment
        Private Shared envWindowsFS As glblWindowsFS
        Private Shared envWindowsInputBox As glblWindowsInputBox
        Private Shared envWindowsMsgBox As glblWindowsMsgBox
        Private Shared tblPersistSetting As sCustomAppParm
        Private Shared tblUserBowl As sUserBowl

        <System.Diagnostics.DebuggerHidden()>
        Private Shared Sub Connect()
            If Have.tblUserBowl Is Nothing Then
                Have.tblAppConfigSettings = New sAppConfigSettings
                Have.envAppExternal = New glblAppExternal
                Have.envWindowsEnvVar = New glblEnvironment
                Have.envWindowsFS = New glblWindowsFS
                Have.envWindowsInputBox = New glblWindowsInputBox
                Have.envWindowsMsgBox = New glblWindowsMsgBox
                Have.tblUserBowl = New sUserBowl
                Have.tblPersistSetting = New sCustomAppParm
            End If
        End Sub 'Connect
    End Class 'Have

    Public Class enmAKV
        Inherits bitBASE
        Public Shared setting_name As enmAKV = TRow(Of enmAKV).glbl.NewBitBase()
        Public Shared setting_value As enmAKV = TRow(Of enmAKV).glbl.NewBitBase()
    End Class

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function AppConfigSettings() As sAppConfigSettings
            Call Have.Connect()
            AppConfigSettings = Have.tblAppConfigSettings
        End Function

        Public Class rAppConfigSettings
            Inherits TRow(Of enmAKV)
        End Class

        Public Class sAppConfigSettings
            Inherits TablePKStr(Of enmAKV, rAppConfigSettings)

            Public Sub New()
                Call MyBase.New(1)
                Dim objAPP_SETTINGS = Mx.glbl.gConfigSettings.AppSettings
                For KEYCTR = 0 To objAPP_SETTINGS.Keys.Count - 1
                    Dim strKEY = objAPP_SETTINGS.Keys.Item(KEYCTR)
                    Dim trwNEW_SETTING = Me.InsKey(strKEY)
                    trwNEW_SETTING.v(enmAKV.setting_value) = objAPP_SETTINGS.Item(strKEY)
                Next KEYCTR
            End Sub 'New
        End Class 'glblAppConfigSettings
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function AppExternal() As glblAppExternal
            Call Have.Connect()
            AppExternal = Have.envAppExternal
        End Function

        Public Class glblAppExternal
            Public Sub Start_Windows_Program(ur_exec_path As String, ur_exec_param As String)
                Call Mx.glbl.gDiagnostics.Start_Windows_Program(ur_exec_path, ur_exec_param)
            End Sub
        End Class 'glblAppExternal
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsEnvVar() As glblEnvironment
            Call Have.Connect()
            WindowsEnvVar = Have.envWindowsEnvVar
        End Function

        Public Class glblEnvironment
            Public Function ExpandEnvironmentVariables(ur_path As String) As String
                ExpandEnvironmentVariables = Mx.glbl.gEnvironment.ExpandEnvironmentVariables(ur_path)
            End Function
        End Class 'glblEnvironment
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsInputBox() As glblWindowsInputBox
            Call Have.Connect()
            WindowsInputBox = Have.envWindowsInputBox
        End Function

        Public Class glblWindowsInputBox
            Public Function GetResult(ur_message As String, ur_default_value As String) As String
                Dim strAPP_NAME = Have.UserBowl.SelKey(enmUN.app_name).Contents
                GetResult = Mx.glbl.gInputBox.GetResult(ur_message, strAPP_NAME, ur_default_value)
            End Function
        End Class 'glblWindowsInputBox
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsMsgBox() As glblWindowsMsgBox
            Call Have.Connect()
            WindowsMsgBox = Have.envWindowsMsgBox
        End Function

        Public Class glblWindowsMsgBox
            Public Function GetResult(ur_message As String, ur_style As MsgBoxStyle) As MsgBoxResult
                Dim strAPP_NAME = Have.UserBowl.SelKey(enmUN.app_name).Contents
                GetResult = Mx.glbl.gMsgBox.GetResult(ur_message, ur_style, strAPP_NAME)
            End Function
        End Class 'glblWindowsMsgBox
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsFS() As glblWindowsFS
            Call Have.Connect()
            WindowsFS = Have.envWindowsFS
        End Function

        Public Class glblWindowsFS
            Public Function GetFiles(ur_search_filespec As MxText.FileName, Optional ur_recurse_option As System.IO.SearchOption = System.IO.SearchOption.TopDirectoryOnly) As String()
                Try
                    GetFiles = Mx.glbl.gWindowsFS.GetFiles(ur_search_filespec.gParentDir, ur_search_filespec.Name, ur_recurse_option)
                Catch ex As System.Exception
                    GetFiles = {}
                End Try
            End Function
        End Class 'glblWindowsFS
    End Class 'Have


    Public Class enmSNV
        Inherits bitBASE
        Public Shared setting_name As enmSNV = TRow(Of enmSNV).glbl.NewBitBase()
        Public Shared setting_value As enmSNV = TRow(Of enmSNV).glbl.NewBitBase()
    End Class

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function CustomAppParm() As sCustomAppParm
            Call Have.Connect()
            CustomAppParm = Have.tblPersistSetting
        End Function 'CustomApp

        Public Class rCustomAppParm
            Inherits TRow(Of enmSNV)
        End Class

        Public Class sCustomAppParm
            Inherits TablePKStr(Of enmSNV, rCustomAppParm)

            Public Sub New()
                Call MyBase.New(1)
            End Sub
        End Class 'sCustomAppParm
    End Class 'enmSNV

    Public Class enmUB
        Inherits bitBASE
        Public Shared bowl_name As enmUB = TRow(Of enmUB).glbl.NewBitBase()
        Public Shared contents As enmUB = TRow(Of enmUB).glbl.NewBitBase()
    End Class

    Public Class enmUN
        Inherits bitBASE
        Public Shared app_folder As zapp_folder = TRow(Of enmUN).glbl.Trbase(Of zapp_folder).NewBitBase() : Public Class zapp_folder : Inherits enmUN : End Class
        Public Shared app_name As zapp_name = TRow(Of enmUN).glbl.Trbase(Of zapp_name).NewBitBase() : Public Class zapp_name : Inherits enmUN : End Class
        Public Shared app_path As zapp_path = TRow(Of enmUN).glbl.Trbase(Of zapp_path).NewBitBase() : Public Class zapp_path : Inherits enmUN : End Class
        Public Shared cmdline_audit As zcmdline_audit = TRow(Of enmUN).glbl.Trbase(Of zcmdline_audit).NewBitBase() : Public Class zcmdline_audit : Inherits enmUN : End Class
        Public Shared cmdline_orig As zcmdline_orig = TRow(Of enmUN).glbl.Trbase(Of zcmdline_orig).NewBitBase() : Public Class zcmdline_orig : Inherits enmUN : End Class
        Public Shared cmdline_table As zcmdline_table = TRow(Of enmUN).glbl.Trbase(Of zcmdline_table).NewBitBase() : Public Class zcmdline_table : Inherits enmUN : End Class
        Public Shared helpfile_path As zhelpfile_path = TRow(Of enmUN).glbl.Trbase(Of zhelpfile_path).NewBitBase() : Public Class zhelpfile_path : Inherits enmUN : End Class
        Public Shared persist_path As zpersist_path = TRow(Of enmUN).glbl.Trbase(Of zpersist_path).NewBitBase() : Public Class zpersist_path : Inherits enmUN : End Class
    End Class 'enmUN

    Partial Public Class Have
        Public Shared objAPP_CONFIG As dbConfigInput

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function UserBowl() As sUserBowl
            Dim bolFIRST_INIT = (Have.tblUserBowl Is Nothing)
            Call Have.Connect()
            UserBowl = Have.tblUserBowl
            If bolFIRST_INIT Then
                Call Have.tblUserBowl.Ins_CommandLine(System.Reflection.Assembly.GetExecutingAssembly, System.Environment.CommandLine)
                'Have.tblUserBowl.InsKey(enmUN.cmdline_audit, "1")
                Call Have.tblUserBowl.Cboard_CmdlineAudit()
            End If
        End Function 'UserBowl

        Public Class rUserBowl
            Inherits TRow(Of enmUB)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmUB, ur_val As String) As rUserBowl
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Property Contents() As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Contents = Me.v(enmUB.contents)
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(ur_val As String)
                    Me.v(enmUB.contents) = ur_val
                End Set
            End Property
        End Class 'rUserBowl

        Public Class sUserBowl
            Inherits TablePKEnum(Of enmUB, enmUN, rUserBowl)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub Cboard_CmdlineAudit()
                If HasText(Me.SelKey(enmUN.cmdline_audit).Contents) Then
                    Dim strAUDIT = Me.ToString(True)
                    If MsgBox(strAUDIT, MsgBoxStyle.OkCancel, Me.SelKey(enmUN.app_name).Contents) = MsgBoxResult.Ok Then
                        My.Computer.Clipboard.SetText(strAUDIT)
                    End If
                End If
            End Sub 'Cboard_CmdlineAudit

            <System.Diagnostics.DebuggerHidden()>
            Public Function Ins_CommandLine(ur_assembly_path As System.Reflection.Assembly, ur_command_line As String) As sUserBowl
                Ins_CommandLine = Me
                Dim flnAPP_PATH = FileNamed().d(ur_assembly_path.Location.Replace("\bin\Debug", ""))
                Me.SelKey(enmUN.app_path).vt(enmUB.contents, flnAPP_PATH)
                Me.SelKey(enmUN.app_name).vt(enmUB.contents, flnAPP_PATH.FileGroup)
                Me.SelKey(enmUN.app_folder).vt(enmUB.contents, flnAPP_PATH.gParentDir)

                Dim arlCMD_RET = MxText.Cmdline_UB(Of enmUN, enmUB).CommandLine_UBParm(enmUB.bowl_name, enmUB.contents, ur_command_line)
                Me.SelKey(enmUN.cmdline_orig).vt(enmUB.contents, qs & System.Environment.CommandLine.Replace(qs, qs & qs) & qs)
                Me.SelKey(enmUN.cmdline_table).vt(enmUB.contents, qs & arlCMD_RET.ttbCMD_PARM.ToString(True).Replace(qs, qs & qs) & qs)
                For Each rowFOUND In arlCMD_RET.ttbUB_PARM
                    For Each enmKEY In TRow(Of enmUN).glbl.RefKeySearch(rowFOUND.v(enmUB.bowl_name))
                        Me.SelKey(enmKEY).Contents = rowFOUND.v(enmUB.contents)
                    Next
                Next rowFOUND

                'Me.SelKey(enmUN.script_path).Contents = Mx.Class1.SourcePath
                'Dim flnSCRIPT_PATH = FileNamed().d(Mx.Class1.SourceFolder).gFullPath
                'If AreEqual(flnSCRIPT_PATH.Name, "Debug") Then
                '    flnSCRIPT_PATH = flnSCRIPT_PATH.gParentDir
                'End If
                'If AreEqual(flnSCRIPT_PATH.Name, "bin") Then
                '    flnSCRIPT_PATH = flnSCRIPT_PATH.gParentDir
                'End If

                'Me.SelKey(enmUN.script_folder).Contents = flnSCRIPT_PATH
            End Function 'Ins_CommandLine

            <System.Diagnostics.DebuggerHidden()>
            Public Function ToCbrd(ur_hdr As Boolean) As Integer
                ToCbrd = Mx.glbl.gCboard.SetText(Me.ToString(ur_hdr))
            End Function
        End Class 'sUserBowl
    End Class 'UB, UN

    Partial Class glbl
        Public Class gInputBox
            <System.Diagnostics.DebuggerHidden()>
            Public Shared Function GetResult(ur_message As String, ur_title As String, ur_default_value As String) As String
                GetResult = InputBox(ur_message, ur_title, ur_default_value)
            End Function
        End Class 'gInputBox

        Public Class gConfigSettings
            Public Shared Function AppSettings() As dbConfigInput
                AppSettings = Have.objAPP_CONFIG
            End Function
        End Class 'gConfigSettings
    End Class 'glbl
End Namespace 'Mx