﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox(Mx.UserAction.Roman_Numeral_Conversion_Report())
        Me.Close()
    End Sub
End Class
