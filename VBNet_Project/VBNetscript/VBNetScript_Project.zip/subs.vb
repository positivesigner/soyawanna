﻿Option Strict On
Namespace Mx
    Public Class Want
        Public Shared Sub Compile_And_Run_Script_errhnd(ur_form As dbUserInput, ur_command_text As String)
            Have.CmdLineText = ur_command_text
            Dim windowscboard_env = Have.WindowsCboard
            Dim windowsmsgbox_env = Have.WindowsMsgBox
            Dim objERR_LIST = New ErrListBase : Try
                Call Assistant.Compile_And_Run_Script(ur_form)

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                MsgBox(objERR_LIST.ToString, , My.Application.Info.Title)
                Call Assistant.Show_CommandLine_Options(windowsmsgbox_env, windowscboard_env)
                Call ur_form.Close()
            End If
        End Sub 'Compile_And_Run_Script_errhnd
    End Class 'Want


    Public Class Assistant
        Public Shared Sub Compile_And_Run_Script(ur_form As dbUserInput)
            Dim windowsmsgbox_env = Have.WindowsMsgBox
            Dim userbowl_cart = Have.UserBowl
            Dim strEXPORT_PROJECT_CODE_PATH = userbowl_cart.SelKey(enmUN.cmd_export_project_code).Contents
            If HasText(strEXPORT_PROJECT_CODE_PATH) Then
                Call Assistant.Export_Project_Code(ur_form, userbowl_cart, windowsmsgbox_env)

            Else
                Dim input_path_bowlname = enmUN.path
                Dim app_folder_bowlname = enmUN.app_folder
                Dim script_path_bowlname = userbowl_cart.Apply(input_path_bowlname, app_folder_bowlname)
                Dim form_title_bowlname = userbowl_cart.Apply(script_path_bowlname, ur_form)
                Dim report_output_bowlname = userbowl_cart.Apply(script_path_bowlname, app_folder_bowlname)
                Dim window_color_bowlname = userbowl_cart.Apply(report_output_bowlname)
                Dim form_close_bowlname = userbowl_cart.Apply(report_output_bowlname, window_color_bowlname, ur_form)
            End If
        End Sub 'Compile_And_Run_Script

        Public Shared Sub Export_Project_Code(ur_form As dbUserInput, ur_userbowl_cart As Have.sUserBowl, ur_windowsmsgbox_env As Have.glblWindowsMsgBox)
            Dim strPROJECT_FILE = "VBNetScript_Project.zip"
            Dim strRESOURCE_FILE = mt
            Dim objASSEMBLY = System.Reflection.Assembly.GetExecutingAssembly
            For Each strENTRY In objASSEMBLY.GetManifestResourceNames()
                If EndingWithText(strENTRY, strPROJECT_FILE) Then
                    strRESOURCE_FILE = strENTRY
                    Exit For
                End If
            Next strENTRY

            If HasText(strRESOURCE_FILE) = False Then
                Throw New System.Exception(Strapd().d("Cannot find resource:").dS(strPROJECT_FILE))
            Else
                Dim flnDEST_PATH = FileNamed().d(ur_userbowl_cart.SelKey(enmUN.app_folder).Contents).d(strPROJECT_FILE)
                Dim enrUSER_INPUT = ur_windowsmsgbox_env.GetResult(
                    ur_title:=ur_userbowl_cart.SelKey(enmUN.app_name).Contents,
                    ur_message:=Strapd().d("Export VBNetScript_Project.zip file to").dS(qs).d(flnDEST_PATH).d(qs).d("?"),
                    ur_style:=MsgBoxStyle.OkCancel
                    )
                If enrUSER_INPUT = MsgBoxResult.Ok Then
                    Using objRESOURCE = objASSEMBLY.GetManifestResourceStream(strRESOURCE_FILE)
                        Using objFILE = New System.IO.FileStream(flnDEST_PATH, System.IO.FileMode.Create, System.IO.FileAccess.Write)
                            objRESOURCE.CopyTo(objFILE)
                        End Using
                    End Using
                End If

                ur_form.Close()
            End If
        End Sub 'Export_Project_Code

        Public Shared Sub Show_CommandLine_Options(ur_windowsmsgbox_env As Have.glblWindowsMsgBox, ur_windowscboard_env As Have.glblWindowsCboard)
            Dim stpHELP = Strapd()
            With stpHELP
                .d("VBNetScript.exe /path=").dSprtr(qs, "UrCodeFile.vbns").d(qs).dLine()
                .dLine()
                .dLine("/path specifies a code file in this format:")
                .dLine()
                .dLine("[Input File Format]")
                .dLine("* At the start of the file, there are several Windows Command Line commands that are skipped:")
                .dLine()
                .dLine("Skipped - start-prefixed lines")
                .dLine("Skipped - cd-prefixed lines")
                .dLine("Skipped - rem-prefixed lines")
                .dLine("Skipped - exit-prefixed lines")
                .dLine("Skipped - @-prefixed lines")
                .dLine("Skipped - Blank lines")
                .dLine()
                .dLine("* The first line that does not match the above skipped lines may be a .DLL file")
                .dLine()
                .dLine("Optional - UrRef.dll")
                .dLine()
                .dLine("* The first line that does not end in .DLL may be an included .VB file")
                .dLine()
                .dLine("Optional - UrInclude.vb")
                .dLine()
                .dLine("* The first line that does not end in .VB may be an OPTION command")
                .dLine()
                .dLine("Optional - , or some other Option On/Off")
                .dLine()
                .dLine("* The first line that does not start with OPTIONAL may be an IMPORTS command")
                .dLine()
                .dLine("Optional - Imports UrNamespace")
                .dLine()
                .dLine("* The first line that does not start with IMPORTS is assumed to be a VB.Net code line")
                .dLine("* Note: The program automatically adds these lines before your first code line")
                .dLine()
                .dLine("Added - NameSpace Mx")
                .dLine("Added - Class Class1")
                .dLine("Added - Function RetVal() As String")
                .dLine()
                .dLine("Required - UrCodeLines")
                .dLine()
                .dLine("* If you assign a value to the RetVal variable, it will show in a multi-line textbox")
                .dLine("    * Unless you assign the value RED or GREEN, which will cause the border to change color")
                .dLine("    * Or you assign the value QUIT, which will not show a Windows Form at all")
                .dLine()
                .dLine("You can add any further VB.Net code lines, including ending the default Function name, Class name and Namespace name and adding others")
                .dLine()
                .dLine("Optional - End Function")
                .dLine("Optional - More Functions and Subs")
                .dLine("Optional - End Class")
                .dLine("Optional - More Classes")
                .dLine("Optional - End Namespace")
                .dLine("Optional - More Namespaces")
                .dLine()
                .dLine("VBNetScript.exe /cmd_export_cmdline_audit=True")
                .dLine()
                .dLine("/cmd_export_cmdline_audit will show the command-line audit table in a message box, and then allow you to copy the table to the clipboard")
                .dLine()
                .dLine("VBNetScript.exe /cmd_export_project_code=True")
                .dLine()
                .dLine("/cmd_export_project_code will ask for a folder in which to save the VBNetScript Project .ZIP file")
                .dLine()
                .dLine("* Note: Command-line parameters may not work in .lnk Windows Shortcut files. Please call from a .cmd file to test.")
                .dLine()
            End With 'stpHELP
            Dim enrUSER_INPUT = ur_windowsmsgbox_env.GetResult(
                ur_title:="VBNetScript",
                ur_message:=stpHELP,
                ur_style:=MsgBoxStyle.OkCancel
                )

            If enrUSER_INPUT = MsgBoxResult.Ok Then
                ur_windowscboard_env.SetText(
                    stpHELP
                    )
            End If
        End Sub 'Show_CommandLine_Options
    End Class 'Assistant

    Public Class Have
        Partial Class sUserBowl
            Public Function Apply(ur_in_path As enmUN.zpath, ur_app_folder As enmUN.zapp_folder) As enmUN.zscript_path
                Dim retKEY = enmUN.script_path
                Apply = retKEY
                Dim script_path = Me.SelKey(retKEY)
                Dim strFOUND_PATH = Me.SelKey(ur_in_path).Contents
                If HasText(strFOUND_PATH) = False Then
                    Throw New System.Exception(Strapd().d("Script file not provided."))

                ElseIf glbl.gWindowsFS.HasFile(strFOUND_PATH) = False Then
                    Dim flnAPP_RELATIVE = FileNamed().d(Me.SelKey(ur_app_folder).Contents).d(strFOUND_PATH)
                    If glbl.gWindowsFS.HasFile(flnAPP_RELATIVE) = False Then
                        Throw New System.Exception(Strapd().d("Script file not found:").dS(strFOUND_PATH))

                    Else
                        script_path.Contents = flnAPP_RELATIVE
                    End If

                Else
                    script_path.Contents = strFOUND_PATH
                End If
            End Function 'Apply(ur_in_path

            Public Function Apply(ur_script_path As enmUN.zscript_path, ur_form1 As dbUserInput) As enmUN.zform_title
                Dim retKEY = enmUN.form_title
                Apply = retKEY
                Dim strFORM_TITLE = Me.SelKey(ur_script_path).Contents
                ur_form1.Text = strFORM_TITLE
                Me.SelKey(retKEY).Contents = strFORM_TITLE
            End Function

            Public Function Apply(ur_script_path As enmUN.zscript_path, ur_app_folder As enmUN.zapp_folder) As enmUN.zreport_output
                Dim retKEY = enmUN.report_output
                Apply = retKEY
                retKEY = enmUN.report_output
                Dim report_output = Me.SelKey(retKEY)
                Dim strSCRIPT_PATH = Me.SelKey(ur_script_path).Contents
                If HasText(strSCRIPT_PATH) Then
                    Dim strREPORT_OUTPUT = Mx.ScriptRun.RunCode(Mx.ScriptRun.enmC_V_J.VisualBasic, strSCRIPT_PATH, Me.SelKey(ur_app_folder).Contents)
                    report_output.Contents = strREPORT_OUTPUT
                End If
            End Function 'Apply(ur_script_path

            Public Function Apply(ur_report_output As enmUN.zreport_output, ur_background_color As enmUN.zbackground_color, ur_form1 As dbUserInput) As enmUN.zwindow_status
                Dim retKEY = enmUN.window_status
                Apply = retKEY
                Dim bitSTATUS = enmUR_Status.Show
                Dim flgSHOW_FORM = True
                Dim strNOTICE_MSG = Me.SelKey(ur_report_output).Contents.Trim
                If StartingWithText(strNOTICE_MSG, "Quit") = False Then
                    Dim trwBG_COLOR = Me.SelKey(ur_background_color)
                    If trwBG_COLOR.v_is(enmUR_Color.Clear) = False Then
                        ur_form1.BackColor = trwBG_COLOR.Background_Color_of_Form
                    End If

                    ur_form1.txtNotice_Message.Text = strNOTICE_MSG

                Else
                    bitSTATUS = enmUR_Status.Close
                    Call ur_form1.Close()
                End If

                Me.SelKey(retKEY).Contents = bitSTATUS.name
            End Function 'Apply(ur_report_output, ur_background_color

            Public Function Apply(ur_report_output As enmUN.zreport_output) As enmUN.zbackground_color
                Dim retKEY = enmUN.background_color
                Apply = retKEY
                retKEY = enmUN.background_color
                Dim bitCOLOR = enmUR_Color.Clear
                Dim strNOTICE_MSG = Me.SelKey(ur_report_output).Contents.Trim
                If StartingWithText(strNOTICE_MSG, "RED") Then
                    bitCOLOR = enmUR_Color.Red

                ElseIf StartingWithText(strNOTICE_MSG, "GREEN") Then
                    bitCOLOR = enmUR_Color.Green
                End If

                Me.SelKey(retKEY).Background_Color = bitCOLOR
            End Function 'Apply(ur_bowl_key
        End Class 'sUserBowl
    End Class 'Have


    Partial Public Class Have
        Private Shared envWindowsCboard As glblWindowsCboard
        Private Shared envWindowsMsgBox As glblWindowsMsgBox
        Private Shared tblUserBowl As sUserBowl

        <System.Diagnostics.DebuggerHidden()>
        Private Shared Sub Connect()
            If Have.tblUserBowl Is Nothing Then
                Have.envWindowsCboard = New glblWindowsCboard
                Have.envWindowsMsgBox = New glblWindowsMsgBox
                Have.tblUserBowl = New sUserBowl
            End If 'sdaTCOL_NAME
        End Sub 'Connect
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsCboard() As glblWindowsCboard
            Call Have.Connect()
            WindowsCboard = Have.envWindowsCboard
        End Function

        Public Class glblWindowsCboard
            Public Function SetText(ur_text As String) As Integer
                SetText = glbl.gCboard.SetText(ur_text)
            End Function
        End Class 'glblWindowsCboard
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsMsgBox() As glblWindowsMsgBox
            Call Have.Connect()
            WindowsMsgBox = Have.envWindowsMsgBox
        End Function

        Public Class glblWindowsMsgBox
            Public Function GetResult(ur_message As String, ur_title As String, ur_style As MsgBoxStyle) As MsgBoxResult
                GetResult = glbl.gMsgBox.GetResult(ur_message, ur_style, ur_title)
            End Function
        End Class 'glblWindowsMsgBox
    End Class 'Have

    Public Class enmUB
        Inherits bitBASE
        Public Shared bowl_name As enmUB = TRow(Of enmUB).glbl.NewBitBase()
        Public Shared contents As enmUB = TRow(Of enmUB).glbl.NewBitBase()
    End Class

    Public Class enmUN
        Inherits bitBASE
        Public Shared app_folder As zapp_folder = TRow(Of enmUN).glbl.Trbase(Of zapp_folder).NewBitBase() : Public Class zapp_folder : Inherits enmUN : End Class
        Public Shared app_name As enmUN = TRow(Of enmUN).glbl.NewBitBase()
        Public Shared app_path As enmUN = TRow(Of enmUN).glbl.NewBitBase()
        Public Shared background_color As zbackground_color = TRow(Of enmUN).glbl.Trbase(Of zbackground_color).NewBitBase() : Public Class zbackground_color : Inherits enmUN : End Class
        Public Shared cmdline_orig As enmUN = TRow(Of enmUN).glbl.NewBitBase()
        Public Shared cmdline_table As enmUN = TRow(Of enmUN).glbl.NewBitBase()
        Public Shared cmd_export_cmdline_audit As enmUN = TRow(Of enmUN).glbl.NewBitBase()
        Public Shared cmd_export_project_code As enmUN = TRow(Of enmUN).glbl.NewBitBase()
        Public Shared compiler_exe As enmUN = TRow(Of enmUN).glbl.NewBitBase()
        Public Shared form_title As zform_title = TRow(Of enmUN).glbl.Trbase(Of zform_title).NewBitBase() : Public Class zform_title : Inherits enmUN : End Class
        Public Shared path As zpath = TRow(Of enmUN).glbl.Trbase(Of zpath).NewBitBase() : Public Class zpath : Inherits enmUN : End Class
        Public Shared script_path As zscript_path = TRow(Of enmUN).glbl.Trbase(Of zscript_path).NewBitBase() : Public Class zscript_path : Inherits enmUN : End Class
        Public Shared report_output As zreport_output = TRow(Of enmUN).glbl.Trbase(Of zreport_output).NewBitBase() : Public Class zreport_output : Inherits enmUN : End Class
        Public Shared window_status As zwindow_status = TRow(Of enmUN).glbl.Trbase(Of zwindow_status).NewBitBase() : Public Class zwindow_status : Inherits enmUN : End Class
    End Class

    Public Class enmUR_Color
        Inherits bitBASE
        Public Shared Clear As enmUR_Color = TRow(Of enmUR_Color).glbl.NewBitBase()
        Public Shared Green As enmUR_Color = TRow(Of enmUR_Color).glbl.NewBitBase()
        Public Shared Red As enmUR_Color = TRow(Of enmUR_Color).glbl.NewBitBase()
    End Class

    Public Class enmUR_Status
        Inherits bitBASE
        Public Shared Show As enmUR_Status = TRow(Of enmUR_Status).glbl.NewBitBase()
        Public Shared Close As enmUR_Status = TRow(Of enmUR_Status).glbl.NewBitBase()
    End Class

    Partial Public Class Have
        Public Shared FirstConnect As Object
        Public Shared CmdLineText As String

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function UserBowl() As sUserBowl
            Dim bolFIRST_INIT = (Have.FirstConnect Is Nothing)
            Call Have.Connect()
            UserBowl = Have.tblUserBowl
            If bolFIRST_INIT Then
                Have.FirstConnect = "Done"
                Call Have.tblUserBowl.InsFrom_Application()
                'db.tblUserBowl.InsKey(enmUN.cmdline_audit, "1")
                Call Have.tblUserBowl.Cboard_CmdlineAudit(Have.WindowsMsgBox, Have.WindowsCboard)
            End If
        End Function

        Public Class rUserBowl
            Inherits TRow(Of enmUB)
            Private enrBackground_Color As System.Drawing.Color
            Private enrUR_Color As enmUR_Color

            Public ReadOnly Property Background_Color_of_Form As System.Drawing.Color
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Background_Color_of_Form = Me.enrBackground_Color
                End Get
            End Property 'Background_Color_of_Form

            Public Property Background_Color As enmUR_Color
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Background_Color = Me.enrUR_Color
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(value As enmUR_Color)
                    Dim intCOLOR = System.Drawing.Color.Transparent
                    If value Is enmUR_Color.Red Then
                        intCOLOR = System.Drawing.Color.Red

                    ElseIf value Is enmUR_Color.Green Then
                        intCOLOR = System.Drawing.Color.Green
                    End If

                    Me.enrBackground_Color = intCOLOR
                    Me.enrUR_Color = value
                    Me.v(enmUB.contents) = value.name
                End Set
            End Property 'Contents

            Public Property Contents As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Contents = Me.v(enmUB.contents)
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(value As String)
                    Me.v(enmUB.contents) = value
                End Set
            End Property 'Contents

            <System.Diagnostics.DebuggerHidden()>
            Public Function v_bowlname_is(ur_cmp As enmUN) As Boolean
                v_bowlname_is = AreEqual(Me.v(enmUB.bowl_name), ur_cmp.name)
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function v_is(ur_cmp As enmUR_Color) As Boolean
                v_is = AreEqual(Me.Contents, ur_cmp.name)
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmUB, ur_val As String) As rUserBowl
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rUserBowl

        Public Class sUserBowl
            Inherits Mx.TablePKEnum(Of enmUB, enmUN, rUserBowl)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub Cboard_CmdlineAudit(ur_windowsmsgbox_env As Have.glblWindowsMsgBox, ur_windowscboard_env As Have.glblWindowsCboard)
                If HasText(Me.SelKey(enmUN.cmd_export_cmdline_audit).v(enmUB.contents)) Then
                    Dim strAUDIT = Me.ToString(True)
                    Dim enrUSER_INPUT = ur_windowsmsgbox_env.GetResult(
                        ur_title:=Me.SelKey(enmUN.app_name).v(enmUB.contents),
                        ur_message:=strAUDIT,
                        ur_style:=MsgBoxStyle.OkCancel
                        )
                    If enrUSER_INPUT = MsgBoxResult.Ok Then
                        ur_windowscboard_env.SetText(
                            strAUDIT
                            )
                    End If
                End If
            End Sub 'Cboard_CmdlineAudit

            <System.Diagnostics.DebuggerHidden()>
            Public Function InsFrom_Application() As rUserBowl
                Dim ret = New rUserBowl
                InsFrom_Application = ret
                Dim strASSEMBLY_EXE = mt
                Try
                    strASSEMBLY_EXE = My.Application.Info.Title
                Catch ex As System.Exception : End Try

                Dim flnASSEMBLY_FOLDER = FileNamed()
                Try
                    flnASSEMBLY_FOLDER.wAssemblyDir(My.Application.Info)
                Catch ex As System.Exception : End Try

                Dim flnASSEMBLY_PATH = flnASSEMBLY_FOLDER.gCopy.d(strASSEMBLY_EXE)
                Me.SelKey(enmUN.app_name).Contents = flnASSEMBLY_PATH.FileGroup
                Me.SelKey(enmUN.app_path).Contents = flnASSEMBLY_PATH
                Me.SelKey(enmUN.app_folder).Contents = flnASSEMBLY_FOLDER

                'enmUN.compiler_exe, enmUN.path take the first non-prefixed parameters; they are just file paths but without /parameter_name=
                Dim arlCMD_RET = MxText.Cmdline_UB(Of enmUN, enmUB).CommandLine_UBParm(enmUB.bowl_name, enmUB.contents, Have.CmdLineText, enmUN.compiler_exe, enmUN.path)
                Me.SelKey(enmUN.cmdline_orig).Contents = qs & Have.CmdLineText.Replace(qs, qs & qs) & qs
                Me.SelKey(enmUN.cmdline_table).Contents = qs & arlCMD_RET.ttbCMD_PARM.ToString(True).Replace(qs, qs & qs) & qs
                For Each rowFOUND In arlCMD_RET.ttbUB_PARM
                    Me.Sel(enmUB.bowl_name, rowFOUND.v(enmUB.bowl_name)).SelFirst.Contents = rowFOUND.v(enmUB.contents)
                Next
            End Function 'InsFrom_Application

            <System.Diagnostics.DebuggerHidden()>
            Public Function ToCboard(ur_hdr As Boolean) As Integer
                ToCboard = Mx.glbl.gCboard.SetText(Me.ToString(ur_hdr))
            End Function
        End Class 'sUserBowl
    End Class 'UB, UN
End Namespace 'Mx