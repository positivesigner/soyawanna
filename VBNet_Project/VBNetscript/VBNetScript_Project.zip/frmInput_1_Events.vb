﻿Option Strict On
Partial Public Class frmInput_1
    Private Sub frmInput_1_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Call Mx.Want.Compile_And_Run_Script_errhnd(Me, System.Environment.CommandLine)
    End Sub 'frmInput_1_Load

    <System.Diagnostics.DebuggerHidden()>
    Public Shared Widening Operator CType(b As frmInput_1) As Mx.dbUserInput
        Return New Mx.dbUserInput(b, b.txtNotice_Message)
    End Operator
End Class 'frmInput_1
