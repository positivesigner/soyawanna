﻿Option Strict On
Public Class frmInput_1
End Class 'frmInput_1
