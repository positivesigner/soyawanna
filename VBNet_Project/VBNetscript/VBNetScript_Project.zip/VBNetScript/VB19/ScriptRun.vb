﻿Namespace Mx
    Public Class ScriptRun
        ' Build a Hello World program graph using 
        ' System.CodeDom types.
        Public Class enmC_V_J
            Inherits bitBASE
            Public Shared CSharp As enmC_V_J = TRow(Of enmC_V_J).glbl.NewBitBase()
            Public Shared VisualBasic As enmC_V_J = TRow(Of enmC_V_J).glbl.NewBitBase()
            Public Shared JScript As enmC_V_J = TRow(Of enmC_V_J).glbl.NewBitBase()
        End Class 'enmC_V_J

        Public Class enmSECTION
            Inherits bitBASE
            Public Shared windows_cmd As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared include_dll_path As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared include_vb_path As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared header_options_flag As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared compile_header_options As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared header_imports_class As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared compile_header_imports As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared compile_code_header As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared function_code_line As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared compile_function_code As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared class_code_line As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared namespace_code_line As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
            Public Shared global_code_line As enmSECTION = TRow(Of enmSECTION).glbl.NewBitBase()
        End Class 'enmSECTION

        Public Shared Function RunCode(ur_provider As Mx.ScriptRun.enmC_V_J, ur_program_lines As Sdata, ur_sourcecode_file_path As String, ur_windowsfs_env As Have.glblWindowsFS) As Strap
            Dim retCODE_OUTPUT = Strapd()
            RunCode = retCODE_OUTPUT
            Dim strSOURCE_CODE = mt
            Dim stpCODE_FILE = Strapd()
            ' Configure a CompilerParameters that links System.dll and produces the specified executable file.
            'Dim objAPP_DOMAIN As System.AppDomain = Nothing
            Dim objCOMPILE_RUNNER As CompilerRunner = Nothing
            Dim objCOMPILER_PARM = New System.CodeDom.Compiler.CompilerParameters
            'Dim objCOPMILER_RESULT As System.CodeDom.Compiler.CompilerResults = Nothing
            'Dim objMETHOD_MAIN As System.Reflection.MethodInfo = Nothing
            'start "" VBNetScript.exe /path script.vbns
            'exit
            'Optional - UrRef.dll
            'Optional - UrInclude.vb
            'Optional - Option Strict On, or some other Option On/Off
            'Optional - Imports UrNamespace
            'UrCodeLines

            Dim sdaINCLUDE_VB_PATH As New Objlist(Of MxText.FileName)
            Dim stpHEADER_OPTIONS_FLAG = Strapd()
            Dim stpHEADER_IMPORTS_CLASS = Strapd()
            objCOMPILER_PARM.ReferencedAssemblies.Add("system.dll")
            Dim stpFUNCTIONS = Strapd()
            Dim enrSECTION = enmSECTION.windows_cmd
            For Each strLINE In ur_program_lines
                Dim strTRIM_LINE = strLINE.Trim
                If enrSECTION Is enmSECTION.windows_cmd Then
                    If StartingWithText(strTRIM_LINE, "start" & s) OrElse
                      StartingWithText(strTRIM_LINE, "cd" & s) OrElse
                      StartingWithText(strTRIM_LINE, "rem" & s) OrElse
                      StartingWithText(strTRIM_LINE, "exit") OrElse
                      StartingWithText(strTRIM_LINE, "@") OrElse
                      StartingWithText(strTRIM_LINE, ":") OrElse
                      HasText(strTRIM_LINE) = False Then
                        'Skip Windows Command-line commands
                    Else

                        enrSECTION = enmSECTION.include_dll_path
                    End If
                End If 'windows_cmd

                If enrSECTION Is enmSECTION.include_dll_path Then
                    If EndingWithText(strTRIM_LINE, ".DLL") Then
                        objCOMPILER_PARM.ReferencedAssemblies.Add(strTRIM_LINE)
                        strLINE = mt
                    Else

                        enrSECTION = enmSECTION.include_vb_path
                    End If
                End If 'include_dll_path

                If enrSECTION Is enmSECTION.include_vb_path Then
                    If EndingWithText(strTRIM_LINE, ".VB") Then
                        sdaINCLUDE_VB_PATH.Add(strTRIM_LINE)
                        strLINE = mt
                    Else

                        enrSECTION = enmSECTION.header_options_flag
                    End If
                End If 'include_vb_path

                If enrSECTION Is enmSECTION.header_options_flag Then
                    If StartingWithText(strTRIM_LINE, "OPTION" & s) Then
                        stpHEADER_OPTIONS_FLAG.dLineNB(strLINE)
                        strLINE = mt

                    Else
                        enrSECTION = enmSECTION.compile_header_options
                    End If
                End If 'header_options_flag

                If enrSECTION Is enmSECTION.compile_header_options Then
                    If stpHEADER_OPTIONS_FLAG.HasText = False Then
                        stpHEADER_OPTIONS_FLAG.dLineNB("Option Infer On")
                    End If

                    enrSECTION = enmSECTION.header_imports_class
                End If 'compile_header_options

                If enrSECTION Is enmSECTION.header_imports_class Then
                    If StartingWithText(strTRIM_LINE, "IMPORTS" & s) Then
                        stpHEADER_IMPORTS_CLASS.dLineNB(strLINE)
                        strLINE = mt

                    Else
                        enrSECTION = enmSECTION.compile_header_imports
                    End If
                End If 'header_imports_class

                If enrSECTION Is enmSECTION.compile_header_imports Then
                    If stpHEADER_IMPORTS_CLASS.HasText = False Then
                        stpHEADER_IMPORTS_CLASS.dLineNB("Imports System")
                        stpHEADER_IMPORTS_CLASS.dLine("Imports Microsoft.VisualBasic")
                        'Imports System.Xml
                        'Imports System.Data
                    End If

                    enrSECTION = enmSECTION.compile_code_header
                End If 'compile_header_imports

                If enrSECTION Is enmSECTION.compile_code_header Then
                    stpCODE_FILE.dLineNB(stpHEADER_OPTIONS_FLAG)
                    stpCODE_FILE.dLineNB(stpHEADER_IMPORTS_CLASS)

                    ' Build a little wrapper code, with our passed in code in the middle 
                    stpCODE_FILE.dLineNB("Namespace Mx")
                    stpCODE_FILE.dLine("Public Class Class1")
                    stpCODE_FILE.dLine("Public Shared Function SourcePath() As String")
                    stpCODE_FILE.dLine(Strapd().d("SourcePath = " & qs & "@r1" & qs).r1(ur_sourcecode_file_path))
                    stpCODE_FILE.dLine("End Function")

                    stpCODE_FILE.dLine(mt)
                    stpCODE_FILE.dLine("Public Shared Function SourceFolder() As String")
                    stpCODE_FILE.dLine("SourceFolder = System.IO.Path.GetDirectoryName(Mx.Class1.SourcePath)")
                    stpCODE_FILE.dLine("End Function")

                    stpCODE_FILE.dLine(mt)
                    If objCOMPILER_PARM.ReferencedAssemblies.Count > 1 Then
                        stpCODE_FILE.dLine("Public Shared Function prvMyResolveEventHandler(Optional sender As Object = Nothing, Optional args As System.ResolveEventArgs = Nothing) As System.Reflection.Assembly")
                        stpCODE_FILE.dLine("    prvMyResolveEventHandler = Nothing")
                        stpCODE_FILE.dLine("    If args Is Nothing Then")
                        stpCODE_FILE.dLine("        RemoveHandler System.AppDomain.CurrentDomain.AssemblyResolve, AddressOf prvMyResolveEventHandler")
                        stpCODE_FILE.dLine("        AddHandler System.AppDomain.CurrentDomain.AssemblyResolve, AddressOf prvMyResolveEventHandler")
                        stpCODE_FILE.dLine(mt)
                        stpCODE_FILE.dLine("    Else 'args")
                        stpCODE_FILE.dLine("        Using stmCONFIG_FILE = New System.IO.StreamReader(Mx.Class1.SourcePath, New System.Text.UTF8Encoding(True, True))")
                        stpCODE_FILE.dLine("            While stmCONFIG_FILE.EndOfStream = False")
                        stpCODE_FILE.dLine("                Dim strENTRY = stmCONFIG_FILE.ReadLine")
                        stpCODE_FILE.dLine(Strapd().d("                If String.Equals(Left(strENTRY, Len(@r1start@r1 & @r1 @r1)), @r1start@r1 & @r1 @r1, System.StringComparison.CurrentCultureIgnoreCase) OrElse").r1(qs))
                        stpCODE_FILE.dLine(Strapd().d("                String.Equals(Left(strENTRY, Len(@r1exit@r1)), @r1exit@r1, System.StringComparison.CurrentCultureIgnoreCase) Then").r1(qs))
                        stpCODE_FILE.dLine(Strapd().d("                ElseIf String.Equals(Right(strENTRY, Len(@r1.DLL@r1)), @r1.DLL@r1, System.StringComparison.CurrentCultureIgnoreCase) Then").r1(qs))
                        stpCODE_FILE.dLine(Strapd().d("                    If InStr(strENTRY, @r1\@r1) = 0 Then").r1(qs))
                        stpCODE_FILE.dLine("                        strENTRY = System.IO.Path.Combine(Mx.Class1.SourcePath, strENTRY)")
                        stpCODE_FILE.dLine("                    End If 'strENTRY")
                        stpCODE_FILE.dLine("                    ")
                        stpCODE_FILE.dLine("                    If String.Equals(Left(args.Name, Len(System.IO.Path.GetFileNameWithoutExtension(strENTRY))), System.IO.Path.GetFileNameWithoutExtension(strENTRY), System.StringComparison.CurrentCultureIgnoreCase) Then")
                        stpCODE_FILE.dLine("                        prvMyResolveEventHandler = System.Reflection.Assembly.LoadFrom(strENTRY)")
                        stpCODE_FILE.dLine("                        Exit While")
                        stpCODE_FILE.dLine("                    End If 'args")
                        stpCODE_FILE.dLine(mt)
                        stpCODE_FILE.dLine("                Else 'strENTRY")
                        stpCODE_FILE.dLine("                    Exit While")
                        stpCODE_FILE.dLine("                End If 'strENTRY")
                        stpCODE_FILE.dLine("            End While 'stmCONFIG_FILE")
                        stpCODE_FILE.dLine("        End Using 'stmCONFIG_FILE")
                        stpCODE_FILE.dLine("    End If 'args")
                        stpCODE_FILE.dLine("End Function 'prvMyResolveEventHandler")
                    End If 'objCOMPILER_PARM

                    stpCODE_FILE.dLine(mt)
                    stpCODE_FILE.dLine("Public Shared Function RetVal() As String")
                    stpCODE_FILE.dLine("RetVal = " & qs & qs)
                    If objCOMPILER_PARM.ReferencedAssemblies.Count > 1 Then
                        stpCODE_FILE.dLine("Call prvMyResolveEventHandler()")
                    End If

                    stpCODE_FILE.dLine("Try")

                    enrSECTION = enmSECTION.function_code_line
                End If 'compile_code_header

                If enrSECTION Is enmSECTION.function_code_line Then
                    If StartingWithText(strTRIM_LINE, "END FUNCTION") Then
                        enrSECTION = enmSECTION.compile_function_code

                    Else
                        stpCODE_FILE.dLine(strLINE)
                    End If

                ElseIf enrSECTION Is enmSECTION.class_code_line Then
                    stpCODE_FILE.dLine(strLINE)
                    If StartingWithText(strTRIM_LINE, "END CLASS") Then
                        enrSECTION = enmSECTION.namespace_code_line
                    End If

                ElseIf enrSECTION Is enmSECTION.namespace_code_line Then
                    stpCODE_FILE.dLine(strLINE)
                    If StartingWithText(strTRIM_LINE, "END NAMESPACE") Then
                        enrSECTION = enmSECTION.global_code_line
                    End If

                ElseIf enrSECTION Is enmSECTION.global_code_line Then
                    stpCODE_FILE.dLine(strLINE)
                End If 'function_code_line

                If enrSECTION Is enmSECTION.compile_function_code Then
                    stpCODE_FILE.dLine("Catch ex As System.Exception")
                    stpCODE_FILE.dLine("RetVal = RetVal & Microsoft.VisualBasic.Constants.vbCrLf & ex.Message")
                    stpCODE_FILE.dLine("End Try")
                    stpCODE_FILE.dLine("End Function 'RetVal")

                    stpCODE_FILE.dLine(mt)
                    enrSECTION = enmSECTION.class_code_line
                End If 'compile_function_code
            Next strLINE

            If enrSECTION Is enmSECTION.function_code_line Then
                stpCODE_FILE.dLine("Catch ex As System.Exception")
                stpCODE_FILE.dLine("RetVal = RetVal & Microsoft.VisualBasic.Constants.vbCrLf & ex.Message")
                stpCODE_FILE.dLine("End Try")
                stpCODE_FILE.dLine("End Function 'RetVal")

                stpCODE_FILE.dLine(mt)
                enrSECTION = enmSECTION.class_code_line
            End If

            If enrSECTION Is enmSECTION.class_code_line Then
                stpCODE_FILE.dLine("End Class 'Class1")
                enrSECTION = enmSECTION.namespace_code_line
            End If

            If enrSECTION Is enmSECTION.namespace_code_line Then
                stpCODE_FILE.dLine("End Namespace 'Mx")
                enrSECTION = enmSECTION.global_code_line
            End If

            'objCOMPILER_PARM.ReferencedAssemblies.Add("system.xml.dll")
            'objCOMPILER_PARM.ReferencedAssemblies.Add("system.data.dll")
            'objCOMPILER_PARM.CompilerOptions = "/t:library"
            objCOMPILER_PARM.GenerateInMemory = True
            objCOMPILER_PARM.GenerateExecutable = False

            ' Generate the Code Framework
            'The program automatically adds NameSpace Mx
            'The program automatically adds Class Class1
            'The program automatically adds Function RetVal() As String
            'UrFunctionines
            'Optional - RetVal = UrReturnValue
            'Optional - End Function
            'Optional - More Functions and Subs
            'Optional - End Class
            'Optional - More Classes
            'Optional - End Namespace
            'Optional - More Namespaces

            For Each strENTRY In sdaINCLUDE_VB_PATH
                If System.IO.File.Exists(strENTRY) Then
                    stpCODE_FILE.dLine(My.Computer.FileSystem.ReadAllText(strENTRY).Replace("Option Infer On", mt).Replace("Option Strict On", mt))

                Else
                    retCODE_OUTPUT.dLine(Strapd().d("Referenced file is missing").dSprtr(": ", strENTRY))
                End If
            Next strENTRY

            If retCODE_OUTPUT.HasText = False Then
                objCOMPILE_RUNNER = New Mx.CompilerRunner
                'Dim flnDLL_FILE_PATH = FileNamed().d(ur_sourcecode_file_path)
                'flnDLL_FILE_PATH = flnDLL_FILE_PATH.gParentDir.dNowTextYMDHMS(flnDLL_FILE_PATH.Name).dAppendEXT("DLL")
                'objCOMPILER_PARM.OutputAssembly = flnDLL_FILE_PATH
                'objCOMPILER_PARM.CompilerOptions = "/t:library"
                'objCOMPILER_PARM.GenerateInMemory = False
                'Dim strDLL_COMPILE_ERRORS = objCOMPILE_RUNNER.Compile(stpCODE_FILE.ToString, ur_provider.name, objCOMPILER_PARM)
                'If HasText(strDLL_COMPILE_ERRORS) Then
                '    retCODE_OUTPUT.d(strDLL_COMPILE_ERRORS)

                'Else
                'objCOMPILER_PARM.GenerateInMemory = True
                'Dim sdaNRW = MyBase.Insert
                '    sdaNRW.Item(enmTH.namespace) = objTYPE.Namespace
                '    sdaNRW.Item(enmTH.name) = objTYPE.Name
                '    sdaNRW.Item(enmTH.class_path) = objTYPE.FullName
                'Next objTYPE

                'Dim objAPP_DOMAIN = System.AppDomain.CreateDomain("MyDomain", System.AppDomain.CurrentDomain.Evidence, ScriptRun.CreateSetup(), permissionSet)
                'Try
                '    Dim objLOAD_ASSEMBLY = objAPP_DOMAIN.CreateInstanceFromAndUnwrap(flnDLL_FILE_PATH, "Mx.Class1")
                '    retCODE_OUTPUT.d(objLOAD_ASSEMBLY.Run("Mx.Class1", "RetVal"))
                'Catch ex As System.Exception
                '    retCODE_OUTPUT.d(ex.Message)
                'End Try

                'System.AppDomain.Unload(objAPP_DOMAIN)
                'Call ur_windowsfs_env.Delete(flnDLL_FILE_PATH)
                'End If

                'Source code compiled into an Assembly in memory is unable to be unloaded
                'Source code compiled into an Assembly in a file system .DLL file can be ran in a new System.AppDomain, which can be unloaded when complete
                'Since I cannot get the AppDomain code above to work, the program currently has to close after running the one Assembly
                retCODE_OUTPUT.d(objCOMPILE_RUNNER.Compile(stpCODE_FILE.ToString, ur_provider.name, objCOMPILER_PARM))
            End If

            If retCODE_OUTPUT.HasText = False Then
                retCODE_OUTPUT.d(objCOMPILE_RUNNER.Run("Mx.Class1", "RetVal"))
            End If
        End Function 'RunCode

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function CreateSetup() As System.AppDomainSetup
            Dim retSETUP = New System.AppDomainSetup
            With retSETUP
                .ApplicationBase = System.AppDomain.CurrentDomain.BaseDirectory
                .ApplicationName = "TestDLL"
                .DisallowBindingRedirects = False
                .ConfigurationFile = System.AppDomain.CurrentDomain.SetupInformation.ConfigurationFile
                .LoaderOptimization = System.LoaderOptimization.MultiDomainHost
            End With
            CreateSetup = retSETUP
        End Function 'CreateSetup
    End Class 'ScriptRun

    Public Class CompilerRunner
        Inherits System.MarshalByRefObject

        Public cur_assembly As System.Reflection.Assembly
        'AppDomain.CurrentDomain.FriendlyName = MyDomain

        Public Function Compile(ur_code As String, ur_provider As String, ur_compiler_parm As System.CodeDom.Compiler.CompilerParameters) As String
            Dim stpERR_MSG = Strapd()
            Me.cur_assembly = Nothing
            Dim provider As System.CodeDom.Compiler.CodeDomProvider = System.CodeDom.Compiler.CodeDomProvider.CreateProvider(ur_provider) 'New Microsoft.VisualBasic.VBCodeProvider 
            Dim objCOMPILER_RESULT = provider.CompileAssemblyFromSource(ur_compiler_parm, ur_code) ' Strapd().d("Namespace Mx").dLine("Public Class Class1").dLine("Public Shared Function RetVal() As String").dLine("RetVal=""Hi""").dLine("End Function").dLine("End Class").dLine("End Namespace"))
            If objCOMPILER_RESULT.Errors.Count = 0 Then
                Me.cur_assembly = objCOMPILER_RESULT.CompiledAssembly

            Else
                stpERR_MSG.dLineNB("Compile Errors")
                stpERR_MSG.dLine()
                For Each errItem As System.CodeDom.Compiler.CompilerError In objCOMPILER_RESULT.Errors
                    stpERR_MSG.dLine(errItem.ErrorText & " [" & errItem.Line + 5 & "]")
                    stpERR_MSG.dLine()
                    stpERR_MSG.dLine()
                Next errItem

                stpERR_MSG.dLine(ur_code)
            End If 'objCOMPILER_RESULT

            Compile = stpERR_MSG.ToString
        End Function 'Comiple

        Public Function Run(ur_type_name As String, ur_method_name As String) As String
            Dim stpERR_MSG = Strapd()
            Dim t As System.Type = Me.cur_assembly.CreateInstance(ur_type_name).GetType()
            'Dim objRESULT = t.InvokeMember(ur_method_name, System.Reflection.BindingFlags.InvokeMethod, Nothing, Me.cur_assembly, {})
            Dim objMETHOD_MAIN As System.Reflection.MethodInfo = Nothing
            For Each m As System.Reflection.MethodInfo In t.GetMethods
                If m.Name = ur_method_name Then
                    objMETHOD_MAIN = m
                    Exit For
                End If
            Next m

            If objMETHOD_MAIN IsNot Nothing Then
                Dim objRESULT = objMETHOD_MAIN.Invoke(Nothing, Nothing)
                If objRESULT IsNot Nothing Then
                    stpERR_MSG.d(objRESULT.ToString)
                End If 'objRESULT
            End If 'objMETHOD_MAIN

            Run = stpERR_MSG.ToString
        End Function 'Run
    End Class 'CompileRunner
End Namespace 'Mx
