﻿Option Strict On
Namespace Mx
    Public Class UserAction
        Public Shared Function Compile_And_Run_Script_errhnd(ur_form As dbUserInput, ur_cur_assembly As System.Reflection.Assembly, ur_command_text As String, Optional ur_curexe As String = "") As Strap
            Dim retPROGRAM_OUTPUT = Strapd()
            Compile_And_Run_Script_errhnd = retPROGRAM_OUTPUT
            Have.CurAssembly = ur_cur_assembly
            Have.CmdLineText = ur_command_text
            Have.CurExe = ur_curexe
            Dim objERR_LIST = New ErrListBase : Try

                Dim noticemsg_tbox = ur_form.txtNotice_Message
                Dim windowscboard_env = Have.WindowsCboardEnv
                Dim windowsfs_env = Have.WindowsFSEnv
                Dim userbowl_cart = Have.UserBowl
                Dim appname_bowlname = enmUN.app_name
                Dim appfolder_bowlname = enmUN.app_folder
                Dim cmd_export_projectcode_bowlname = enmUN.export_project_code
                Dim cmd_export_cmdlineaudit_bowlname = enmUN.audit_parms_to_cboard
                Dim path_vbns_bowlname = enmUN.path
                Dim project_codezip_bowlname = enmUN.project_code_zip
                Dim project_coderesource_bowlname = enmUN.project_code_resource
                Dim script_code_text = mt
                Dim script_file_path = FileNamed()

                Dim updated_userbowl_count = Assistant.Store_ProjectResourceName(ur_cur_assembly, userbowl_cart, project_codezip_bowlname, project_coderesource_bowlname)
                updated_userbowl_count = Assistant.Store_AppName(userbowl_cart, appname_bowlname, path_vbns_bowlname)
                Dim audit_notice_msg = Assistant.Cboard_CmdlineAudit(userbowl_cart, cmd_export_cmdlineaudit_bowlname)
                Dim written_message_count = Assistant.Write_NoticeMessage(noticemsg_tbox, audit_notice_msg)
                If written_message_count = 0 Then
                    Dim export_notice_msg = Assistant.Export_Project_Code(ur_form, ur_cur_assembly, userbowl_cart, appfolder_bowlname, project_codezip_bowlname, project_coderesource_bowlname, cmd_export_projectcode_bowlname, windowsfs_env)
                    written_message_count = Assistant.Write_NoticeMessage(noticemsg_tbox, export_notice_msg)
                End If

                If written_message_count = 0 Then
                    script_file_path = Assistant.Search_for_Script_File(userbowl_cart, path_vbns_bowlname, appfolder_bowlname)
                    Dim updated_form_count = Assistant.Update_Form_Title(ur_form, userbowl_cart, script_file_path)
                    script_code_text = Assistant.Read_CommandCode(script_file_path, windowsfs_env)
                    If script_code_text.Length = 0 Then
                        Dim stpFILE_CONTENTS = Strapd().d("Cannot find source code lines: ").d(script_file_path)
                        written_message_count = Assistant.Write_NoticeMessage(ur_form.txtNotice_Message, stpFILE_CONTENTS)
                    End If
                End If

                If written_message_count = 0 Then
                    Dim report_output_text = Assistant.Run_ProgramText(userbowl_cart, script_code_text, script_file_path, windowsfs_env)
                    Compile_And_Run_Script_errhnd = report_output_text
                    written_message_count = Assistant.Write_NoticeMessage(noticemsg_tbox, report_output_text)
                    Dim updated_form_count = Assistant.Close_Input_Form(ur_form, report_output_text)
                    updated_form_count = Assistant.Update_Window_Color(ur_form, report_output_text)
                End If 'written_message_count

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                objERR_LIST.ToString()
                Dim stpERR_MSG = Strapd().d(Assistant.strlit_RED).dLine.dLine(objERR_LIST.ToString).dLine.dLine.dLine(Assistant.Help_CommandLine_Options)
                Compile_And_Run_Script_errhnd = stpERR_MSG
                ur_form.txtNotice_Message.Text = stpERR_MSG
            End If
        End Function 'Compile_And_Run_Script_errhnd
    End Class 'UserAction


    Public Class Assistant
        Public Shared strline_GREEN As String = "GREEN"
        Public Shared strlit_RED As String = "RED"
        Public Shared strlit_FALSE As String = "False"
        Public Shared strlit_TRUE As String = "True"
        Public Shared strlit_QUIT As String = "Quit"
        Public Shared strlit_VBNETSCRIPT_PROJECT_DOT_ZIP As String = "VBNetScript_Project.zip"

        Public Shared Function Cboard_CmdlineAudit(ur_userbowl_cart As Have.sUserBowl, ur_cmd_export_cmdlineaudit_bowlname As enmUN.zaudit_parms_to_cboard) As Strap
            Dim stpRET_MSG = Strapd()
            Cboard_CmdlineAudit = stpRET_MSG
            Dim strUSER_INPUT = ur_userbowl_cart.SelKey(ur_cmd_export_cmdlineaudit_bowlname).Contents
            If HasText(strUSER_INPUT) AndAlso
              AreEqual(strUSER_INPUT, strlit_TRUE) = False AndAlso
              AreEqual(strUSER_INPUT, strlit_FALSE) = False Then
                stpRET_MSG.d("Command line option").dS(ur_cmd_export_cmdlineaudit_bowlname.name).dS(" must only have the text True or False, or it must be omitted. Provided text:").dS(strUSER_INPUT)

            ElseIf AreEqual(strUSER_INPUT, strlit_TRUE) Then
                stpRET_MSG.d(ur_userbowl_cart.ToString(True)).dLine.dLine.dLine(Assistant.Help_CommandLine_Options)
            End If 'strUSER_INPUT
        End Function 'Cboard_CmdlineAudit

        Public Shared Function Close_Input_Form(ur_form As dbUserInput, ur_program_output As String) As Integer
            Close_Input_Form = 0
            If StartingWithText(ur_program_output, strlit_QUIT) Then
                Call ur_form.Close()
                Close_Input_Form = 1
            End If
        End Function 'Close_Input_Form

        Public Shared Function Export_Project_Code(ur_form As dbUserInput, ur_cur_assembly As System.Reflection.Assembly, ur_userbowl_cart As Have.sUserBowl, ur_appfolder_bowlname As enmUN.zapp_folder, ur_project_codezip_bolwname As enmUN.zproject_code_zip, ur_project_coderesource_bolwname As enmUN.zproject_code_resource, ur_export_projectcode_bowlname As enmUN.zexport_project_code, ur_windowsfs_env As Have.glblWindowsFS) As Strap
            Dim stpRET_MSG = Strapd()
            Export_Project_Code = stpRET_MSG
            Dim strUSER_INPUT = ur_userbowl_cart.SelKey(ur_export_projectcode_bowlname).Contents
            If HasText(strUSER_INPUT) AndAlso
              AreEqual(strUSER_INPUT, strlit_TRUE) = False AndAlso
              AreEqual(strUSER_INPUT, strlit_FALSE) = False Then
                stpRET_MSG.d("Command line option").dS(ur_export_projectcode_bowlname.name).dS(" must only have the text True or False, or it must be omitted. Provided text:").dS(strUSER_INPUT)

            ElseIf AreEqual(strUSER_INPUT, strlit_TRUE) Then
                Dim strPROJECT_FILE = ur_userbowl_cart.SelKey(ur_project_codezip_bolwname).Contents
                Dim strFOUND_RESOURCE_NAME = ur_userbowl_cart.SelKey(ur_project_coderesource_bolwname).Contents
                Dim flnDEST_PATH = FileNamed().d(ur_userbowl_cart.SelKey(ur_appfolder_bowlname).Contents).d(strPROJECT_FILE)
                If HasText(strFOUND_RESOURCE_NAME) = False Then
                    stpRET_MSG.d("Cannot find resource:").dS(strPROJECT_FILE)

                ElseIf ur_windowsfs_env.GetFiles(flnDEST_PATH).Count >= 1 Then
                    stpRET_MSG.d("Export ZIP file already exists:").dS(flnDEST_PATH)

                Else
                    Using objRESOURCE = ur_cur_assembly.GetManifestResourceStream(strFOUND_RESOURCE_NAME)
                        Using objFILE = New System.IO.FileStream(flnDEST_PATH, System.IO.FileMode.Create, System.IO.FileAccess.Write)
                            objRESOURCE.CopyTo(objFILE)
                        End Using
                    End Using 'objRESOURCE

                    stpRET_MSG.d("Project file exported:").dS(flnDEST_PATH)
                End If 'strFOUND_RESOURCE_NAME
            End If 'strUSER_INPUT
        End Function 'Export_Project_Code

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function Help_CommandLine_Options() As Strap
            Dim stpHELP = Strapd()
            Help_CommandLine_Options = stpHELP
            With stpHELP
                .d("VBNetScript.exe /path=").dSprtr(qs, "UrCodeFile.vbns").d(qs).dLine()
                .dLine()
                .dLine("/path specifies a code file in this format:")
                .dLine()
                .dLine("[Input File Format]")
                .dLine("* At the start of the file, there are several Windows Command Line commands that are skipped:")
                .dLine()
                .dLine("Skipped - start-prefixed lines")
                .dLine("Skipped - cd-prefixed lines")
                .dLine("Skipped - rem-prefixed lines")
                .dLine("Skipped - exit-prefixed lines")
                .dLine("Skipped - @-prefixed lines")
                .dLine("Skipped - Blank lines")
                .dLine()
                .dLine("* The first line that does not match the above skipped lines may be a .DLL file")
                .dLine()
                .dLine("Optional - UrRef.dll")
                .dLine()
                .dLine("* The first line that does not end in .DLL may be an included .VB file")
                .dLine()
                .dLine("Optional - UrInclude.vb")
                .dLine()
                .dLine("* The first line that does not end in .VB may be an OPTION command")
                .dLine()
                .dLine("Optional - , or some other Option On/Off")
                .dLine()
                .dLine("* The first line that does not start with OPTIONAL may be an IMPORTS command")
                .dLine()
                .dLine("Optional - Imports UrNamespace")
                .dLine()
                .dLine("* The first line that does not start with IMPORTS is assumed to be a VB.Net code line")
                .dLine("* Note: The program automatically adds these lines before your first code line")
                .dLine()
                .dLine("Added - NameSpace Mx")
                .dLine("Added - Class Class1")
                .dLine("Added - Function RetVal() As String")
                .dLine()
                .dLine("Required - UrCodeLines")
                .dLine()
                .dLine("* If you assign a value to the RetVal variable, it will show in a multi-line textbox")
                .dLine("    * Unless you assign the value RED or GREEN, which will cause the border to change color")
                .dLine("    * Or you assign the value QUIT, which will not show a Windows Form at all")
                .dLine()
                .dLine("You can add any further VB.Net code lines, including ending the default Function name, Class name and Namespace name and adding others")
                .dLine()
                .dLine("Optional - End Function")
                .dLine("Optional - More Functions and Subs")
                .dLine("Optional - End Class")
                .dLine("Optional - More Classes")
                .dLine("Optional - End Namespace")
                .dLine("Optional - More Namespaces")
                .dLine()
                .dLine("VBNetScript.exe /audit_parms_to_cboard=True")
                .dLine()
                .dLine("/audit_parms_to_cboard will show the command-line audit table in a message box, and then allow you to copy the table to the clipboard")
                .dLine()
                .dLine("VBNetScript.exe /export_project_code=True")
                .dLine()
                .dLine("/export_project_code will ask for a folder in which to save the VBNetScript Project .ZIP file")
                .dLine()
                .dLine("* Note: Command-line parameters may not work in .lnk Windows Shortcut files. Please call from a .cmd file to test.")
                .dLine()
            End With 'stpHELP
        End Function 'Help_CommandLine_Options

        Public Shared Function Read_CommandCode(ur_script_file_path As String, ur_windowsfs_env As Have.glblWindowsFS) As String
            Dim retPROGRAM_CODE = mt
            For Each strFOUND_PATH In ur_windowsfs_env.GetFiles(ur_script_file_path)
                retPROGRAM_CODE = ur_windowsfs_env.ReadAllText(strFOUND_PATH)
                Exit For
            Next

            Read_CommandCode = retPROGRAM_CODE
        End Function 'Read_CommandCode

        Public Shared Function Read_CommandLines(ur_script_file_path As String, ur_program_text As String, ur_windowsfs_env As Have.glblWindowsFS) As Sdata
            Dim retPROGRAM_LINES = New Sdata()
            Dim strPROGRAM_TEXT = ur_program_text
            If HasText(strPROGRAM_TEXT) = False Then
                For Each strFOUND_PATH In ur_windowsfs_env.GetFiles(ur_script_file_path)
                    retPROGRAM_LINES = ur_windowsfs_env.ReadAllLines(strFOUND_PATH)
                    Exit For
                Next

            Else
                retPROGRAM_LINES.dList(ur_program_text.Replace(vbCr, mt).Split(Chr(10)))
            End If 'strPROGRAM_TEXT

            Read_CommandLines = retPROGRAM_LINES
        End Function 'Read_CommandLines

        Public Shared Function Run_ProgramText(ur_userbowl_cart As Have.sUserBowl, ur_script_code_text As String, ur_script_file_path As String, ur_windowsfs_env As Have.glblWindowsFS) As Strap
            Dim retPROGRAM_OUTPUT = Strapd()
            If ur_script_code_text.Length > 0 Then
                Dim sdaCODE_LINES = New Sdata().dList(ur_script_code_text.Replace(vbCr, mt).Split(Chr(10)))
                retPROGRAM_OUTPUT = Mx.ScriptRun.RunCode(Mx.ScriptRun.enmC_V_J.VisualBasic, sdaCODE_LINES, ur_script_file_path, ur_windowsfs_env)
            End If 'ur_script_code_text

            Run_ProgramText = retPROGRAM_OUTPUT
        End Function 'Run_ProgramText

        Public Shared Function Search_for_Script_File(ur_userbowl_cart As Have.sUserBowl, ur_inpath_bowlname As enmUN.zpath, ur_app_folder As enmUN.zapp_folder) As Mx.MxText.FileName
            Dim retSCRIPT_LINES = FileNamed()
            Search_for_Script_File = retSCRIPT_LINES
            Dim strSCRIPT_PATH = ur_userbowl_cart.SelKey(ur_inpath_bowlname).Contents
            If HasText(strSCRIPT_PATH) Then
                If InStr(strSCRIPT_PATH, ":") > 0 Then
                    retSCRIPT_LINES.d(strSCRIPT_PATH)
                Else
                    retSCRIPT_LINES.d(ur_userbowl_cart.SelKey(ur_app_folder).Contents).d(strSCRIPT_PATH)
                End If
            End If 'strSCRIPT_PATH
        End Function 'Search_for_Script_File

        Public Shared Function Store_AppName(ur_userbowl_cart As Have.sUserBowl, ur_appname_bowlname As enmUN.zapp_name, ur_path_vbns_bolwname As enmUN.zpath) As Integer
            Store_AppName = 1
            ur_userbowl_cart.SelKey(ur_appname_bowlname).Contents = ur_userbowl_cart.SelKey(ur_path_vbns_bolwname).Contents
        End Function 'Store_AppName

        Public Shared Function Store_ProjectResourceName(ur_cur_assembly As System.Reflection.Assembly, ur_userbowl_cart As Have.sUserBowl, ur_project_codezip_bolwname As enmUN.zproject_code_zip, ur_project_coderesource_bolwname As enmUN.zproject_code_resource) As Integer
            Store_ProjectResourceName = 2
            Dim strPROJECT_FILE = strlit_VBNETSCRIPT_PROJECT_DOT_ZIP
            ur_userbowl_cart.SelKey(ur_project_codezip_bolwname).Contents = strPROJECT_FILE
            For Each strENTRY In ur_cur_assembly.GetManifestResourceNames()
                If EndingWithText(strENTRY, strPROJECT_FILE) Then
                    ur_userbowl_cart.SelKey(ur_project_coderesource_bolwname).Contents = strENTRY
                    Exit For
                End If
            Next strENTRY
        End Function 'Store_ProjectResourceName

        Public Shared Function Update_Form_Title(ur_form As dbUserInput, ur_userbowl_cart As Have.sUserBowl, ur_script_file_path As String) As Integer
            Update_Form_Title = 1
            ur_form.Text = ur_script_file_path
        End Function 'Update_Form_Title

        Public Shared Function Update_Window_Color(ur_form As dbUserInput, ur_report_output As String) As Integer
            Update_Window_Color = 0
            If StartingWithText(ur_report_output, strlit_RED) Then
                ur_form.BackColor = System.Drawing.Color.Red
                Update_Window_Color = 0
            ElseIf StartingWithText(ur_report_output, strline_GREEN) Then
                ur_form.BackColor = System.Drawing.Color.Green
                Update_Window_Color = 0
            End If
        End Function 'Update_Window_Color

        Public Shared Function Write_NoticeMessage(ur_noticemsg_tbox As dbUserInput.componentTextBox, ur_export_notice_msg As Strap) As Integer
            Write_NoticeMessage = 0
            If ur_export_notice_msg.HasText Then
                ur_noticemsg_tbox.Text = ur_export_notice_msg.ToString
                Write_NoticeMessage = 1
            End If
        End Function 'Write_NoticeMessage
    End Class 'Assistant


    Partial Public Class Have
        Private Shared prv_envWindowsCboard As glblWindowsCboard
        Private Shared prv_envWindowsMsgBox As glblWindowsMsgBox
        Private Shared prv_envWindowsVar As glblWindowsVar
        Private Shared prv_envWindowsFS As glblWindowsFS
        Private Shared prv_tblUserBowl As sUserBowl

        <System.Diagnostics.DebuggerHidden()>
        Private Shared Sub Connect()
            If Have.prv_tblUserBowl Is Nothing Then
                Have.prv_envWindowsCboard = New glblWindowsCboard
                Have.prv_envWindowsMsgBox = New glblWindowsMsgBox
                Have.prv_envWindowsVar = New glblWindowsVar
                Have.prv_envWindowsFS = New glblWindowsFS
                Have.prv_tblUserBowl = New sUserBowl
            End If 'sdaTCOL_NAME
        End Sub 'Connect
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsCboardEnv() As glblWindowsCboard
            Call Have.Connect()
            WindowsCboardEnv = Have.prv_envWindowsCboard
        End Function

        Public Class glblWindowsCboard
            <System.Diagnostics.DebuggerHidden()>
            Public Function SetText(ur_text As String) As Integer
                SetText = glbl.gCboard.SetText(ur_text)
            End Function
        End Class 'glblWindowsCboard
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsMsgBoxEnv() As glblWindowsMsgBox
            Call Have.Connect()
            WindowsMsgBoxEnv = Have.prv_envWindowsMsgBox
        End Function

        Public Class glblWindowsMsgBox
            <System.Diagnostics.DebuggerHidden()>
            Public Function GetResult(ur_message As String, Optional ur_style As MsgBoxStyle = MsgBoxStyle.OkOnly) As MsgBoxResult
                Dim strAPP_NAME = Have.UserBowl.SelKey(enmUN.app_name).Contents
                GetResult = glbl.gMsgBox.GetResult(ur_message, ur_style, strAPP_NAME)
            End Function
        End Class 'glblWindowsMsgBox
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsEnvVar() As glblWindowsVar
            Call Have.Connect()
            WindowsEnvVar = Have.prv_envWindowsVar
        End Function

        Public Class glblWindowsVar
            Public Function ExpandEnvironmentVariables(ur_path As String) As String
                ExpandEnvironmentVariables = Mx.glbl.gEnvironment.ExpandEnvironmentVariables(ur_path)
            End Function
        End Class 'glblWindowsVar
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsFSEnv() As glblWindowsFS
            Call Have.Connect()
            WindowsFSEnv = Have.prv_envWindowsFS
        End Function

        Public Class glblWindowsFS
            <System.Diagnostics.DebuggerHidden()>
            Public Function GetFiles(ur_search_filespec As MxText.FileName, Optional ur_recurse_option As System.IO.SearchOption = System.IO.SearchOption.TopDirectoryOnly) As Sdata
                Try
                    GetFiles = New Sdata().dList(glbl.gWindowsFS.GetFiles(ur_search_filespec.gParentDir, ur_search_filespec.Name, ur_recurse_option))
                Catch ex As System.Exception
                    GetFiles = New Sdata
                End Try
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function ReadAllLines(ur_file_path As String) As Mx.Sdata
                ReadAllLines = New Mx.Sdata().dList(System.IO.File.ReadAllLines(ur_file_path, Mx.gUTF8_FileEncoding))
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function ReadAllText(ur_file_path As String) As String
                ReadAllText = System.IO.File.ReadAllText(ur_file_path, Mx.gUTF8_FileEncoding)
            End Function
        End Class 'glblWindowsFS
    End Class 'Have


    Public Class enmUB
        Inherits bitBASE
        Public Shared bowl_name As enmUB = TRow(Of enmUB).glbl.NewBitBase()
        Public Shared contents As enmUB = TRow(Of enmUB).glbl.NewBitBase()
    End Class

    Public Class enmUN
        Inherits bitBASE
        Public Shared app_folder As zapp_folder = TRow(Of enmUN).glbl.Trbase(Of zapp_folder).NewBitBase() : Public Class zapp_folder : Inherits enmUN : End Class
        Public Shared app_name As zapp_name = TRow(Of enmUN).glbl.Trbase(Of zapp_name).NewBitBase() : Public Class zapp_name : Inherits enmUN : End Class
        Public Shared app_path As zapp_path = TRow(Of enmUN).glbl.Trbase(Of zapp_path).NewBitBase() : Public Class zapp_path : Inherits enmUN : End Class
        Public Shared audit_parms_to_cboard As zaudit_parms_to_cboard = TRow(Of enmUN).glbl.Trbase(Of zaudit_parms_to_cboard).NewBitBase() : Public Class zaudit_parms_to_cboard : Inherits enmUN : End Class
        Public Shared background_color As zbackground_color = TRow(Of enmUN).glbl.Trbase(Of zbackground_color).NewBitBase() : Public Class zbackground_color : Inherits enmUN : End Class
        Public Shared cmdline_curexe As zcmdline_curexe = TRow(Of enmUN).glbl.Trbase(Of zcmdline_curexe).NewBitBase() : Public Class zcmdline_curexe : Inherits enmUN : End Class
        Public Shared cmdline_orig As zcmdline_orig = TRow(Of enmUN).glbl.Trbase(Of zcmdline_orig).NewBitBase() : Public Class zcmdline_orig : Inherits enmUN : End Class
        Public Shared cmdline_table As zcmdline_table = TRow(Of enmUN).glbl.Trbase(Of zcmdline_table).NewBitBase() : Public Class zcmdline_table : Inherits enmUN : End Class
        Public Shared export_project_code As zexport_project_code = TRow(Of enmUN).glbl.Trbase(Of zexport_project_code).NewBitBase() : Public Class zexport_project_code : Inherits enmUN : End Class
        Public Shared compiler_exe As zcompiler_exe = TRow(Of enmUN).glbl.Trbase(Of zcompiler_exe).NewBitBase() : Public Class zcompiler_exe : Inherits enmUN : End Class
        Public Shared project_code_zip As zproject_code_zip = TRow(Of enmUN).glbl.Trbase(Of zproject_code_zip).NewBitBase() : Public Class zproject_code_zip : Inherits enmUN : End Class
        Public Shared project_code_resource As zproject_code_resource = TRow(Of enmUN).glbl.Trbase(Of zproject_code_resource).NewBitBase() : Public Class zproject_code_resource : Inherits enmUN : End Class
        Public Shared path As zpath = TRow(Of enmUN).glbl.Trbase(Of zpath).NewBitBase() : Public Class zpath : Inherits enmUN : End Class
        Public Shared window_status As zwindow_status = TRow(Of enmUN).glbl.Trbase(Of zwindow_status).NewBitBase() : Public Class zwindow_status : Inherits enmUN : End Class
    End Class

    Partial Public Class Have
        Public Shared FirstConnect As Object
        Public Shared CmdLineText As String
        Public Shared CurAssembly As System.Reflection.Assembly
        Public Shared CurExe As String

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function UserBowl() As sUserBowl
            Dim bolFIRST_INIT = (Have.FirstConnect Is Nothing)
            Call Have.Connect()
            UserBowl = Have.prv_tblUserBowl
            If bolFIRST_INIT Then
                Have.FirstConnect = "Done"
                Dim apppath_bowlname = enmUN.app_path
                Dim appname_bowlname = enmUN.app_name
                Dim appfolder_bowlname = enmUN.app_folder
                Dim curexe_bowlname = enmUN.cmdline_curexe
                Dim cmdline_orig_bowlname = enmUN.cmdline_orig
                Dim cmdline_table_bowlname = enmUN.cmdline_table
                Dim cmdexport_audit_bowlname = enmUN.audit_parms_to_cboard
                Dim compiler_exe_bowlname = enmUN.compiler_exe
                Dim path_vbns_bowlname = enmUN.path
                Call Have.prv_tblUserBowl.UpdFrom_Application(Have.CurAssembly, Have.CurExe, apppath_bowlname, appname_bowlname, appfolder_bowlname, curexe_bowlname)
                Call Have.prv_tblUserBowl.UpdFrom_CommandLine(Have.CmdLineText, compiler_exe_bowlname, path_vbns_bowlname, cmdline_orig_bowlname, cmdline_table_bowlname)
                'Have.prv_tblUserBowl.SelKey(cmdexport_audit_bowlname).Contents = "1"
                Call Have.prv_tblUserBowl.UpdCboard_FromAudit(cmdexport_audit_bowlname)
            End If 'bolFIRST_INIT
        End Function 'UserBowl

        Public Class rUserBowl
            Inherits TRow(Of enmUB)

            Public Property Contents As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Contents = Me.v(enmUB.contents)
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(value As String)
                    Me.v(enmUB.contents) = value
                End Set
            End Property 'Contents
        End Class 'rUserBowl

        Public Class sUserBowl
            Inherits Mx.TablePKEnum(Of enmUB, enmUN, rUserBowl)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub UpdCboard_FromAudit(cmdexport_audit_bowlname As enmUN.zaudit_parms_to_cboard)
                If Mx.HasText(Me.SelKey(cmdexport_audit_bowlname).v(enmUB.contents)) Then
                    Dim strAUDIT = Me.ToString(True)
                    Dim ins_msg = Have.WindowsMsgBoxEnv.GetResult(
                        ur_message:=Me.SelKey(enmUN.app_name).v(enmUB.contents),
                        ur_style:=MsgBoxStyle.OkCancel
                        )
                    If ins_msg = MsgBoxResult.Ok Then
                        Have.WindowsCboardEnv.SetText(
                            strAUDIT
                            )
                    End If
                End If
            End Sub 'UpdCboard_FromAudit

            <System.Diagnostics.DebuggerHidden()>
            Public Function UpdFrom_Application(ur_cur_assembly As System.Reflection.Assembly, ur_curdir As String, ur_apppath_bowlname As enmUN.zapp_path, ur_appname_bowlname As enmUN.zapp_name, ur_appfolder_bowlname As enmUN.zapp_folder, ur_curexe_bowlname As enmUN.zcmdline_curexe) As sUserBowl
                UpdFrom_Application = Me
                Dim strCUR_EXE_PATH = ur_cur_assembly.Location
                If Mx.HasText(strCUR_EXE_PATH) = False Then
                    strCUR_EXE_PATH = ur_curdir
                End If

                Dim flnAPP_PATH = Mx.FileNamed().d(strCUR_EXE_PATH.Replace("\bin\Debug", Mx.mt))
                Me.SelKey(ur_apppath_bowlname).Contents = flnAPP_PATH
                Me.SelKey(ur_appname_bowlname).Contents = flnAPP_PATH.FileGroup
                Me.SelKey(ur_appfolder_bowlname).Contents = flnAPP_PATH.ParentDir
                Me.SelKey(ur_curexe_bowlname).Contents = strCUR_EXE_PATH
            End Function 'UpdFrom_Application

            <System.Diagnostics.DebuggerHidden()>
            Public Function UpdFrom_CommandLine(ur_cmdline_text As String, ur_compiler_exe_bowlname As enmUN.zcompiler_exe, ur_path_vbns_bowlname As enmUN.zpath, ur_cmdline_orig_bowlname As enmUN.zcmdline_orig, ur_cmdline_table_bowlname As enmUN.zcmdline_table) As sUserBowl
                UpdFrom_CommandLine = Me
                Dim arlCMD_RET = Mx.MxText.Cmdline_UB(Of enmUN, enmUB).CommandLine_UBParm(enmUB.bowl_name, enmUB.contents, ur_cmdline_text, ur_compiler_exe_bowlname, ur_path_vbns_bowlname)
                Me.SelKey(ur_cmdline_orig_bowlname).Contents = Mx.qs & ur_cmdline_text.Replace(Mx.qs, Mx.qs & Mx.qs) & Mx.qs
                Me.SelKey(ur_cmdline_table_bowlname).Contents = Mx.qs & arlCMD_RET.ttbCMD_PARM.ToString(True).Replace(Mx.qs, Mx.qs & Mx.qs) & Mx.qs
                For Each trwPARM In arlCMD_RET.ttbUB_PARM
                    For Each trwBOWL In Me.Sel(enmUB.bowl_name, trwPARM.v(enmUB.bowl_name)).SelAll
                        If Mx.HasText(trwBOWL.Contents) = False Then
                            trwBOWL.Contents = trwPARM.v(enmUB.contents)
                        End If
                    Next trwBOWL
                Next trwPARM
            End Function 'UpdFrom_CommandLine

            <System.Diagnostics.DebuggerHidden()>
            Public Function ToCboard(ur_hdr As Boolean) As Integer
                ToCboard = Mx.glbl.gCboard.SetText(Me.ToString(ur_hdr))
            End Function
        End Class 'sUserBowl
    End Class 'UB, UN
End Namespace 'Mx