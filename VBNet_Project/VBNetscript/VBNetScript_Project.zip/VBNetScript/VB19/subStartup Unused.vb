Option Strict On
Namespace My
    Partial Friend Class MyApplication
        Sub Main(sender As Object, e As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs) Handles Me.Startup
            Mx.Want.TestReferencedAssemblies_errhnd(e)
            'Next goes to frmInput_1_Load, then Want.Compile_And_Run_Script
        End Sub
    End Class
End Namespace

Namespace Mx
    Partial Public Class Want
        Public Shared Sub TestReferencedAssemblies_errhnd(ur_startup_event_args As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs)
            Dim objERR_LIST = New ErrListBase : Try
                Call Assistant.TestReferencedAssemblies()

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                MsgBox(objERR_LIST.ToString, , My.Application.Info.Title)
                ur_startup_event_args.Cancel = True
            End If
        End Sub 'TestReferencedAssemblies_errhnd
    End Class 'Want
    
    Partial Public Class Assistant
        Public Shared Sub TestReferencedAssemblies()
            'Will error if DLL does is not available
            Dim objV1 = System.Data.SqlClient.SortOrder.Ascending
        End Sub 'TestReferencedAssemblies
    End Class 'Assistant
End Namespace 'Mx
