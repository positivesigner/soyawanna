Option Strict On
Namespace Mx
    Public Class dbUserInput
        Private objINPUT_FORM As Mx2.Mock.Form
        Public txtNotice_Message As componentTextBox

        <System.Diagnostics.DebuggerHidden()>
        Public Sub New(ur_input_form As Mx2.Mock.Form, ur_notice_message_textbox As Mx2.Mock.TextBox)
            objINPUT_FORM = ur_input_form
            Me.txtNotice_Message = New componentTextBox(ur_notice_message_textbox)
        End Sub 'New

        <System.Diagnostics.DebuggerHidden()>
        Public Sub Close()
            If objINPUT_FORM IsNot Nothing Then
                objINPUT_FORM.Close()
            End If
        End Sub

        Public Property BackColor As System.Drawing.Color
            <System.Diagnostics.DebuggerHidden()>
            Get
                BackColor = Nothing
                If objINPUT_FORM IsNot Nothing Then
                    BackColor = objINPUT_FORM.BackColor
                End If
            End Get
            <System.Diagnostics.DebuggerHidden()>
            Set(value As System.Drawing.Color)
                If objINPUT_FORM IsNot Nothing Then
                    objINPUT_FORM.BackColor = value
                End If
            End Set
        End Property 'BackColor

        Public Property Text As String
            <System.Diagnostics.DebuggerHidden()>
            Get
                Text = mt
                If objINPUT_FORM IsNot Nothing Then
                    Text = objINPUT_FORM.Text
                End If
            End Get
            <System.Diagnostics.DebuggerHidden()>
            Set(value As String)
                If objINPUT_FORM IsNot Nothing Then
                    objINPUT_FORM.Text = value
                End If
            End Set
        End Property 'Text

        Public Class componentTextBox
            Private objTEXT_BOX As Mx2.Mock.TextBox

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New(ur_textbox As Mx2.Mock.TextBox)
                objTEXT_BOX = ur_textbox
            End Sub

            Public Property Text As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Text = mt
                    If objTEXT_BOX IsNot Nothing Then
                        Text = objTEXT_BOX.Text
                    End If
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(value As String)
                    If objTEXT_BOX IsNot Nothing Then
                        objTEXT_BOX.Text = value
                    End If
                End Set
            End Property 'Text
        End Class 'componentTextBox
    End Class 'dbUserInput
End Namespace 'Mx
