Namespace Mx2
    Public Class Mock
        Public Class TextBox
            Public Text As String

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Me.Text = Mx.mt
            End Sub
        End Class 'TextBox

        Public Class Form
            Public BackColor As System.Drawing.Color
            Public Text As String

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Me.BackColor = Nothing
                Me.Text = Mx.mt
            End Sub

            Public Sub Close()
            End Sub
        End Class 'Form
    End Class 'Mock

    Public Class UserAction
        Public Shared Function CompileCode_Report_errhnd(ur_cur_assembly As System.Reflection.Assembly, ur_commandline_text As String, Optional ur_curexe As String = "") As Mx.Strap
            Have.CurAssembly = ur_cur_assembly
            Have.CmdLineText = ur_commandline_text
            Have.CurExe = ur_curexe
            Dim stpRET = Mx.Strapd() : CompileCode_Report_errhnd = stpRET : Dim objERR_LIST = New Mx.ErrListBase : Try

                stpRET.d("RED").dLine()
                Dim windowsfs_env = Have.WindowsFSEnv
                Dim windowsshell_env = Have.WindowsShell
                Dim userbowl_cart = Have.UserBowl
                Dim appfolder_bowlname = enmUN.app_folder
                Dim persistpath_bowlname = enmUN.pesist_path
                Dim vbnetscript_path_bowlname = enmUN.vbnetscript_path
                Dim mocktest_cart = Have.MockTest
                Dim testlist_file_bowlname = enmMT.test_list_file
                Dim mocktest_code_bowlname = enmMT.mock_test_code
                Dim mocktest_result_bowlname = enmMT.mock_expect_result
                Dim testbase_file_bowlname = enmMT.test_base_file
                Dim testlist_line_bowlname = enmMT.test_list_line
                Dim mocktest_type_bowlname = enmMT.mock_test_type
                Dim testrun_result_bowlname = enmMT.test_run_result
                Dim testpass_count_bowlname = enmMT.test_pass_count

                Dim updated_record_count = Assistant.Store_VBNetScript_Path(userbowl_cart, appfolder_bowlname, vbnetscript_path_bowlname)
                Dim added_test_count = Assistant.Load_MockTest_commandline_Files(mocktest_cart, userbowl_cart, appfolder_bowlname, windowsfs_env)
                Dim updated_test_count = Assistant.Load_MockTest_action_Files(mocktest_cart, testlist_file_bowlname, testbase_file_bowlname, windowsfs_env)
                added_test_count = Assistant.Load_MockTest_expected_result_Files(mocktest_cart, testlist_file_bowlname, testlist_line_bowlname, testbase_file_bowlname, mocktest_type_bowlname, mocktest_code_bowlname, mocktest_result_bowlname, windowsfs_env)
                Dim ran_test_count = Assistant.Gather_MockTest_run_Results(mocktest_cart, testlist_file_bowlname, testlist_line_bowlname, testbase_file_bowlname, mocktest_type_bowlname, mocktest_code_bowlname, mocktest_result_bowlname, testrun_result_bowlname, testpass_count_bowlname, userbowl_cart, appfolder_bowlname, vbnetscript_path_bowlname, windowsfs_env, windowsshell_env)
                Dim report_line_count = Assistant.Compile_MockTest_results_Report(mocktest_cart, testrun_result_bowlname, testpass_count_bowlname, stpRET)

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                stpRET.Clear().d(objERR_LIST.ToString)
            End If
        End Function 'CompileCode_Report_errhnd
    End Class 'UserAction

    Public Class Assistant
        Public Shared strlit_MOCKTEST_FOLDER_STAR_DOT_MOCK_COMMANDLINE_TXT = "MockTest\*.testlist.txt"
        Public Shared strlit_ATSIGN = "@"
        Public Shared strlit_HYPHEN = "-"
        Public Shared strlit_HYPHEN_SP = "- "
        Public Shared strlit_DONE = "DONE"
        Public Shared strlit_OUTPUT = "OUTPUT"
        Public Shared strlit_VBNS = "VBNS"
        Public Shared strlit_VBNETSCRIPT_EXE = "vbnetscript.exe"
        Public Shared strlit_FSLASH_PATH_EQ = "/path="
        Public Shared strlit_DLL = "DLL"
        Public Shared strlit_IN_MEMORY = "InMemory"

        Public Shared Function Compile_MockTest_results_Report(ur_mocktest_cart As Have.sMockTest, ur_testrun_result_bowlname As enmMT.ztest_run_result, ur_testpass_count_bowlname As enmMT.ztest_pass_count, ur_report As Mx.Strap) As Integer
            Dim intTEST_COUNT = ur_mocktest_cart.SelAll.Count
            Dim intTEST_PASS = 0
            Dim intTEST_FAIL = 0
            For Each trwMOCK_TEST In ur_mocktest_cart.SelAll
                intTEST_PASS += CInt(trwMOCK_TEST.v(ur_testpass_count_bowlname))
            Next trwMOCK_TEST

            intTEST_FAIL = intTEST_COUNT - intTEST_PASS

            If intTEST_COUNT = intTEST_PASS Then
                ur_report.Clear().d("GREEN").dLine()
            Else
                ur_report.dLine.dLine(Have.UserBowl.ToString(True))
            End If

            ur_report.dLineNB(intTEST_PASS.ToString).dS("Tests passed")
            ur_report.dLineNB(intTEST_FAIL.ToString).dS("Tests failed")
            For Each rowMOCK_TEST In ur_mocktest_cart.SelAll
                Dim strRESULT = rowMOCK_TEST.v(ur_testrun_result_bowlname)
                If Mx.HasText(strRESULT) Then
                    ur_report.dLine()
                    ur_report.dLine()
                    ur_report.dLine(strRESULT)
                End If
            Next rowMOCK_TEST

            Compile_MockTest_results_Report = intTEST_COUNT
        End Function 'Compile_MockTest_results_Report

        Public Shared Function Gather_MockTest_run_Results(ur_mocktest_cart As Have.sMockTest, ur_testlist_file_bowlname As enmMT.ztest_list_file, ur_testlist_line_userbowl As enmMT.ztest_list_line, ur_testbase_file_bowlname As enmMT.ztest_base_file, ur_mocktest_type_bowlname As enmMT.zmock_test_type, ur_mocktest_code_bowlname As enmMT.zmock_test_code, ur_mocktest_result_bowlname As enmMT.zmock_expect_result, ur_testrun_result_bowlname As enmMT.ztest_run_result, ur_testpass_count_bowlname As enmMT.ztest_pass_count, ur_userbowl_cart As Have.sUserBowl, ur_appfolder_bowlname As enmUN.zapp_folder, ur_vbnetscript_bowlname As enmUN.zvbnetscript_path, ur_windowsfs_env As Have.glblWindowsFS, ur_windowsshell_env As Have.glblWindowsShell) As Integer
            Dim retREC_TESTED = 0
            For Each trwMOCK_TEST In ur_mocktest_cart.SelAll
                Dim flnCOMMANDLINE_FILE = Mx.FileNamed().d(trwMOCK_TEST.v(ur_testlist_file_bowlname))
                Dim flnTEST_CODEFILE_PATH = Mx.FileNamed().d(trwMOCK_TEST.v(ur_testbase_file_bowlname))
                Dim strTEST_CODEFILE_LINE = trwMOCK_TEST.v(ur_testlist_line_userbowl)
                Dim stpTEST_RESULT = Mx.Strapd
                retREC_TESTED += 1
                Dim strTEST_TYPE = trwMOCK_TEST.v(ur_mocktest_type_bowlname)
                Dim strPROGRAM_TEXT = trwMOCK_TEST.v(ur_mocktest_code_bowlname)
                Dim strEXPECTED_RESULT = trwMOCK_TEST.v(ur_mocktest_result_bowlname)
                Dim cur_assembly = Have.CurAssembly
                Dim mockNoticeMsgTbox = New Mock.TextBox
                Dim mockForm = New Mock.Form
                Dim mockUserInput = New Mx.dbUserInput(mockForm, mockNoticeMsgTbox)

                Dim stpTEST_COMMANDLINE = Mx.Strapd().d(strlit_VBNETSCRIPT_EXE).dS(strlit_FSLASH_PATH_EQ).dSprtr(Mx.qs, flnTEST_CODEFILE_PATH).d(Mx.qs)
                Mx.Have.CmdLineText = stpTEST_COMMANDLINE
                Dim userbowl_cart = Mx.Have.UserBowl
                Dim appfolder_bowlname = Mx.enmUN.app_folder
                Dim inpath_bowlname = Mx.enmUN.path
                userbowl_cart.SelKey(appfolder_bowlname).Contents = ur_userbowl_cart.SelKey(ur_appfolder_bowlname).Contents
                userbowl_cart.SelKey(inpath_bowlname).Contents = flnTEST_CODEFILE_PATH.ToString
                ': assign mock ui fields

                Dim strFOUND_RESULT = Mx.mt
                If Mx.AreEqual(strTEST_TYPE, strlit_IN_MEMORY) Then
                    Call Mx.UserAction.Compile_And_Run_Script_errhnd(mockUserInput, cur_assembly, stpTEST_COMMANDLINE)
                    strFOUND_RESULT = mockNoticeMsgTbox.Text

                ElseIf Mx.AreEqual(strTEST_TYPE, strlit_DLL) Then
                    Dim stpDLL_RET = Assistant.Run_VBNetScript(ur_userbowl_cart, strPROGRAM_TEXT, flnCOMMANDLINE_FILE, ur_vbnetscript_bowlname, ur_windowsfs_env, ur_windowsshell_env)
                    strFOUND_RESULT = stpDLL_RET.ToString
                Else
                    strFOUND_RESULT = Mx.Strapd().d("Unknown Test type:").dS(strTEST_TYPE)
                End If 'strTEST_TYPE

                Dim intTEST_PASS = 0
                If strFOUND_RESULT = strEXPECTED_RESULT Then
                    intTEST_PASS += 1

                Else
                    stpTEST_RESULT.dLine().dLine()
                    Call stpTEST_RESULT.dSprtr("`", flnTEST_CODEFILE_PATH.Name).d("`").dS("ln.").d(strTEST_CODEFILE_LINE).dS("").dSprtr("`", strPROGRAM_TEXT).d("`").dS("expected").dS("").dSprtr("`", strEXPECTED_RESULT.ToString).d("`").d("; received").dSprtr("`", strFOUND_RESULT).d("`")
                End If 'strFOUND_RESULT

                trwMOCK_TEST.vt(ur_testrun_result_bowlname, stpTEST_RESULT.ToString)
                trwMOCK_TEST.vt(ur_testpass_count_bowlname, intTEST_PASS.ToString)
            Next trwMOCK_TEST

            Gather_MockTest_run_Results = retREC_TESTED
        End Function 'Gather_MockTest_run_Results

        Public Shared Function Load_MockTest_action_Files(ur_mocktest_cart As Have.sMockTest, ur_testlist_file_userbowl As enmMT.ztest_list_file, ur_testbase_file_userbowl As enmMT.ztest_base_file, ur_windowsfs_env As Have.glblWindowsFS) As Integer
            Dim retREC_UPDATED = 0
            For Each trwMOCK_TEST In ur_mocktest_cart.SelAll
                Dim flnTEST_FILE_PATH = Mx.FileNamed.d(trwMOCK_TEST.v(ur_testlist_file_userbowl))
                Dim flnTEST_CODE_PATH = flnTEST_FILE_PATH.gParentDir.d(Mx.FileNamed().d(flnTEST_FILE_PATH.FileGroup).FileGroup)
                For Each strTEST_CODE_PATH In ur_windowsfs_env.GetFiles(flnTEST_CODE_PATH)
                    retREC_UPDATED += 1
                    trwMOCK_TEST.vt(ur_testbase_file_userbowl, strTEST_CODE_PATH)
                    Exit For
                Next strTEST_CODE_PATH
            Next trwMOCK_TEST

            Load_MockTest_action_Files = retREC_UPDATED
        End Function 'Load_MockTest_action_Files

        Public Shared Function Load_MockTest_commandline_Files(ur_mocktest_cart As Have.sMockTest, ur_userbowl_cart As Have.sUserBowl, ur_appfolder_bowlname As enmUN.zapp_folder, ur_windowsfs_env As Have.glblWindowsFS) As Integer
            Dim retREC_ADDED = 0
            Dim flnAPP_FOLDER = Mx.FileNamed.d(ur_userbowl_cart.SelKey(ur_appfolder_bowlname).Contents)
            Dim flnSEARCH_MOCK_COMMANDLINE = flnAPP_FOLDER.gParentDir.d(strlit_MOCKTEST_FOLDER_STAR_DOT_MOCK_COMMANDLINE_TXT)

            For Each strPATH In ur_windowsfs_env.GetFiles(flnSEARCH_MOCK_COMMANDLINE)
                Dim trwMOCK_TEST = ur_mocktest_cart.InsKey(strPATH, 1)
                retREC_ADDED += 1
            Next strPATH

            Load_MockTest_commandline_Files = retREC_ADDED
        End Function 'Load_MockTest_commandline_Files

        Public Shared Function Load_MockTest_expected_result_Files(ur_mocktest_cart As Have.sMockTest, ur_testlist_file_userbowl As enmMT.ztest_list_file, ur_testlist_line_userbowl As enmMT.ztest_list_line, ur_testbase_file_userbowl As enmMT.ztest_base_file, ur_test_type_userbowl As enmMT.zmock_test_type, ur_mocktest_code_userbowl As enmMT.zmock_test_code, ur_mocktest_result_userbowl As enmMT.zmock_expect_result, ur_windowsfs_env As Have.glblWindowsFS) As Integer
            Dim retREC_ADDED = 0
            For Each trwBASE_TEST In ur_mocktest_cart.SelAll
                Dim trwMOCK_TEST = trwBASE_TEST
                Dim flnTEST_LIST_PATH = Mx.FileNamed.d(trwMOCK_TEST.v(ur_testlist_file_userbowl))
                Dim sdaTEST_LINES = ur_windowsfs_env.ReadAllLines(flnTEST_LIST_PATH)
                Dim intFILE_TEST_COUNT = 0
                For Each kvpLINE In sdaTEST_LINES.kvp
                    If Mx.StartingWithText(kvpLINE.v, strlit_ATSIGN) Then
                        intFILE_TEST_COUNT += 1
                        retREC_ADDED += 1
                        If intFILE_TEST_COUNT > 1 Then
                            trwMOCK_TEST = ur_mocktest_cart.InsKey(trwBASE_TEST.v(ur_testlist_file_userbowl), kvpLINE.Indexb1.ToString)
                            trwMOCK_TEST.vt(ur_testbase_file_userbowl, trwBASE_TEST.v(ur_testbase_file_userbowl))
                        End If

                        trwMOCK_TEST.vt(ur_test_type_userbowl, Mid(kvpLINE.v, 2))
                        'If Mx.StartingWithText(strCUR_LINE, ":") Then
                        Dim stpPROGRAM_TEXT = Mx.Strapd()
                        Dim stpEXPECTED_RESULT = Mx.Strapd()
                        For CODECTR = kvpLINE.Indexb1 + 1 To kvpLINE.LastIndexb1
                            Dim strCODE_LINE = sdaTEST_LINES.v_b1(CODECTR)
                            If Mx.StartingWithText(strCODE_LINE, strlit_HYPHEN) Then
                                For EXPECTCTR = CODECTR To kvpLINE.LastIndexb1
                                    Dim strEXPECTED_RESULT_LINE = sdaTEST_LINES.v_b1(EXPECTCTR)
                                    If Mx.StartingWithText(strEXPECTED_RESULT_LINE, strlit_HYPHEN) = False Then
                                        Exit For

                                    ElseIf Mx.StartingWithText(strEXPECTED_RESULT_LINE, strlit_HYPHEN_SP) Then
                                        stpEXPECTED_RESULT.dLineNB(Mid(strEXPECTED_RESULT_LINE, 3))
                                    End If 'strEXPECTED_RESULT_LINE
                                Next EXPECTCTR

                                Exit For

                            Else 'strCODE_LINE
                                stpPROGRAM_TEXT.dLineNB(strCODE_LINE)
                            End If 'strCODE_LINE
                        Next CODECTR

                        trwMOCK_TEST.vt(ur_mocktest_code_userbowl, stpPROGRAM_TEXT)
                        trwMOCK_TEST.vt(ur_mocktest_result_userbowl, stpEXPECTED_RESULT)
                    End If 'kvpLINE
                Next kvpLINE
            Next trwBASE_TEST

            Load_MockTest_expected_result_Files = retREC_ADDED
        End Function 'Load_MockTest_expected_result_Files

        Public Shared Function Run_VBNetScript(ur_userbowl_cart As Have.sUserBowl, ur_script_code_text As String, ur_script_file_path As Mx.MxText.FileName, ur_vbnetscript_path_bowlname As enmUN.zvbnetscript_path, ur_windowsfs_env As Have.glblWindowsFS, ur_windowsshell_env As Have.glblWindowsShell) As Mx.Strap
            Dim retPROGRAM_OUTPUT = Mx.Strapd()
            If ur_script_code_text.Length > 0 Then
                Dim flnDATED_SCRIPT = ur_script_file_path.gParentDir.dNowTextYMDHMS(ur_script_file_path.Name).dAppendEXT(strlit_VBNS)
                Dim flnOUTPUT_SCRIPT = flnDATED_SCRIPT.gCopy.dAppendEXT(strlit_OUTPUT)
                Dim flnDONE_SCRIPT = flnDATED_SCRIPT.gCopy.dAppendEXT(strlit_DONE)
                Dim strVBNETSCRIPT_EXE_PATH = ur_userbowl_cart.SelKey(ur_vbnetscript_path_bowlname).Contents
                If ur_windowsfs_env.Exists(strVBNETSCRIPT_EXE_PATH) = False Then
                    retPROGRAM_OUTPUT = Mx.Strapd().d("Could not find VBNetScript program from DeveloperSettings:").dS(strVBNETSCRIPT_EXE_PATH)
                End If

                If retPROGRAM_OUTPUT.HasText = False Then
                    Call ur_windowsfs_env.WriteAllText(flnDATED_SCRIPT, ur_script_code_text)
                    Dim stpOPTION_PATH = Mx.Strapd().d(strlit_FSLASH_PATH_EQ).dSprtr(Mx.qs, flnDATED_SCRIPT.ToString).d(Mx.qs)
                    Call ur_windowsshell_env.Start_Windows_Program(strVBNETSCRIPT_EXE_PATH, stpOPTION_PATH)
                    Dim bolFOUND_OUTPUT = False
                    For EXCCTR = 10 To 1 Step -1
                        System.Threading.Thread.Sleep(1000)
                        If ur_windowsfs_env.Exists(flnDONE_SCRIPT) Then
                            bolFOUND_OUTPUT = True
                            Exit For
                        End If
                    Next EXCCTR

                    If bolFOUND_OUTPUT = False Then
                        retPROGRAM_OUTPUT = Mx.Strapd().d("Could not find done file:").dS(flnDONE_SCRIPT.ToString)
                    End If 'bolFOUND_OUTPUT
                End If

                If retPROGRAM_OUTPUT.HasText = False Then
                    If ur_windowsfs_env.Exists(flnDONE_SCRIPT) = False Then
                        retPROGRAM_OUTPUT = Mx.Strapd().d("Could not find done file:").dS(flnDONE_SCRIPT.ToString)
                    End If
                End If

                If retPROGRAM_OUTPUT.HasText = False Then
                    If ur_windowsfs_env.Exists(flnOUTPUT_SCRIPT) = False Then
                        retPROGRAM_OUTPUT = Mx.Strapd().d("Could not find output file:").dS(flnOUTPUT_SCRIPT.ToString)
                    End If
                End If

                If retPROGRAM_OUTPUT.HasText = False Then
                    retPROGRAM_OUTPUT.d(ur_windowsfs_env.ReadAllText(flnOUTPUT_SCRIPT))
                    ur_windowsfs_env.Delete(flnOUTPUT_SCRIPT)
                    ur_windowsfs_env.Delete(flnDONE_SCRIPT)
                End If

                ur_windowsfs_env.Delete(flnDATED_SCRIPT)
            End If 'ur_script_code_text

            Run_VBNetScript = retPROGRAM_OUTPUT
        End Function 'Run_VBNetScript

        Public Shared Function Store_VBNetScript_Path(ur_userbowl_cart As Have.sUserBowl, ur_app_folder As enmUN.zapp_folder, ur_vbnetscript_path_bowlname As enmUN.zvbnetscript_path) As Integer
            Store_VBNetScript_Path = 1
            Dim flnAPP_PARM = Mx.FileNamed().d(ur_userbowl_cart.SelKey(ur_app_folder).Contents).gParentDir.d("Dep").d("VBNetScript.exe")
            ur_userbowl_cart.SelKey(ur_vbnetscript_path_bowlname).Contents = flnAPP_PARM.ToString
        End Function ' Store_VBNetScript_Path
    End Class 'Assistant


    Partial Public Class Have
        Private Shared prv_envWindowsCboard As glblWindowsCboard
        Private Shared prv_envWindowsMsgBox As glblWindowsMsgBox
        Private Shared prv_envWindowsFS As glblWindowsFS
        Private Shared prv_envWindowsShell As glblWindowsShell
        Private Shared prv_envMockTest As sMockTest
        Private Shared prv_tblUserBowl As sUserBowl

        <System.Diagnostics.DebuggerHidden()>
        Private Shared Sub Connect()
            If Have.prv_tblUserBowl Is Nothing Then
                Have.prv_envWindowsCboard = New glblWindowsCboard
                Have.prv_envWindowsMsgBox = New glblWindowsMsgBox
                Have.prv_envWindowsFS = New glblWindowsFS
                Have.prv_envWindowsShell = New glblWindowsShell
                Have.prv_envMockTest = New sMockTest
                Have.prv_tblUserBowl = New sUserBowl
            End If 'sdaTCOL_NAME
        End Sub 'Connect
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsCboardEnv() As glblWindowsCboard
            Call Have.Connect()
            WindowsCboardEnv = Have.prv_envWindowsCboard
        End Function

        Public Class glblWindowsCboard
            <System.Diagnostics.DebuggerHidden()>
            Public Function SetText(ur_text As String) As Integer
                SetText = Mx.glbl.gCboard.SetText(ur_text)
            End Function
        End Class 'glblWindowsCboard
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsMsgBoxEnv() As glblWindowsMsgBox
            Call Have.Connect()
            WindowsMsgBoxEnv = Have.prv_envWindowsMsgBox
        End Function

        Public Class glblWindowsMsgBox
            <System.Diagnostics.DebuggerHidden()>
            Public Function GetResult(ur_message As String, Optional ur_style As MsgBoxStyle = MsgBoxStyle.OkOnly) As MsgBoxResult
                Dim strAPP_NAME = Have.UserBowl.SelKey(enmUN.app_name).Contents
                GetResult = Mx.glbl.gMsgBox.GetResult(ur_message, ur_style, strAPP_NAME)
            End Function
        End Class 'glblWindowsMsgBox
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsFSEnv() As glblWindowsFS
            Call Have.Connect()
            WindowsFSEnv = Have.prv_envWindowsFS
        End Function

        Public Class glblWindowsFS
            <System.Diagnostics.DebuggerHidden()>
            Public Sub Delete(ur_path As String)
                Call Mx.glbl.gWindowsFS.Delete(ur_path)
            End Sub

            <System.Diagnostics.DebuggerHidden()>
            Public Function Exists(ur_search_filepath As Mx.MxText.FileName) As Boolean
                Exists = System.IO.File.Exists(ur_search_filepath)
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function GetFiles(ur_search_filespec As Mx.MxText.FileName, Optional ur_recurse_option As System.IO.SearchOption = System.IO.SearchOption.TopDirectoryOnly) As String()
                Try
                    GetFiles = Mx.glbl.gWindowsFS.GetFiles(ur_search_filespec.gParentDir, ur_search_filespec.Name, ur_recurse_option)
                Catch ex As System.Exception
                    GetFiles = {}
                End Try
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function ReadAllText(ur_file_path As String) As String
                ReadAllText = Mx.glbl.gWindowsFS.ReadAllText(ur_file_path)
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Function ReadAllLines(ur_file_path As String) As Mx.Sdata
                ReadAllLines = New Mx.Sdata().dList(System.IO.File.ReadAllLines(ur_file_path, Mx.gUTF8_FileEncoding))
            End Function

            <System.Diagnostics.DebuggerHidden()>
            Public Sub WriteAllText(ur_file_path As String, ur_text As String)
                Call System.IO.File.WriteAllText(ur_file_path, ur_text, Mx.gUTF8_FileEncoding)
            End Sub
        End Class 'glblWindowsFS
    End Class 'Have

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function WindowsShell() As glblWindowsShell
            Call Have.Connect()
            WindowsShell = Have.prv_envWindowsShell
        End Function

        Public Class glblWindowsShell
            <System.Diagnostics.DebuggerHidden()>
            Public Sub Start_Windows_Program(ur_path As String, ur_parameters As String)
                Call Mx.glbl.gDiagnostics.Start_Windows_Program(ur_path, ur_parameters)
            End Sub

            <System.Diagnostics.DebuggerHidden()>
            Public Sub Sleep(ur_milliseconds As Integer)
                Call Mx.glbl.gThread.Sleep(ur_milliseconds)
            End Sub
        End Class 'glblWindowsShell
    End Class 'Have

    Public Class enmMT
        Inherits Mx.bitBASE
        Public Shared test_list_file As ztest_list_file = Mx.TRow(Of enmMT).glbl.Trbase(Of ztest_list_file).NewBitBase() : Public Class ztest_list_file : Inherits enmMT : End Class
        Public Shared test_list_line As ztest_list_line = Mx.TRow(Of enmMT).glbl.Trbase(Of ztest_list_line).NewBitBase() : Public Class ztest_list_line : Inherits enmMT : End Class
        Public Shared mock_expect_result As zmock_expect_result = Mx.TRow(Of enmMT).glbl.Trbase(Of zmock_expect_result).NewBitBase() : Public Class zmock_expect_result : Inherits enmMT : End Class
        Public Shared mock_test_code As zmock_test_code = Mx.TRow(Of enmMT).glbl.Trbase(Of zmock_test_code).NewBitBase() : Public Class zmock_test_code : Inherits enmMT : End Class
        Public Shared mock_test_type As zmock_test_type = Mx.TRow(Of enmMT).glbl.Trbase(Of zmock_test_type).NewBitBase() : Public Class zmock_test_type : Inherits enmMT : End Class
        Public Shared test_base_file As ztest_base_file = Mx.TRow(Of enmMT).glbl.Trbase(Of ztest_base_file).NewBitBase() : Public Class ztest_base_file : Inherits enmMT : End Class
        Public Shared test_run_result As ztest_run_result = Mx.TRow(Of enmMT).glbl.Trbase(Of ztest_run_result).NewBitBase() : Public Class ztest_run_result : Inherits enmMT : End Class
        Public Shared test_pass_count As ztest_pass_count = Mx.TRow(Of enmMT).glbl.Trbase(Of ztest_pass_count).NewBitBase() : Public Class ztest_pass_count : Inherits enmMT : End Class
    End Class 'enmMT

    Partial Public Class Have
        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function MockTest() As sMockTest
            Call Have.Connect()
            MockTest = Have.prv_envMockTest
        End Function

        Public Class rMockTest
            Inherits Mx.TRow(Of enmMT)

            <System.Diagnostics.DebuggerHidden()>
            Public Function vt(ur_enm As enmMT, ur_val As String) As rMockTest
                vt = Me
                Me.v(ur_enm) = ur_val
            End Function
        End Class 'rMockTest

        Public Class sMockTest
            Inherits Mx.TablePKStr(Of enmMT, rMockTest)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                MyBase.New(2)
            End Sub
        End Class
    End Class 'enmMT

    Public Class enmUB
        Inherits Mx.bitBASE
        Public Shared bowl_name As enmUB = Mx.TRow(Of enmUB).glbl.NewBitBase()
        Public Shared contents As enmUB = Mx.TRow(Of enmUB).glbl.NewBitBase()
    End Class

    Public Class enmUN
        Inherits Mx.bitBASE
        Public Shared app_folder As zapp_folder = Mx.TRow(Of enmUN).glbl.Trbase(Of zapp_folder).NewBitBase() : Public Class zapp_folder : Inherits enmUN : End Class
        Public Shared app_name As zapp_name = Mx.TRow(Of enmUN).glbl.Trbase(Of zapp_name).NewBitBase() : Public Class zapp_name : Inherits enmUN : End Class
        Public Shared app_path As zapp_path = Mx.TRow(Of enmUN).glbl.Trbase(Of zapp_path).NewBitBase() : Public Class zapp_path : Inherits enmUN : End Class
        Public Shared audit_parms_to_cboard As zaudit_parms_to_cboard = Mx.TRow(Of enmUN).glbl.Trbase(Of zaudit_parms_to_cboard).NewBitBase() : Public Class zaudit_parms_to_cboard : Inherits enmUN : End Class
        Public Shared cmdline_curexe As zcmdline_curexe = Mx.TRow(Of enmUN).glbl.Trbase(Of zcmdline_curexe).NewBitBase() : Public Class zcmdline_curexe : Inherits enmUN : End Class
        Public Shared cmdline_orig As zcmdline_orig = Mx.TRow(Of enmUN).glbl.Trbase(Of zcmdline_orig).NewBitBase() : Public Class zcmdline_orig : Inherits enmUN : End Class
        Public Shared cmdline_table As zcmdline_table = Mx.TRow(Of enmUN).glbl.Trbase(Of zcmdline_table).NewBitBase() : Public Class zcmdline_table : Inherits enmUN : End Class
        Public Shared compiler_exe As zcompiler_exe = Mx.TRow(Of enmUN).glbl.Trbase(Of zcompiler_exe).NewBitBase() : Public Class zcompiler_exe : Inherits enmUN : End Class
        Public Shared path_unassigned As zpath_unassigned = Mx.TRow(Of enmUN).glbl.Trbase(Of zpath_unassigned).NewBitBase() : Public Class zpath_unassigned : Inherits enmUN : End Class
        Public Shared pesist_path As zpersist_path = Mx.TRow(Of enmUN).glbl.Trbase(Of zpersist_path).NewBitBase() : Public Class zpersist_path : Inherits enmUN : End Class
        Public Shared vbnetscript_path As zvbnetscript_path = Mx.TRow(Of enmUN).glbl.Trbase(Of zvbnetscript_path).NewBitBase() : Public Class zvbnetscript_path : Inherits enmUN : End Class
    End Class

    Partial Public Class Have
        Public Shared FirstConnect As Object
        Public Shared CmdLineText As String
        Public Shared CurAssembly As System.Reflection.Assembly
        Public Shared CurExe As String

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Function UserBowl() As sUserBowl
            Dim bolFIRST_INIT = (Have.FirstConnect Is Nothing)
            Call Have.Connect()
            UserBowl = Have.prv_tblUserBowl
            If bolFIRST_INIT Then
                Have.FirstConnect = "Done"
                Dim apppath_bowlname = enmUN.app_path
                Dim appname_bowlname = enmUN.app_name
                Dim appfolder_bowlname = enmUN.app_folder
                Dim curexe_bowlname = enmUN.cmdline_curexe
                Dim cmdline_orig_bowlname = enmUN.cmdline_orig
                Dim cmdline_table_bowlname = enmUN.cmdline_table
                Dim cmdexport_audit_bowlname = enmUN.audit_parms_to_cboard
                Dim compiler_exe_bowlname = enmUN.compiler_exe
                Dim path_unassigned_bowlname = enmUN.path_unassigned

                Call Have.prv_tblUserBowl.UpdFrom_Application(Have.CurAssembly, Have.CurExe, apppath_bowlname, appname_bowlname, appfolder_bowlname, curexe_bowlname)
                Call Have.prv_tblUserBowl.UpdFrom_CommandLine(Have.CmdLineText, compiler_exe_bowlname, path_unassigned_bowlname, cmdline_orig_bowlname, cmdline_table_bowlname)
                'Have.prv_tblUserBowl.SelKey(cmdexport_audit_bowlname).Contents = "1"
                Call Have.prv_tblUserBowl.UpdCboard_FromAudit(cmdexport_audit_bowlname)
            End If 'bolFIRST_INIT
        End Function

        Public Class rUserBowl
            Inherits Mx.TRow(Of enmUB)

            Public Property Contents As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Contents = Me.v(enmUB.contents)
                End Get
                <System.Diagnostics.DebuggerHidden()>
                Set(value As String)
                    Me.v(enmUB.contents) = value
                End Set
            End Property 'Contents
        End Class 'rUserBowl

        Public Class sUserBowl
            Inherits Mx.TablePKEnum(Of enmUB, enmUN, rUserBowl)

            <System.Diagnostics.DebuggerHidden()>
            Public Sub UpdCboard_FromAudit(cmdexport_audit_bowlname As enmUN.zaudit_parms_to_cboard)
                If Mx.HasText(Me.SelKey(cmdexport_audit_bowlname).v(enmUB.contents)) Then
                    Dim strAUDIT = Me.ToString(True)
                    Dim ins_msg = Have.WindowsMsgBoxEnv.GetResult(
                        ur_message:=Me.SelKey(enmUN.app_name).v(enmUB.contents),
                        ur_style:=MsgBoxStyle.OkCancel
                        )
                    If ins_msg = MsgBoxResult.Ok Then
                        Have.WindowsCboardEnv.SetText(
                            strAUDIT
                            )
                    End If
                End If
            End Sub 'UpdCboard_FromAudit

            <System.Diagnostics.DebuggerHidden()>
            Public Function UpdFrom_Application(ur_cur_assembly As System.Reflection.Assembly, ur_curdir As String, ur_apppath_bowlname As enmUN.zapp_path, ur_appname_bowlname As enmUN.zapp_name, ur_appfolder_bowlname As enmUN.zapp_folder, ur_curexe_bowlname As enmUN.zcmdline_curexe) As sUserBowl
                UpdFrom_Application = Me
                Dim strCUR_EXE_PATH = ur_cur_assembly.Location
                If Mx.HasText(strCUR_EXE_PATH) = False Then
                    strCUR_EXE_PATH = ur_curdir
                End If

                Dim flnAPP_PATH = Mx.FileNamed().d(strCUR_EXE_PATH.Replace("\bin\Debug", Mx.mt))
                Me.SelKey(ur_apppath_bowlname).Contents = flnAPP_PATH
                Me.SelKey(ur_appname_bowlname).Contents = flnAPP_PATH.FileGroup
                Me.SelKey(ur_appfolder_bowlname).Contents = flnAPP_PATH.ParentDir
                Me.SelKey(ur_curexe_bowlname).Contents = strCUR_EXE_PATH
            End Function 'UpdFrom_Application

            <System.Diagnostics.DebuggerHidden()>
            Public Function UpdFrom_CommandLine(ur_cmdline_text As String, ur_compiler_exe_bowlname As enmUN.zcompiler_exe, ur_path_unassigned_bowlname As enmUN.zpath_unassigned, ur_cmdline_orig_bowlname As enmUN.zcmdline_orig, ur_cmdline_table_bowlname As enmUN.zcmdline_table) As sUserBowl
                UpdFrom_CommandLine = Me
                Dim arlCMD_RET = Mx.MxText.Cmdline_UB(Of enmUN, enmUB).CommandLine_UBParm(enmUB.bowl_name, enmUB.contents, ur_cmdline_text, ur_compiler_exe_bowlname, ur_path_unassigned_bowlname)
                Me.SelKey(ur_cmdline_orig_bowlname).Contents = Mx.qs & ur_cmdline_text.Replace(Mx.qs, Mx.qs & Mx.qs) & Mx.qs
                Me.SelKey(ur_cmdline_table_bowlname).Contents = Mx.qs & arlCMD_RET.ttbCMD_PARM.ToString(True).Replace(Mx.qs, Mx.qs & Mx.qs) & Mx.qs
                For Each trwPARM In arlCMD_RET.ttbUB_PARM
                    For Each trwBOWL In Me.Sel(enmUB.bowl_name, trwPARM.v(enmUB.bowl_name)).SelAll
                        If Mx.HasText(trwBOWL.Contents) = False Then
                            trwBOWL.Contents = trwPARM.v(enmUB.contents)
                        End If
                    Next trwBOWL
                Next trwPARM
            End Function 'UpdFrom_CommandLine

            <System.Diagnostics.DebuggerHidden()>
            Public Function ToCboard(ur_hdr As Boolean) As Integer
                ToCboard = Mx.glbl.gCboard.SetText(Me.ToString(ur_hdr))
            End Function
        End Class 'sUserBowl
    End Class 'UB, UN
End Namespace 'Mx2
