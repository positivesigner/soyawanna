Namespace Mx.ToDo
    Public Class ToBe
        Public Shared Sub Not_2B()
            Microsoft.VisualBasic.MsgBox("All Done", Microsoft.VisualBasic.MsgBoxStyle.OkOnly, "MyNeatProgram")
            End Sub 'Not_2B
        
        End Class 'ToBe
    
    End Namespace 'Mx.ToDo
