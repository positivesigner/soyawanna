Option Strict On
Namespace Mx
    Public Class MxSQL
        <System.Diagnostics.DebuggerHidden()> Public Shared Function Calculate_ConnectionString(ur_cmd_line As CommandParms, ur_db As enmCCol) As Strap
            Dim stpRET = Strapd()
            Calculate_ConnectionString = stpRET
            stpRET.d("Server=@r1;Database=@r2;Integrated Security = SSPI")
            '"User ID" "Password"
            stpRET.r1(ur_cmd_line.v(enmCCol.server))
            stpRET.r2(ur_cmd_line.v(ur_db))
        End Function 'Calculate_ConnectionString

        <System.Diagnostics.DebuggerHidden()> Public Shared Sub Command_InputValb1(ur_sql_cmd As System.Data.SqlClient.SqlCommand, ur_indexb1 As Integer, ur_val As String)
            Call Command_InputValb0(ur_sql_cmd, b0(ur_indexb1), ur_val)
        End Sub 'Command_InputValb1

        <System.Diagnostics.DebuggerHidden()> Public Shared Sub Command_InputValb0(ur_sql_cmd As System.Data.SqlClient.SqlCommand, ur_indexb0 As Integer, ur_val As String)
            If ur_indexb0 < ur_sql_cmd.Parameters.Count Then
                Dim objPARM = ur_sql_cmd.Parameters.Item(ur_indexb0)
                If HasText(ur_val) Then
                    objPARM.Value = ur_val
                Else
                    objPARM.Value = System.DBNull.Value
                End If
            End If
        End Sub 'Command_InputValb0

        <System.Diagnostics.DebuggerHidden()> Public Shared Sub Command_OverwriteParms(ur_sql_cmd As System.Data.SqlClient.SqlCommand, ur_parm_list As Sdata)
            For Each kvpPARM In ur_parm_list.kvp
                Call MxSQL.Command_InputValb1(ur_sql_cmd, kvpPARM.Indexb1, kvpPARM.v)
            Next kvpPARM
        End Sub 'Command_OverwriteParms

        <System.Diagnostics.DebuggerHidden()> Public Shared Sub Command_ResetParms(ur_sql_cmd As System.Data.SqlClient.SqlCommand)
            For Each PRMCTR In New RCTR(ur_sql_cmd.Parameters.Count)
                Dim objPARM = ur_sql_cmd.Parameters.Item(b0(PRMCTR))
                objPARM.Value = System.DBNull.Value
            Next PRMCTR
        End Sub 'Command_ResetParms

        <System.Diagnostics.DebuggerHidden()> Public Shared Function Connection_Init(ur_connection_string As String, ur_retry_count As Integer) As System.Data.SqlClient.SqlConnection
            Dim objRET = New System.Data.SqlClient.SqlConnection(ur_connection_string)
            Connection_Init = objRET
            If objRET.State = System.Data.ConnectionState.Open Then
                objRET.Close()
            End If 'State

            If ur_retry_count > 0 Then
                For RETCTR = ur_retry_count To 1 Step -1
                    Try
                        objRET.Open()
                        Exit For

                    Catch
                        If RETCTR = 1 Then
                            Throw

                        Else 'RETCTR
                            System.Threading.Thread.Sleep(1500)
                        End If 'RETCTR
                    End Try
                Next RETCTR

            Else 'ur_retry_count
                objRET.Open()
            End If 'ur_retry_count

            Call System.Data.SqlClient.SqlConnection.ClearPool(objRET)
        End Function 'Connection_Init

        <System.Diagnostics.DebuggerHidden()> Public Shared Function New_Command_SPExec(ur_sql_conn As System.Data.SqlClient.SqlConnection, ur_command_text As String, ur_parm_list As Sdata) As System.Data.SqlClient.SqlCommand
            Dim objRET = New System.Data.SqlClient.SqlCommand
            New_Command_SPExec = objRET
            objRET.Connection = ur_sql_conn
            objRET.CommandText = ur_command_text
            objRET.CommandType = System.Data.CommandType.StoredProcedure
            objRET.CommandTimeout = 0
            For Each strPARM In ur_parm_list
                Dim objPARM = objRET.Parameters.Add(strPARM, System.Data.SqlDbType.NVarChar)
                objPARM.Direction = System.Data.ParameterDirection.Input
                objPARM.IsNullable = True
                objPARM.Value = System.DBNull.Value
            Next strPARM
        End Function 'New_Command_SPExec
    End Class 'MxSQL
End Namespace 'Mx
