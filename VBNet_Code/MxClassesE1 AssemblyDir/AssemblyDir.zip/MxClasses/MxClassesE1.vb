Option Strict On
Namespace Mx
    Public Module ConstVar
        Public Const mt = ""
        Public Const qs = """"
        Public Const qt = "'"
        Public Const s = " "

        <System.Diagnostics.DebuggerHidden()>
        Public Function AreEqual(ur_val As String, ur_cmp As String) As Boolean
            AreEqual = String.Equals(ur_val, ur_cmp, System.StringComparison.CurrentCultureIgnoreCase)
        End Function
        <System.Diagnostics.DebuggerHidden()>
        Public Function HasText(ur_value As String) As Boolean
            HasText = Not String.IsNullOrWhiteSpace(ur_value)
        End Function 'HasText

        <System.Diagnostics.DebuggerHidden()>
        Public Function FileNamed() As MxText.FileName
            FileNamed = New MxText.FileName
        End Function

        <System.Diagnostics.DebuggerHidden()>
        Public Function Strapd() As Strap
            Strapd = New Strap
        End Function
    End Module 'ConstVar

    Public Class Strap
        Private pstbTEXT As System.Text.StringBuilder

        <System.Diagnostics.DebuggerHidden()>
        Public Sub New()
            Me.pstbTEXT = New System.Text.StringBuilder
        End Sub

        <System.Diagnostics.DebuggerHidden()>
        Public Shared Widening Operator CType(b As Strap) As String
            Return b.ToString
        End Operator

        <System.Diagnostics.DebuggerHidden()>
        Public Function Clear() As Strap
            Clear = Me
            Call Me.pstbTEXT.Clear()
        End Function

        <System.Diagnostics.DebuggerHidden()>
        Public Function d(ur_text As String) As Strap
            d = Me.dSprtr(mt, ur_text)
        End Function

        <System.Diagnostics.DebuggerHidden()>
        Public Function dLine(Optional ur_text As String = "") As Strap
            dLine = Me.dSprtr(vbCrLf, ur_text)
        End Function

        <System.Diagnostics.DebuggerHidden()>
        Public Function dS(ur_text As String) As Strap
            dS = Me.dSprtr(s, ur_text)
        End Function

        <System.Diagnostics.DebuggerHidden()>
        Public Function dSprtr(ur_sprtr As String, ur_text As String) As Strap
            dSprtr = Me
            Me.pstbTEXT.Append(ur_sprtr).Append(ur_text)
        End Function

        <System.Diagnostics.DebuggerHidden()>
        Public Function HasText() As Boolean
            HasText = (Me.Length > 0)
        End Function

        Public ReadOnly Property Length As Integer
            <System.Diagnostics.DebuggerHidden()>
            Get
                Length = Me.pstbTEXT.Length
            End Get
        End Property

        <System.Diagnostics.DebuggerHidden()>
        Public Shadows Function ToString() As String
            ToString = Me.pstbTEXT.ToString
        End Function
    End Class 'Strap
    
    Public Class MxText
        Public Class FileName
            Public FilePath As String
            <System.Diagnostics.DebuggerHidden()>
            Public Sub New()
                Me.FilePath = mt
            End Sub 'New
            <System.Diagnostics.DebuggerHidden()>
            Public Sub New(ur_path As String)
                Me.FilePath = ur_path
            End Sub 'New

            <System.Diagnostics.DebuggerHidden()>
            Public Shared Widening Operator CType(b As FileName) As String
                Return b.FilePath
            End Operator 'CType
            <System.Diagnostics.DebuggerHidden()>
            Public Shared Widening Operator CType(b As String) As FileName
                Return New FileName(b)
            End Operator 'CType
            <System.Diagnostics.DebuggerHidden()>
            Public Shadows Function ToString() As String
                ToString = Me.FilePath
            End Function 'ToString

            <System.Diagnostics.DebuggerHidden()>
            Public Function d(ur_file_name As String) As FileName
                d = Me
                If HasText(Me.FilePath) Then
                    Me.FilePath = System.IO.Path.Combine(Me.FilePath, ur_file_name)

                Else 'Me
                    Me.FilePath = ur_file_name
                End If 'Me
            End Function 'd

            <System.Diagnostics.DebuggerHidden()>
            Public Function gParentDir() As FileName
                gParentDir = New FileName(Me.ParentDir)
            End Function 'gParentDir

            Public Property Name() As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    Name = mt
                    Dim strPATH = Me.FilePath
                    If HasText(strPATH) Then
                        If HasText(System.IO.Path.GetFileName(strPATH)) = False Then
                            strPATH = System.IO.Path.GetDirectoryName(strPATH)
                        End If 'strPATH
                    End If

                    If HasText(strPATH) Then
                        Name = System.IO.Path.GetFileName(strPATH)
                    End If
                End Get

                <System.Diagnostics.DebuggerHidden()>
                Set(value As String)
                    Me.wParentDir.d(value)
                End Set
            End Property 'Name

            Public Property ParentDir() As String
                <System.Diagnostics.DebuggerHidden()>
                Get
                    ParentDir = mt
                    Dim strPATH = Me.FilePath
                    If HasText(strPATH) Then
                        If HasText(System.IO.Path.GetFileName(strPATH)) = False Then
                            strPATH = System.IO.Path.GetDirectoryName(strPATH)
                        End If 'strPATH
                    End If 'strPATH

                    If HasText(strPATH) Then
                        ParentDir = System.IO.Path.GetDirectoryName(strPATH)
                    End If 'strPATH
                End Get

                <System.Diagnostics.DebuggerHidden()>
                Set(value As String)
                    Dim strFILE_NAME = Me.Name
                    If HasText(value) Then
                        Me.FilePath = System.IO.Path.Combine(value, strFILE_NAME)

                    Else 'value
                        Me.FilePath = strFILE_NAME
                    End If 'value
                End Set
            End Property 'ParentDir
           
            <System.Diagnostics.DebuggerHidden()>
            Public Function wAssemblyDir() As FileName
                wAssemblyDir = Me
                Me.FilePath = glbl.gDiagnostics.GetMainModuleFolder
            End Function 'wAssemblyDir
 
            <System.Diagnostics.DebuggerHidden()>
            Public Function wParentDir() As FileName
                wParentDir = Me
                Me.FilePath = Me.ParentDir
            End Function 'wParentDir
        End Class 'FileName
    End Class 'MxText-FileName

    Partial Public Class glbl
        Public Class gDiagnostics
            <System.Diagnostics.DebuggerHidden()>
            Public Shared Function GetMainModulePath() As MxText.FileName
                Dim flnEXE_PATH = FileNamed().d(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName)
                GetMainModulePath = glbl.gDiagnostics.GetMainModuleFolder.d(flnEXE_PATH.Name)
            End Function 'GetMainModulePath

            <System.Diagnostics.DebuggerHidden()>
            Public Shared Function GetMainModuleFolder() As MxText.FileName
                Dim flnEXE_PATH = FileNamed().d(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName)
                Dim flnPARENT_DIR = flnEXE_PATH.gParentDir
                Dim flnTEMP_DIR = flnPARENT_DIR.gParentDir
                If AreEqual(flnTEMP_DIR.Name, "Debug") Then
                    flnPARENT_DIR = flnTEMP_DIR.gParentDir
                End If
                
                If AreEqual(flnPARENT_DIR.Name, "Debug") Then
                    flnPARENT_DIR = flnPARENT_DIR.gParentDir
                End If
                
                If AreEqual(flnPARENT_DIR.Name, "bin") Then
                    flnPARENT_DIR = flnPARENT_DIR.gParentDir
                End If
                
                GetMainModuleFolder = flnPARENT_DIR
            End Function 'GetMainModuleFolder
        End Class 'gDiagnostics
    End Class 'glbl
End Namespace 'Mx
