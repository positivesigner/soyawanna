﻿Module AppStartup
    Sub Main(args As String())
        Mx.Want.ConsoleFS_WriteUnicodeText_errhnd()
    End Sub 'Main
End Module 'AppStartup

Namespace Mx
    Public Class Want
        Public Shared Sub ConsoleFS_WriteUnicodeText(ret_notice_msg As Strap)
            Dim flnIN_FILE = FileNamed().wAssemblyDir.d("UTF-8 test greetings.txt")
            Dim flnTEMP_FILE = FileNamed().dTempFileName
            Dim flnOUT_FILE = FileNamed().wAssemblyDir.d("WriteUnicodeText.txt").dNowFileGroupYMDHMS.dAppendFileGroup(flnTEMP_FILE.FileGroup)
            Using stmINPUT = New System.IO.StreamReader(flnIN_FILE, gUTF8_FileEncoding)
                Using stmOUTPUT = New System.IO.StreamWriter(flnOUT_FILE, False, gUTF8_FileEncoding)
                    While stmINPUT.EndOfStream = False
                        Dim strLINE = stmINPUT.ReadLine
                        stmOUTPUT.WriteLine(strLINE)
                    End While 'strLINE
                End Using 'stmOUTPUT
            End Using 'stmINPUT

            Using stmSOURCE = New System.IO.StreamReader(flnIN_FILE, gUTF8_FileEncoding)
                Using stmCOMPARE = New System.IO.StreamReader(flnOUT_FILE, gUTF8_FileEncoding)
                    Dim intLINE_COUNT = 0
                    While stmSOURCE.EndOfStream = False
                        Dim strLINE_SRC = stmSOURCE.ReadLine
                        intLINE_COUNT += 1
                        If stmCOMPARE.EndOfStream Then
                            ret_notice_msg.d("Comparison file has less lines")
                            Exit While

                        Else
                            Dim strLINE_CMP = stmCOMPARE.ReadLine
                            If strLINE_SRC <> strLINE_CMP Then
                                ret_notice_msg.d("Comparison file has different text: Line @r1").r1(intLINE_COUNT)
                                ret_notice_msg.dLine(strLINE_SRC)
                                ret_notice_msg.dLine(strLINE_CMP)
                                Exit While
                            End If
                        End If
                    End While 'strLINE

                    If ret_notice_msg.HasText = False AndAlso
                      stmCOMPARE.EndOfStream = False Then
                        ret_notice_msg.d("Comparison file has more lines")
                    End If
                End Using 'stmCOMPARE
            End Using 'stmCOMPARE

            If ret_notice_msg.HasText = False Then
                ret_notice_msg.d("Passed: Files Match")
            End If
        End Sub 'ConsoleFS_WriteUnicodeText

        Public Shared Sub ConsoleFS_WriteUnicodeText_errhnd()
            Dim stpRET = Strapd()
            Dim objERR_LIST = New ErrListBase : Try
                Call ConsoleFS_WriteUnicodeText(stpRET)
                Console.WriteLine(stpRET)

            Catch ex As System.Exception
                Call objERR_LIST.dError_Stack(ex)
            End Try

            If objERR_LIST.Found Then
                Console.WriteLine(objERR_LIST.ToString)
            End If
        End Sub 'ConsoleFS_WriteUnicodeText_errhnd
    End Class 'Want
End Namespace 'Mx
